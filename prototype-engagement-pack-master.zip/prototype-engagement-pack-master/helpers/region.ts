import { loadConfig } from '@smithy/node-config-provider';
import {
  NODE_REGION_CONFIG_OPTIONS,
  NODE_REGION_CONFIG_FILE_OPTIONS
} from '@smithy/config-resolver';

let cachedRegion: string | undefined;

/**
 * Resolves the AWS region using the same chain as every AWS SDK v3 client:
 *   1. `CDK_DEFAULT_REGION` (injected by the CDK CLI)
 *   2. `AWS_REGION` / `AWS_DEFAULT_REGION` environment variables
 *   3. `~/.aws/config` and `~/.aws/credentials` (respects `AWS_PROFILE`)
 *
 * The result is cached after the first successful call.
 * Call this once at startup (e.g. in the wizard) before using `getRegion()`.
 */
export async function resolveRegion(): Promise<string> {
  if (cachedRegion !== undefined) {
    return cachedRegion;
  }

  // CDK CLI injects this env var — check it first.
  if (process.env.CDK_DEFAULT_REGION) {
    cachedRegion = process.env.CDK_DEFAULT_REGION;
    return cachedRegion;
  }

  try {
    // This is the exact same resolution chain every AWS SDK v3 client uses:
    // env vars (AWS_REGION) -> shared config files (~/.aws/config) -> throw
    const region = await loadConfig(
      NODE_REGION_CONFIG_OPTIONS,
      NODE_REGION_CONFIG_FILE_OPTIONS,
    )();
    cachedRegion = region;
    return region;
  } catch {
    cachedRegion = '';
    return '';
  }
}

/**
 * Returns the region synchronously.
 *
 * If `resolveRegion()` was previously called, returns the cached result.
 * Otherwise, falls back to checking environment variables directly
 * (sufficient for the CDK path where `CDK_DEFAULT_REGION` is always set).
 *
 * For the wizard path (where env vars may not be set), `resolveRegion()`
 * must be called first to resolve the region from `~/.aws/config`.
 *
 * @throws if no region could be determined.
 */
export function getRegion(): string {
  if (cachedRegion !== undefined && cachedRegion !== '') {
    return (cachedRegion);
  }

  // Synchronous fallback: check env vars directly.
  // This covers the CDK path where CDK_DEFAULT_REGION is always available.
  const envRegion = process.env.CDK_DEFAULT_REGION
    || process.env.AWS_REGION
    || process.env.AWS_DEFAULT_REGION;

  if (envRegion) {
    cachedRegion = envRegion;
    return (envRegion);
  }

  throw new Error(
    'AWS region is not configured. Please set the AWS_REGION environment variable, ' +
    'configure it in your AWS CLI profile (~/.aws/config), or set it locally by doing: ' +
    'export AWS_REGION=<preferred_region>'
  );
}
