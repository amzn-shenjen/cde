import * as Joi from 'joi';

/**
 * A description of the Amazon GuardDuty configuration
 * in Typescript.
 */
export type IGuardDuty = {

  /**
   * Whether to enable Amazon GuardDuty on the sandbox account.
   */
  enabled: boolean;
};

/**
 * The `Joi` schema for validating the GuardDuty configuration.
 */
export const guardDutySchema = Joi.object().keys({
  enabled: Joi.boolean().required()
});
