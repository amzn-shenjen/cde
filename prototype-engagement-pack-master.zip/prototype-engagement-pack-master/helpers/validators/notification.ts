import * as Joi from 'joi';

/**
 * The available notification types
 * in Typescript.
 */
export enum INotificationType {
  EMAIL = 'email',
  SLACK = 'slack',
  TEAMS = 'teams'
}

/**
 * Describes the properties associated with
 * e-mail notifications.
 */
export type IEmailProps = {

  /**
   * The e-mail address that will be used as the sender
   * of notifications. It must be a valid e-mail address.
   */
  sender: string;

  /**
   * An array of e-mail addresses to which notifications
   * should be sent.
   */
  targets: Set<string>
};

/**
 * Describes the properties associated with
 * Slack notifications.
 */
export type ISlackProps = {
  
  /**
   * To get the ID, open Slack, right click on the channel name in the left pane, then choose Copy Link.
   * The channel ID is the 9-character string at the end of the URL. For example, ABCBBLZZZ.
   */
  slackChannelId: string;

  /**
   * The ID of the Slack workspace authorized with AWS Chatbot.
   * To get the workspace ID, you must perform the initial authorization flow with Slack in the AWS Chatbot console.
   * Then you can copy and paste the workspace ID from the console.
   * For more details, see steps 1-4 in Setting Up AWS Chatbot with Slack in the AWS Chatbot User Guide.
   */
  slackWorkspaceId: string;
}

/**
 * Describes the properties associated with
 * Teams notifications.
 */
export type ITeamsProps = {

  /**
   * The URL of the Teams webhook to which we should send
   * the received notifications.
   */
  webhookUrl: string;
}

/**
 * A description of a notification configuration.
 */
export type INotification = {

  /**
   * E-mail notification.
   */
  [INotificationType.EMAIL]?: IEmailProps;

  /**
   * Slack notification.
   */
  [INotificationType.SLACK]?: ISlackProps;

  /**
   * Teams notification.
   */
  [INotificationType.TEAMS]?: ITeamsProps
}

/**
 * The `Joi` schema for validating the notification configuration.
 */
export const notificationSchema = Joi.object().keys({
  [INotificationType.EMAIL]: Joi.object().keys({
    sender: Joi.string().email().required(),
    targets: Joi.array().items(
      Joi.string().email()
    ).min(1).required()
  }).optional(),
  [INotificationType.SLACK]: Joi.object().keys({
    slackChannelId: Joi.string().required(),
    slackWorkspaceId: Joi.string().required()
  }).optional(),
  [INotificationType.TEAMS]: Joi.object().keys({
    webhookUrl: Joi.string().uri({ scheme: ['https'] }).required()
  }).optional()
});
