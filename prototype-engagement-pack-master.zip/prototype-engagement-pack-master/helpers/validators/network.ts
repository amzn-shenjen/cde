import * as Joi from 'joi';

/**
 * A description of the network configuration
 * in Typescript.
 */
export type INetwork = {

  /**
   * Whether to create a VPC with isolated subnets
   * as well as the required VPC endpoints deployed
   * Lambda functions can use to keep traffic internal
   * to the AWS network.
   */
  useVpcEndpoints: boolean
};

/**
 * The `Joi` schema for validating the network configuration.
 */
export const networkSchema = Joi.object().keys({
  useVpcEndpoints: Joi.boolean().default(false).required()
});