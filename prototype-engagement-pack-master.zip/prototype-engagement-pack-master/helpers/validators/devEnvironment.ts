import * as Joi from 'joi';

/**
 * Describes the development environment configuration.
 */
export type IDevEnvironment = {
  /**
   * Whether the development environment is enabled.
   */
  enabled: boolean;

  /**
   * The disk space required for the development environment in GB.
   */
  diskSpaceGb: number;

  /**
   * The instance type for the development environment.
   */
  instanceType?: string;

  /**
   * The access method for the development environment.
   * 'code-server' for browser-based VS Code, 'vscode-ssh' for VS Code via SSH over SSM.
   */
  ideType?: 'code-server' | 'vscode-ssh';

  /**
   * Optional VPC ID to reuse existing VPC instead of creating a new one.
   */
  vpcId?: string;

  /**
   * Optional subnet ID to use for the development instance.
   * Required if vpcId is provided. The subnet must have internet access.
   */
  subnetId?: string;

  /**
   * Optional availability zone for the subnet.
   * Required if subnetId is provided.
   */
  availabilityZone?: string;
};

/**
 * The `Joi` schema for validating the development environment configuration.
 */
export const devEnvironmentSchema = Joi.object().keys({
  enabled: Joi.boolean().default(false).required(),
  diskSpaceGb: Joi.number().min(8).max(200).default(50).optional(),
  instanceType: Joi.string().default('m5.xlarge').optional(),
  ideType: Joi.string().valid('code-server', 'vscode-ssh').default('code-server').optional(),
  vpcId: Joi.string().pattern(/^vpc-[0-9a-f]{8,17}$/).optional(),
  subnetId: Joi.string().pattern(/^subnet-[0-9a-f]{8,17}$/).when('vpcId', {
    is: Joi.exist(),
    then: Joi.required(),
    otherwise: Joi.optional()
  }),
  availabilityZone: Joi.string().pattern(/^[a-z]{2}-[a-z]+-[0-9][a-z]$/).when('vpcId', {
    is: Joi.exist(),
    then: Joi.required(),
    otherwise: Joi.optional()
  })
});
