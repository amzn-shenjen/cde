import * as Joi from 'joi';

/**
 * A description of the AWS Budget configuration
 * in Typescript.
 */
export type IBudget = {

  /**
   * The limit (in defined currency) at which a notification is
   * to be sent when the actual budget is superior
   * to the limit value.
   */
  limit: number;
};

/**
 * The `Joi` schema for validating the budget configuration.
 */
export const budgetSchema = Joi.object().keys({
  limit: Joi
    .number()
    .min(1)
    .required()
});
