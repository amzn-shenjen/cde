import * as Joi from 'joi';

/**
 * A description of the AWS CloudTrail configuration
 * in Typescript.
 */
export type ICloudTrail = {

  /**
   * Whether to capture events from all regions in the
   * created CloudTrail trail. Otherwise, captures the
   * events from the region in which the trail is created.
   */
  multiRegion: boolean
};

/**
 * The `Joi` schema for validating the cloudtrail configuration.
 */
export const cloudTrailSchema = Joi.object().keys({
  multiRegion: Joi
    .boolean()
    .default(true)
    .required()
});