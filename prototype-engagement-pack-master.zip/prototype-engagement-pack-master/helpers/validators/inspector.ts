import * as Joi from 'joi';

/**
 * Amazon Inspector configuration
 */
export type IInspector = {

  /**
   * Whether to enable Amazon Inspector
   */
  enabled: boolean,
};

/**
 * The `Joi` schema for validating the Amazon Inspector configuration.
 */
export const inspectorSchema = Joi.object().keys({
  enabled: Joi.boolean().default(true).required(),
});