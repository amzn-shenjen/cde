import * as Joi from 'joi';
import { isValidRoleArn } from '../iam-arn';

/**
 * The maximum number of IAM users that can be trusted.
 * IAM caps a role trust policy at 2048 characters.
 * @see https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_iam-quotas.html
 */
export const MAX_TRUSTED_USERS = 5;

/**
 * The `Joi` schema validating an IAM user name.
 */
export const usernameSchema = Joi
  .string()
  .max(64)
  .pattern(/^[\w+=,.@-]+$/);

/**
 * The trust target of the cross-account role.
 */
export type TrustMode =
  | 'role'
  | 'user'
  | 'account';

/**
 * The properties common to every trust mode.
 */
type IEngagementRoleBase = {

  /**
   * An array of managed policy ARNs to add to the role
   * being assumed by the AWS team.
   */
  managedPolicies: string[];

  /**
   * The account identifier of the account used by the
   * AWS team to access the customer account. In `role` trust
   * mode this is derived from `sourceRoleArn`.
   */
  sourceAccountId: string;
};

/**
 * A description of the cross-account role to be created. Each trust
 * mode carries its own identifiers, and they are mutually exclusive.
 */
export type IEngagementRole = IEngagementRoleBase & (
  | {

    /**
     * Trusts a single named IAM role in the source account.
     */
    trustMode: 'role';

    /**
     * The ARN of the IAM role in the source account used by the
     * AWS team to access the customer account.
     */
    sourceRoleArn: string;
  }
  | {

    /**
     * Trusts named IAM users in the source account.
     */
    trustMode: 'user';

    /**
     * The names of the IAM users in the source account used by the
     * AWS team to access the customer account.
     */
    sourceUsernames: string[];
  }
  | {

    /**
     * Trusts the source account as a whole.
     */
    trustMode: 'account';
  }
);

/**
 * A description of an engagement configuration
 * in Typescript.
 */
export type IEngagement = {

  /**
   * The ARN of the role to be assumed by the
   * AWS team.
   */
  role: IEngagementRole;

  /**
   * The date at which the engagement will start
   * in the IAM policy format.
   * See here for a documentation on the format https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_examples_aws-dates.html
   */
  start: string;

  /**
    * The date at which the engagement will end (inclusive)
    * in the IAM policy format.
    * See here for a documentation on the format https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_examples_aws-dates.html
    */
  end: string;
};

/**
 * The `Joi` schema for validating the engagement configuration.
 */
export const engagementSchema = Joi.object().keys({
  role: Joi.object().keys({
    trustMode: Joi
      .string()
      .valid('role', 'user', 'account')
      .required(),
    managedPolicies: Joi
      .array()
      .default([])
      .required(),
    sourceRoleArn: Joi.when('trustMode', {
      is: 'role',
      then: Joi
        .string()
        .custom((value, helpers) => (isValidRoleArn(value) ? value : helpers.error('any.invalid')))
        .required()
        .messages({ 'any.invalid': 'sourceRoleArn must be a valid IAM role ARN' }),
      otherwise: Joi
        .string()
        .optional()
    }),
    sourceUsernames: Joi.when('trustMode', {
      is: 'user',
      then: Joi
        .array()
        .items(usernameSchema)
        .min(1)
        .max(MAX_TRUSTED_USERS)
        .unique((a: string, b: string) => a.toLowerCase() === b.toLowerCase())
        .required(),
      otherwise: Joi
        .array()
        .optional()
    }),
    sourceAccountId: Joi
      .string()
      .min(12)
      .max(12)
      .required()
  }).optional(),
  start: Joi
    .string()
    .required(),
  end: Joi
    .string()
    .required()
});
