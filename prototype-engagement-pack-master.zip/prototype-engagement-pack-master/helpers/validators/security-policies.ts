import * as Joi from 'joi';

/**
 * A description of the security policies configuration
 * in Typescript.
 */
export type ISecurityPolicies = {

  /**
   * Whether to restrict S3 public access.
   */
  enableS3PublicAccessBlock?: boolean;

  /**
   * Whether to enable protection for the current
   * stack.
   */
  enableStackProtection?: boolean;

  /**
   * Whether to enable an alarm monitoring running actions
   * on large EC2 instances (>= 4xlarge).
   */
  enableLargeInstanceProtection?: boolean;
};

/**
 * The `Joi` schema for validating the security policies configuration.
 */
export const securityPoliciesSchema = Joi.object().keys({
  enableS3PublicAccessBlock: Joi.boolean().default(false).optional(),
  enableStackProtection: Joi.boolean().default(false).optional(),
  enableLargeInstanceProtection: Joi.boolean().default(false).optional()
});
