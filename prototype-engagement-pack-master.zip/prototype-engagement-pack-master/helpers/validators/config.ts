import * as Joi from 'joi';

/**
 * Identifiers of the custom Lambda-backed Config rules.
 */
export const CustomConfigRuleNames = {
  s3Cmk: 'S3_ENCRYPTED_WITH_CMK'
} as const;

/**
 * The kind of an AWS Config rule entry persisted in the
 * configuration. Drives how the construct deploys the entry.
 */
export type ConfigRuleKind =
  | 'managed'
  | 'custom'
  | 'vpc-endpoint';

/**
 * One rule entry persisted in `prototype.context.json`.
 */
export type ConfigRuleEntry = {

  /**
   * Stable identifier — must match an entry in the catalog.
   */
  id: string;

  /**
   * Discriminator that pairs the entry with the right deployment
   * branch in `ConfigConstruct`.
   */
  kind: ConfigRuleKind;

  /**
   * Whether this rule should be paired with an automatic
   * remediation. Only meaningful for `managed` rules whose id
   * is handled by a remediation construct; ignored otherwise.
   */
  enableRemediation?: boolean;
};

/**
 * The AWS Config configuration persisted in
 * `prototype.context.json`. A single deduped, self-describing
 * array of rule entries — kind-specific buckets are derived in
 * the construct.
 */
export type IConfig = {

  /**
   * The selected rule entries. Deduped at load time by id.
   */
  rules: ConfigRuleEntry[];
};

/**
 * Joi schema for validating one rule entry.
 */
const ruleEntrySchema = Joi.object<ConfigRuleEntry>().keys({
  id: Joi
    .string()
    .required(),
  kind: Joi
    .string()
    .valid('managed', 'custom', 'vpc-endpoint')
    .required(),
  enableRemediation: Joi
    .boolean()
    .default(false)
    .optional()
});

/**
 * Joi schema for validating the AWS Config configuration.
 */
export const configSchema = Joi.object<IConfig>().keys({
  rules: Joi
    .array()
    .items(ruleEntrySchema)
    .required()
});
