import * as Joi from 'joi';

import { engagementSchema } from './engagement';
import { networkSchema } from './network';
import { cloudTrailSchema } from './cloudtrail';
import { configSchema } from './config';
import { budgetSchema } from './budget';
import { guardDutySchema } from './guardDuty';
import { notificationSchema } from './notification';
import { securityPoliciesSchema } from './security-policies';
import { inspectorSchema } from './inspector';
import { devEnvironmentSchema } from './devEnvironment';

import type { IEngagement } from './engagement';
import type { INetwork } from './network';
import type { ICloudTrail } from './cloudtrail';
import type { IConfig } from './config';
import type { IBudget } from './budget';
import type { IGuardDuty } from './guardDuty';
import type { INotification } from './notification';
import type { ISecurityPolicies } from './security-policies';
import type { IInspector } from './inspector';
import type { IDevEnvironment } from './devEnvironment';

/**
 * Describes a configuration associated with the
 * current stack in Typescript.
 */
export type IConfiguration = {

  /**
   * This key contains all the data associated with
   * the prototyping engagement.
   */
  engagement?: IEngagement;

  /**
   * This key defines the network configuration to
   * apply to the deployment.
   */
  network?: INetwork;

  /**
   * This key defines the security policies to
   * apply to the deployment.
   */
  securityPolicies?: ISecurityPolicies;

  /**
   * This key allows to define AWS CloudTrail options.
   */
  cloudtrail?: ICloudTrail;

  /**
   * This key defines AWS Config options. Holds the unified set
   * of rules selected by the user across the wizard's `config`
   * and `genai` screens.
   */
  config?: IConfig;

  /**
   * This key defines how to monitor the budget.
   */
  budget?: IBudget;

  /**
   * This key defines whether guard duty is enabled.
   */
  guardDuty?: IGuardDuty;

  /**
   * This key defines whether inspector is enabled.
   */
  inspector?: IInspector;

  /**
   * This key defines who and how to notify for compliance issues.
   */
  notification?: INotification;

  /**
   * This key defines the development environment configuration.
   */
  devEnvironment?: IDevEnvironment;

  /**
   * This key defines the mandatory tags to apply to the deployment.
   */
  tags?: {
    [key: string]: string;
  };
};

/**
 * The `Joi` schema for validating the configuration.
 */
export const schema = Joi.object().keys({
  engagement: engagementSchema.optional(),
  network: networkSchema.optional(),
  securityPolicies: securityPoliciesSchema.optional(),
  cloudtrail: cloudTrailSchema.optional(),
  config: configSchema.optional(),
  budget: budgetSchema.optional(),
  guardDuty: guardDutySchema.optional(),
  inspector: inspectorSchema.optional(),
  notification: notificationSchema.optional(),
  devEnvironment: devEnvironmentSchema.optional(),
  tags: Joi.object().default({}).optional()
}).unknown().required();
