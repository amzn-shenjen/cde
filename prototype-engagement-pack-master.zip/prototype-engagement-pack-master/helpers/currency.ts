import { PARTITION } from './partition';

/**
 * The supported currencies.
 */
export type Currency =
  | 'USD'
  | 'CNY'
  | 'EUR';

/**
 * A helper function to resolve the currency based on the
 * current AWS partition.
 * @param partition the used AWS partition.
 * @returns the resolved currency code.
 */
const resolveCurrency = (partition: string): Currency => {
  switch (partition) {
    case 'aws-cn':
      return 'CNY';
    case 'aws-eusc':
      return 'EUR';
    default:
      return 'USD';
  }
};

/**
 * The currency code to use across the selected partition.
 */
export const CURRENCY = resolveCurrency(PARTITION);
