import { Arn, ArnFormat } from 'aws-cdk-lib';

/**
 * 12-digit AWS account id.
 */
const ACCOUNT_ID_PATTERN = /^\d{12}$/;

/**
 * The parsed components of a validated IAM role ARN.
 */
export type ParsedRoleArn = {

  /**
   * The full role ARN, unchanged.
   */
  arn: string;

  /**
   * The 12-digit AWS account id owning the role.
   */
  accountId: string;

  /**
   * The role name (the part after `role/`, path included).
   */
  roleName: string;

  /**
   * The AWS partition (e.g. `aws`, `aws-cn`).
   */
  partition: string;
};

/**
 * Parses and validates an IAM role ARN using the AWS CDK's `Arn`
 * utility, then layers on the IAM-specific constraints: the
 * service must be `iam`, the resource must be a `role`, and the
 * account id must be 12 digits. Returns the parsed components, or
 * `undefined` when the value is not a well-formed IAM role ARN.
 *
 * Accepts paths in the role resource (e.g. `role/team/Name`).
 *
 * @param value - The candidate ARN.
 */
export const parseRoleArn = (value: string | undefined): ParsedRoleArn | undefined => {
  if (!value) {
    return (undefined);
  }

  try {
    // SLASH_RESOURCE_NAME splits `role/Name` (and `role/path/Name`)
    // into resource `role` + resourceName `path/Name`.
    const components = Arn.split(value, ArnFormat.SLASH_RESOURCE_NAME);
    if (
      components.service !== 'iam'
      || components.resource !== 'role'
      || !components.resourceName
      || !components.account
      || !ACCOUNT_ID_PATTERN.test(components.account)
    ) {
      return (undefined);
    }
    return ({
      arn: value,
      accountId: components.account,
      roleName: components.resourceName,
      partition: components.partition ?? 'aws'
    });
  } catch {
    return (undefined);
  }
};

/**
 * Returns whether `value` is a syntactically valid IAM role ARN.
 * @param value - The candidate ARN.
 */
export const isValidRoleArn = (value: string | undefined): value is string => {
  return (parseRoleArn(value) !== undefined);
};
