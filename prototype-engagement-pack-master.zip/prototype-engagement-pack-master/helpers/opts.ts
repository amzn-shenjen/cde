import * as fs from 'node:fs';
import * as path from 'node:path';

import { schema } from './validators/configuration';

import type { IConfiguration } from './validators/configuration';
import type { ConfigRuleEntry } from './validators/config';

/**
 * Path of the wizard-generated configuration file, relative to
 * this module.
 */
const CONFIG_PATH = path.resolve(__dirname, '..', 'prototype.context.json');

/**
 * Reads, parses, and validates the wizard-generated configuration
 * file. Rule entries persisted under `config.rules` are deduped
 * by id, preserving first occurrence — the file is generated, but
 * we treat it as a set in code so a hand-edit can never deploy a
 * duplicate.
 * @throws if the file is missing or invalid.
 */
export const getOpts = async (): Promise<IConfiguration> => {
  let raw: string;
  try {
    raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  } catch {
    console.error(
      `\nThe 'prototype.context.json' configuration file could not be found.\n`
      + `Please run 'npm run wizard' to generate a configuration before deploying.\n`
    );
    process.exit(1);
  }

  const parsed: unknown = JSON.parse(raw);
  const result = schema.validate(parsed);

  if (result.error) {
    throw new Error(result.error.message);
  }

  const configuration = result.value as IConfiguration;
  if (configuration.config?.rules) {
    configuration.config.rules = dedupeRulesById(configuration.config.rules);
  }

  return (configuration);
};

/**
 * Dedupes rule entries by id, preserving first occurrence.
 * @param rules - The rules to dedupe.
 */
const dedupeRulesById = (rules: readonly ConfigRuleEntry[]): ConfigRuleEntry[] => {
  const byId = new Map<string, ConfigRuleEntry>();
  for (const rule of rules) {
    if (!byId.has(rule.id)) {
      byId.set(rule.id, rule);
    }
  }
  return ([...byId.values()]);
};
