import { getRegion } from './region';

/**
 * The set of AWS partitions the Prototype Engagement Pack
 * supports.
 */
export type Partition =
  | 'aws'
  | 'aws-cn'
  | 'aws-us-gov'
  | 'aws-eusc';

/**
 * Default partition for every region not matched by `PARTITIONS`.
 */
const DEFAULT_PARTITION: Partition = 'aws';

/**
 * Region prefix → partition mapping. First match wins.
 */
const PARTITIONS: Readonly<Record<string, Partition>> = {
  'cn-':     'aws-cn',
  'us-gov-': 'aws-us-gov',
  'eusc-':   'aws-eusc'
};

/**
 * Public AWS console host per partition.
 */
const CONSOLE_HOSTS: Readonly<Record<Partition, string>> = {
  'aws':        'console.aws.amazon.com',
  'aws-cn':     'console.amazonaws.cn',
  'aws-us-gov': 'console.amazonaws-us-gov.com',
  'aws-eusc':   'console.amazonaws.eu'
};

/**
 * Resolves the AWS partition for a given region.
 * @param region - AWS region (e.g. `us-east-1`, `cn-north-1`).
 */
const resolvePartition = (region: string): Partition => {
  for (const [prefix, partition] of Object.entries(PARTITIONS)) {
    if (region.startsWith(prefix)) {
      return (partition);
    }
  }
  return (DEFAULT_PARTITION);
};

/**
 * Returns the public AWS console host for the given partition.
 * Falls back to the commercial host when the partition is
 * unknown.
 * @param partition - The AWS partition. Defaults to the current
 * partition.
 */
export const getConsoleHost = (partition: Partition = PARTITION): string => {
  return (CONSOLE_HOSTS[partition] ?? CONSOLE_HOSTS[DEFAULT_PARTITION]);
};

/**
 * The current AWS partition.
 */
export const PARTITION: Partition = resolvePartition(getRegion());
