import { describe, test, expect } from 'vitest';

import { engagementSchema, MAX_TRUSTED_USERS } from '../helpers/validators/engagement';

/**
 * Builds a baseline engagement payload for the given role block.
 * @param role - The `role` sub-object under test.
 */
const engagementWith = (role: Record<string, unknown>) => ({
  role,
  start: '2026-01-01T00:00:00.000Z',
  end: '2026-03-01T00:00:00.000Z'
});

describe('engagementSchema — role trust mode', () => {

  /**
   * A valid role ARN passes and the account id is accepted.
   */
  test('accepts a valid sourceRoleArn', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'role',
      sourceAccountId: '123456789012',
      sourceRoleArn: 'arn:aws:iam::123456789012:role/PrototypeAccess',
      managedPolicies: []
    }));
    expect(error).toBeUndefined();
  });

  /**
   * `role` mode requires `sourceRoleArn`.
   */
  test('rejects role mode without sourceRoleArn', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'role',
      sourceAccountId: '123456789012',
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });

  /**
   * A malformed ARN is rejected with the custom message.
   */
  test('rejects an invalid sourceRoleArn', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'role',
      sourceAccountId: '123456789012',
      sourceRoleArn: 'arn:aws:iam::123456789012:user/bob',
      managedPolicies: []
    }));
    expect(error?.message).toContain('valid IAM role ARN');
  });
});

describe('engagementSchema — user trust mode', () => {

  /**
   * A single trusted username passes.
   */
  test('accepts a single sourceUsername', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: ['jane.doe'],
      managedPolicies: []
    }));
    expect(error).toBeUndefined();
  });

  /**
   * The trusted usernames fill up to the documented maximum.
   */
  test('accepts the maximum number of sourceUsernames', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: Array.from({ length: MAX_TRUSTED_USERS }, (_, index) => `user-${index}`),
      managedPolicies: []
    }));
    expect(error).toBeUndefined();
  });

  /**
   * Exceeding the maximum keeps the trust policy under the IAM
   * 2048 character limit.
   */
  test('rejects more than the maximum number of sourceUsernames', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: Array.from({ length: MAX_TRUSTED_USERS + 1 }, (_, index) => `user-${index}`),
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });

  /**
   * The same user cannot be trusted twice.
   */
  test('rejects duplicate sourceUsernames', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: ['jane.doe', 'jane.doe'],
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });

  /**
   * IAM user names are unique regardless of their case, so two
   * spellings of the same name are a duplicate.
   */
  test('rejects sourceUsernames differing only by case', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: ['jane.doe', 'JANE.DOE'],
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });

  /**
   * `user` mode requires at least one username.
   */
  test('rejects user mode without sourceUsernames', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });

  /**
   * A username containing characters IAM disallows is rejected.
   */
  test('rejects a malformed sourceUsername', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'user',
      sourceAccountId: '123456789012',
      sourceUsernames: ['jane doe'],
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });
});

describe('engagementSchema — account trust mode', () => {

  /**
   * `account` mode needs only the source account id — no ARN.
   */
  test('accepts account mode without sourceRoleArn', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'account',
      sourceAccountId: '123456789012',
      managedPolicies: []
    }));
    expect(error).toBeUndefined();
  });

  /**
   * The source account id must be 12 digits in any mode.
   */
  test('rejects a malformed source account id', () => {
    const { error } = engagementSchema.validate(engagementWith({
      trustMode: 'account',
      sourceAccountId: '123',
      managedPolicies: []
    }));
    expect(error).toBeDefined();
  });
});
