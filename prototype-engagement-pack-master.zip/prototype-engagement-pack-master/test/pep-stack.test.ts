import { describe, test, expect, beforeEach } from 'vitest';
import { App } from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { PepStack } from '../lib/pep-stack';
import { CURRENCY } from '../helpers/currency';

import type { ConfigRuleEntry } from '../helpers/validators/config';
import type { Partition } from '../lib/constructs/config/catalog';
import {
  RULE_CATALOG,
  entries,
  getVpcEndpointServiceName,
  isSupportedInPartition
} from '../lib/constructs/config/catalog';

// The CDK application.
let app: App;

// The stack environment.
const cdkEnv = {
  account: process.env.CDK_DEFAULT_ACCOUNT,
  region: process.env.CDK_DEFAULT_REGION
};

// The active partition. Tests run in the commercial partition by
// default; explicit casts keep the catalog helpers honest about
// the value flowing into them.
const ACTIVE_PARTITION: Partition = 'aws';

describe('Testing the Prototype Engagement options', () => {

  beforeEach(() => {
    app = new App();
  });

  /**
   * Cross-account role tests.
   */
  test('Cross-account role should be created', () => {
    const stack = new PepStack(app, 'PepStack', {
      engagement: {
        start: '2021-01-01T00:00:00.000Z',
        end: '2021-01-02T00:00:00.000Z',
        role: {
          trustMode: 'account',
          sourceAccountId: '132112121222',
          managedPolicies: ['arn:aws:iam::aws:policy/PowerUserAccess']
        }
      }
    }, cdkEnv);

    const accountPrincipal = {
      AWS: {
        'Fn::Join': ['', ['arn:', { Ref: 'AWS::Partition' }, ':iam::132112121222:root']]
      }
    };
    const accountConditions = {
      Bool: { 'aws:MultiFactorAuthPresent': true },
      DateGreaterThan: { 'aws:CurrentTime': '2021-01-01T00:00:00.000Z' },
      DateLessThan: { 'aws:CurrentTime': '2021-01-02T00:00:00.000Z' }
    };

    Template.fromStack(stack).hasResourceProperties('AWS::IAM::Role', {
      AssumeRolePolicyDocument: {
        Statement: Match.arrayWith([
          {
            Action: 'sts:AssumeRole',
            Condition: accountConditions,
            Effect: 'Allow',
            Principal: accountPrincipal
          },
          {
            Action: 'sts:SetSourceIdentity',
            Condition: accountConditions,
            Effect: 'Allow',
            Principal: accountPrincipal
          }
        ]),
        Version: '2012-10-17'
      },
      Description: 'A role to be assumed by the AWS team to access and operate on customer accounts.',
      ManagedPolicyArns: ['arn:aws:iam::aws:policy/PowerUserAccess'],
      MaxSessionDuration: 43200
    });
  });

  test('Cross-account role should be created when a specific IAM Role is trusted', () => {
    const sourceRoleArn = 'arn:aws:iam::132112121222:role/TestSourceRole';
    const stack = new PepStack(app, 'PepStack', {
      engagement: {
        start: '2021-01-01T00:00:00.000Z',
        end: '2021-01-02T00:00:00.000Z',
        role: {
          trustMode: 'role',
          sourceAccountId: '132112121222',
          sourceRoleArn,
          managedPolicies: ['arn:aws:iam::aws:policy/PowerUserAccess']
        }
      }
    }, cdkEnv);

    const roleConditions = {
      DateGreaterThan: { 'aws:CurrentTime': '2021-01-01T00:00:00.000Z' },
      DateLessThan: { 'aws:CurrentTime': '2021-01-02T00:00:00.000Z' }
    };

    Template.fromStack(stack).hasResourceProperties('AWS::IAM::Role', {
      AssumeRolePolicyDocument: {
        Statement: Match.arrayWith([
          {
            Action: 'sts:AssumeRole',
            Condition: roleConditions,
            Effect: 'Allow',
            Principal: { AWS: sourceRoleArn }
          },
          {
            Action: 'sts:SetSourceIdentity',
            Condition: roleConditions,
            Effect: 'Allow',
            Principal: { AWS: sourceRoleArn }
          }
        ]),
        Version: '2012-10-17'
      },
      Description: 'A role to be assumed by the AWS team to access and operate on customer accounts.',
      ManagedPolicyArns: ['arn:aws:iam::aws:policy/PowerUserAccess'],
      MaxSessionDuration: 43200
    });
  });

  test('Cross-account role should be created when IAM users are trusted', () => {
    const stack = new PepStack(app, 'PepStack', {
      engagement: {
        start: '2021-01-01T00:00:00.000Z',
        end: '2021-01-02T00:00:00.000Z',
        role: {
          trustMode: 'user',
          sourceAccountId: '132112121222',
          sourceUsernames: ['jane.doe', 'john.smith'],
          managedPolicies: ['arn:aws:iam::aws:policy/PowerUserAccess']
        }
      }
    }, cdkEnv);

    // Every trusted user lands in a single `Principal.AWS` array,
    // keeping the trust policy under the IAM 2048 character limit.
    const userPrincipal = {
      AWS: [
        'arn:aws:iam::132112121222:user/jane.doe',
        'arn:aws:iam::132112121222:user/john.smith'
      ]
    };
    const userConditions = {
      Bool: { 'aws:MultiFactorAuthPresent': true },
      DateGreaterThan: { 'aws:CurrentTime': '2021-01-01T00:00:00.000Z' },
      DateLessThan: { 'aws:CurrentTime': '2021-01-02T00:00:00.000Z' }
    };

    Template.fromStack(stack).hasResourceProperties('AWS::IAM::Role', {
      AssumeRolePolicyDocument: {
        Statement: Match.arrayWith([
          {
            Action: 'sts:AssumeRole',
            Condition: userConditions,
            Effect: 'Allow',
            Principal: userPrincipal
          },
          {
            Action: 'sts:SetSourceIdentity',
            Condition: userConditions,
            Effect: 'Allow',
            Principal: userPrincipal
          }
        ]),
        Version: '2012-10-17'
      },
      Description: 'A role to be assumed by the AWS team to access and operate on customer accounts.',
      ManagedPolicyArns: ['arn:aws:iam::aws:policy/PowerUserAccess'],
      MaxSessionDuration: 43200
    });
  });

  /**
   * AWS Budgets test.
   */
  test('AWS Budgets should be created', () => {
    const stack = new PepStack(app, 'PepStack', {
      budget: { limit: 100 }
    }, cdkEnv);

    Template.fromStack(stack).hasResourceProperties('AWS::Budgets::Budget', {
      Budget: {
        BudgetLimit: { Amount: 100, Unit: CURRENCY },
        BudgetName: 'prototype-budget',
        BudgetType: 'COST',
        TimeUnit: 'MONTHLY'
      }
    });
  });

  /**
   * Amazon GuardDuty tests.
   */
  test('Amazon GuardDuty should synthesize a bootstrap Lambda when enabled', () => {
    const stack = new PepStack(app, 'PepStack', {
      guardDuty: { enabled: true }
    }, cdkEnv);

    const template = Template.fromStack(stack);

    // The bootstrap Lambda is present and the EventBridge rule is wired.
    template.hasResourceProperties('AWS::Lambda::Function', Match.objectLike({
      Description: Match.stringLikeRegexp('GuardDuty')
    }));
    template.resourceCountIs('AWS::Events::Rule', 1);
  });

  test('Amazon GuardDuty should not synthesize anything when disabled', () => {
    const stack = new PepStack(app, 'PepStack', {
      guardDuty: { enabled: false }
    }, cdkEnv);

    const template = Template.fromStack(stack);
    template.resourceCountIs('AWS::GuardDuty::Detector', 0);
    template.resourceCountIs('AWS::Events::Rule', 0);
  });

  /**
   * AWS CloudTrail test.
   */
  test('AWS CloudTrail trail should be created', () => {
    const stack = new PepStack(app, 'LocalTrail', {
      cloudtrail: { multiRegion: false }
    }, cdkEnv);

    Template.fromStack(stack).hasResourceProperties('AWS::CloudTrail::Trail', {
      EnableLogFileValidation: true,
      IncludeGlobalServiceEvents: true,
      IsMultiRegionTrail: false
    });

    const allStack = new PepStack(new App(), 'GlobalTrail', {
      cloudtrail: { multiRegion: true }
    }, cdkEnv);

    Template.fromStack(allStack).hasResourceProperties('AWS::CloudTrail::Trail', {
      EnableLogFileValidation: true,
      IncludeGlobalServiceEvents: true,
      IsMultiRegionTrail: true
    });
  });

  /**
   * AWS Config tests.
   */
  test('AWS Config managed rules should be created', () => {
    const rules: ConfigRuleEntry[] = [
      { id: 'S3_BUCKET_PUBLIC_READ_PROHIBITED', kind: 'managed', enableRemediation: true },
      { id: 'S3_BUCKET_PUBLIC_WRITE_PROHIBITED', kind: 'managed', enableRemediation: true },
      { id: 'IAM_USER_MFA_ENABLED', kind: 'managed' }
    ];

    const stack = new PepStack(app, 'PepStack', { config: { rules } }, cdkEnv);

    rules.forEach((rule) => {
      Template.fromStack(stack).hasResourceProperties('AWS::Config::ConfigRule', {
        Source: { Owner: 'AWS', SourceIdentifier: rule.id },
        ConfigRuleName: rule.id
      });
    });

    Template.fromStack(stack).hasResourceProperties('AWS::Events::Rule', {
      Description: 'Listens to events sent by AWS Config on compliance updates.',
      EventPattern: {
        source: ['aws.config'],
        'detail-type': ['Config Rules Compliance Change'],
        detail: {
          newEvaluationResult: {
            complianceType: ['NON_COMPLIANT']
          }
        }
      },
      State: 'ENABLED'
    });
  });

  test('AWS Config rules should include custom rules', () => {
    const rules: ConfigRuleEntry[] = [
      { id: 'S3_BUCKET_PUBLIC_READ_PROHIBITED', kind: 'managed', enableRemediation: true },
      { id: 'S3_ENCRYPTED_WITH_CMK', kind: 'custom' }
    ];

    const stack = new PepStack(app, 'PepStack', { config: { rules } }, cdkEnv);

    Template.fromStack(stack).hasResourceProperties('AWS::Config::ConfigRule', {
      Source: { Owner: 'AWS', SourceIdentifier: 'S3_BUCKET_PUBLIC_READ_PROHIBITED' },
      ConfigRuleName: 'S3_BUCKET_PUBLIC_READ_PROHIBITED'
    });

    Template.fromStack(stack).hasResourceProperties('AWS::Config::ConfigRule', {
      Source: { Owner: 'CUSTOM_LAMBDA' },
      ConfigRuleName: 's3-cmk-encryption-check'
    });
  });

  test('AWS Config rules should include vpc endpoint rules', () => {
    const region = 'us-east-1';
    const rules: ConfigRuleEntry[] = [
      { id: 'S3_BUCKET_PUBLIC_READ_PROHIBITED', kind: 'managed', enableRemediation: true },
      { id: 'SERVICE_VPC_ENDPOINT_ENABLED_SSM', kind: 'vpc-endpoint' },
      { id: 'SERVICE_VPC_ENDPOINT_ENABLED_S3', kind: 'vpc-endpoint' }
    ];

    const stack = new PepStack(app, 'PepStack', { config: { rules } }, { ...cdkEnv, region });

    [`com.amazonaws.${region}.s3`, `com.amazonaws.${region}.ssm`].forEach((service) => {
      Template.fromStack(stack).hasResourceProperties('AWS::Config::ConfigRule', {
        Source: { Owner: 'AWS', SourceIdentifier: 'SERVICE_VPC_ENDPOINT_ENABLED' },
        InputParameters: { serviceName: service }
      });
    });
  });

  /**
   * GenAI tests — feed every catalog entry surfaced through the
   * GenAI screen into `config.rules` and check that they all
   * land as the right kind of CFN resource.
   */
  describe('GenAI rules', () => {
    const region = 'us-east-1';
    const genaiEntries = entries('genai').filter(
      (entry) => isSupportedInPartition(entry, ACTIVE_PARTITION)
    );

    const genaiRules: ConfigRuleEntry[] = genaiEntries.map((entry) => ({
      id: entry.id,
      kind: entry.kind
    }));

    let template: Template;

    beforeEach(() => {
      const stack = new PepStack(app, 'PepStack', {
        config: { rules: genaiRules }
      }, { ...cdkEnv, region });
      template = Template.fromStack(stack);
    });

    test('creates each managed GenAI rule', () => {
      const managed = genaiEntries.filter((entry) => entry.kind === 'managed');
      managed.forEach((entry) => {
        template.hasResourceProperties('AWS::Config::ConfigRule', {
          Source: { Owner: 'AWS', SourceIdentifier: entry.id }
        });
      });
    });

    test('creates each custom GenAI rule', () => {
      const expectedCustomNames = new Map<string, string>([
        ['S3_ENCRYPTED_WITH_CMK', 's3-cmk-encryption-check'],
        ['BEDROCK_GUARDRAILS_CHECK', 'bedrock-guardrails-check']
      ]);

      genaiEntries
        .filter((entry) => entry.kind === 'custom')
        .forEach((entry) => {
          const name = expectedCustomNames.get(entry.id);
          if (!name) {
            throw new Error(`Test fixture missing expected name for custom rule ${entry.id}`);
          }
          template.hasResourceProperties('AWS::Config::ConfigRule', {
            Source: { Owner: 'CUSTOM_LAMBDA' },
            ConfigRuleName: name
          });
        });
    });

    test('creates one SERVICE_VPC_ENDPOINT_ENABLED rule per VPC endpoint entry', () => {
      genaiEntries
        .filter((entry) => entry.kind === 'vpc-endpoint')
        .forEach((entry) => {
          if (entry.kind !== 'vpc-endpoint') {
            return;
          }
          template.hasResourceProperties('AWS::Config::ConfigRule', {
            Source: { Owner: 'AWS', SourceIdentifier: 'SERVICE_VPC_ENDPOINT_ENABLED' },
            InputParameters: { serviceName: getVpcEndpointServiceName(entry, region) }
          });
        });
    });

    test('total number of config rules matches catalog selection', () => {
      template.resourceCountIs('AWS::Config::ConfigRule', genaiEntries.length);
    });
  });

  /**
   * Catalog hygiene tests.
   */
  describe('Catalog hygiene', () => {

    test('every entry id is unique', () => {
      const ids = RULE_CATALOG.map((entry) => entry.id);
      expect(new Set(ids).size).toBe(ids.length);
    });

    test('every entry is surfaced through at least one screen', () => {
      RULE_CATALOG.forEach((entry) => {
        expect(Object.keys(entry.categories).length).toBeGreaterThan(0);
      });
    });
  });

  /**
   * Dev-environment tests.
   */
  describe('Dev environment', () => {

    test.each([
      ['omitted', {}],
      ['enabled=false', { devEnvironment: { enabled: false, diskSpaceGb: 50 } }]
    ])('%s produces no instance and no secret', (_label, config) => {
      const stack = new PepStack(app, 'PepStack', config, cdkEnv);
      const template = Template.fromStack(stack);
      template.resourceCountIs('AWS::EC2::Instance', 0);
      template.resourceCountIs('AWS::SecretsManager::Secret', 0);
    });

    test('code-server mode creates a secret, an instance, and three outputs', () => {
      const stack = new PepStack(app, 'PepStack', {
        devEnvironment: { enabled: true, ideType: 'code-server', diskSpaceGb: 50 }
      }, cdkEnv);
      const template = Template.fromStack(stack);
      template.resourceCountIs('AWS::EC2::Instance', 1);
      template.resourceCountIs('AWS::SecretsManager::Secret', 1);
      template.hasOutput('*', { Description: Match.stringLikeRegexp('SSM port forwarding') });
      template.hasOutput('*', { Description: Match.stringLikeRegexp('VS Code server password') });
      template.hasOutput('*', { Description: Match.stringLikeRegexp('Localhost URL') });
    });

    test('vscode-ssh mode skips the secret and emits a single SSH output', () => {
      const stack = new PepStack(app, 'PepStack', {
        devEnvironment: { enabled: true, ideType: 'vscode-ssh', diskSpaceGb: 50 }
      }, cdkEnv);
      const template = Template.fromStack(stack);
      template.resourceCountIs('AWS::EC2::Instance', 1);
      template.resourceCountIs('AWS::SecretsManager::Secret', 0);
      template.hasOutput('*', { Description: Match.stringLikeRegexp('SSM for VS Code SSH') });
    });

    test('security defaults: IMDSv2 + EBS encryption', () => {
      const stack = new PepStack(app, 'PepStack', {
        devEnvironment: { enabled: true, ideType: 'code-server', diskSpaceGb: 50 }
      }, cdkEnv);
      const template = Template.fromStack(stack);

      template.hasResourceProperties('AWS::EC2::LaunchTemplate', {
        LaunchTemplateData: Match.objectLike({
          MetadataOptions: { HttpTokens: 'required' }
        })
      });

      template.hasResourceProperties('AWS::EC2::Instance', {
        BlockDeviceMappings: Match.arrayWith([
          Match.objectLike({ Ebs: Match.objectLike({ Encrypted: true }) })
        ])
      });
    });
  });
});
