import { describe, test, expect } from 'vitest';

import { isValidRoleArn, parseRoleArn } from '../helpers/iam-arn';

describe('parseRoleArn', () => {

  /**
   * A standard commercial-partition role ARN parses into its
   * components.
   */
  test('parses a valid role ARN', () => {
    const parsed = parseRoleArn('arn:aws:iam::123456789012:role/PrototypeAccess');
    expect(parsed).toEqual({
      arn: 'arn:aws:iam::123456789012:role/PrototypeAccess',
      accountId: '123456789012',
      roleName: 'PrototypeAccess',
      partition: 'aws'
    });
  });

  /**
   * Role paths are preserved in the role name, and non-commercial
   * partitions are reported faithfully.
   */
  test('handles role paths and alternate partitions', () => {
    const parsed = parseRoleArn('arn:aws-cn:iam::123456789012:role/team/Deployer');
    expect(parsed?.partition).toBe('aws-cn');
    expect(parsed?.roleName).toBe('team/Deployer');
    expect(parsed?.accountId).toBe('123456789012');
  });

  /**
   * Non-role IAM resources (users, groups) are rejected.
   */
  test('rejects non-role IAM resources', () => {
    expect(parseRoleArn('arn:aws:iam::123456789012:user/bob')).toBeUndefined();
    expect(parseRoleArn('arn:aws:iam::123456789012:group/admins')).toBeUndefined();
  });

  /**
   * STS assumed-role ARNs are not IAM role ARNs.
   */
  test('rejects STS assumed-role ARNs', () => {
    expect(parseRoleArn('arn:aws:sts::123456789012:assumed-role/Role/session')).toBeUndefined();
  });

  /**
   * The account id must be exactly 12 digits.
   */
  test('rejects malformed account ids', () => {
    expect(parseRoleArn('arn:aws:iam::123:role/Short')).toBeUndefined();
    expect(parseRoleArn('arn:aws:iam::abcdefghijkl:role/NotDigits')).toBeUndefined();
  });

  /**
   * Garbage and empty input return undefined rather than throwing.
   */
  test('rejects non-ARN and empty input', () => {
    expect(parseRoleArn('not-an-arn')).toBeUndefined();
    expect(parseRoleArn('')).toBeUndefined();
    expect(parseRoleArn(undefined)).toBeUndefined();
  });
});

describe('isValidRoleArn', () => {

  /**
   * The boolean guard mirrors `parseRoleArn`'s verdict.
   */
  test('returns true only for valid role ARNs', () => {
    expect(isValidRoleArn('arn:aws:iam::123456789012:role/PrototypeAccess')).toBe(true);
    expect(isValidRoleArn('arn:aws:iam::123456789012:user/bob')).toBe(false);
    expect(isValidRoleArn(undefined)).toBe(false);
  });
});
