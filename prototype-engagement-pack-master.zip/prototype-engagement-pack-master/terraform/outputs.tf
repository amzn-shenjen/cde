# =============================================================================
# Root outputs
# =============================================================================

output "kms_key_arn" {
  description = "ARN of the PEP Customer Managed Key."
  value       = module.kms.key_arn
}

output "sns_topic_arn" {
  description = "ARN of the centralized SNS notification topic."
  value       = local.sns_required ? module.sns[0].topic_arn : null
}

output "cloudtrail_bucket_name" {
  description = "Name of the CloudTrail S3 bucket."
  value       = var.cloudtrail != null ? module.cloudtrail[0].trail_bucket_name : null
}

output "cloudtrail_log_group_name" {
  description = "Name of the CloudTrail CloudWatch log group."
  value       = var.cloudtrail != null ? module.cloudtrail[0].log_group_name : null
}

output "vpc_id" {
  description = "ID of the VPC (if created)."
  value       = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].vpc_id : null
}

output "cross_account_role_arn" {
  description = "ARN of the cross-account IAM role."
  value       = var.engagement != null ? module.cross_account_role[0].role_arn : null
}

output "guardduty_detector_id" {
  description = "GuardDuty detector ID."
  value       = var.guardduty != null ? module.guardduty[0].detector_id : null
}

# Dev environment outputs
output "dev_instance_id" {
  description = "EC2 instance ID for the development environment."
  value       = var.dev_environment != null && var.dev_environment.enabled ? module.dev_environment[0].instance_id : null
}

output "dev_ssm_command" {
  description = "AWS CLI command to start an SSM session to the dev instance."
  value       = var.dev_environment != null && var.dev_environment.enabled ? module.dev_environment[0].ssm_command : null
}

output "dev_code_server_url" {
  description = "Local URL for code-server after SSM port-forwarding."
  value = (
    var.dev_environment != null && var.dev_environment.enabled && var.dev_environment.ide_type == "code-server"
    ? module.dev_environment[0].code_server_url
    : null
  )
}
