<div align="center">
  <img width="200" src="../assets/icon.png" />
</div>

# Prototype Engagement Pack — Terraform

> The Prototype Engagement Pack for Terraform is a Terraform project used to create secure prototyping sandbox environments.

Current version: **3.4.0**

> 🧰 This is the **Terraform** flavor of the Prototype Engagement Pack. An **AWS CDK** flavor deploying the same components is available at the [root of this project](../README.md). Use the one matching the Infrastructure-as-Code toolchain preferred for the sandbox account.

## 📋 Table of content

- [Prototype Engagement Pack — Terraform](#prototype-engagement-pack--terraform)
  - [📋 Table of content](#-table-of-content)
  - [🚀 Tutorial](#-tutorial)
  - [🎒 Requirements](#-requirements)
  - [🔰 Description](#-description)
  - [📘 Architecture](#-architecture)
    - [Using VPC Endpoints](#using-vpc-endpoints)
  - [🖥️ Development Environment](#️-development-environment)
  - [👀 See Also](#-see-also)

## 🚀 Tutorial

Before getting started, verify that your configuration matches the [list of requirements](#-requirements) for the Prototype Engagement Pack. If you do not want to use your computer for deploying the Prototype Engagement Pack, you can use [AWS CloudShell](https://docs.aws.amazon.com/cloudshell/latest/userguide/welcome.html) which comes preconfigured with the AWS CLI.

Run the built-in wizard which will prompt you with questions on the type of configuration you would like to apply to the sandbox environment.

```bash
./wizard.sh
```

> On Windows, you can use the `wizard.ps1` PowerShell script instead.

The wizard will then generate a configuration in the `pep.auto.tfvars.json` file that Terraform will automatically pick up. You can now initialize and deploy the Prototype Engagement Pack.

```bash
terraform init
```

Once initialized, you can deploy the Prototype Engagement Pack using the following command.

```bash
terraform apply
```

> Terraform will create resources directly on the sandbox account based on the currently configured AWS credentials and region. You can view the deployed resources in the [AWS Console](https://console.aws.amazon.com/).

Whenever the prototype comes to an end, you need to remove the Prototype Engagement Pack from the sandbox account and all the resources it has deployed. To do so, use the following command.

```bash
terraform destroy
```

## 🎒 Requirements

- A dedicated AWS Account and a deployment machine that must be able to deploy on this account. ([How to create an AWS account](https://aws.amazon.com/premiumsupport/knowledge-center/create-and-activate-aws-account/?nc1=h_ls) | [How to create an AWS Organization account](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_accounts_create.html))
- [NodeJS 20+](https://nodejs.org/en/) must be installed on the deployment machine to run the built-in wizard. ([Instructions](https://nodejs.org/en/download/))
- [Terraform 1.9+](https://www.terraform.io/) must be installed on the deployment machine. ([Instructions](https://developer.hashicorp.com/terraform/install))
- The [AWS CLI](https://aws.amazon.com/cli/) must be installed and configured on the deployment machine. ([Instructions](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html))
- The [AWS Config](https://aws.amazon.com/en/config/) service must be enabled on the target account and recording must be turned on if you would like to use AWS Config rules. ([Instructions](https://docs.aws.amazon.com/config/latest/developerguide/gs-console.html)). *The AWS Config configuration **should** include **global resources** (e.g., AWS IAM resources) to make them discovered by the service and to run rules over them.*
- IAM access to billing must be enabled if you would like to create and manage AWS Budgets. ([Instructions](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/control-access-billing.html#ControllingAccessWebsite-Activate))
- When you deploy the PEP, you are required to provide email addresses for email notifications. Notifications are sent when there are Budget alerts or AWS Config Rule alerts. For this to work correctly, the *sender* email that you choose needs to be verified by AWS SNS. If you select a customer email address to be the *sender*, please inform them that they need to verify their email, this is done by responding to the email that AWS SNS sends you. Sender email addresses can also be verified via the AWS Console in the customer sandbox account. If you do not verify the sender email, you will not receive email notifications.
- AWS account credentials should be configured in your environment. AWS CloudShell does this automatically for you. If you are deploying from your laptop/PC or another environment make sure the account credentials and regions are [configured correctly](https://docs.aws.amazon.com/cli/v1/userguide/cli-configure-files.html).

## 🔰 Description

The Prototype Engagement Pack is a configurable and modular [Terraform](https://www.terraform.io/) project that can be used to secure the environment of a sandbox account during prototyping activities. It can conditionally upon selection using the Prototype Engagement Pack Wizard enable the deployment of the following components on a sandbox account.

- The IAM role allowing cross-account access between an AWS internal account and the sandbox account. ([More information](./docs/components.md#cross-account-role))
- A set of AWS Config rules monitoring compliance in the sandbox account. ([More information](./docs/components.md#aws-config-rules))
- A set of AWS Config remediation actions automatically executed when one of the AWS Config rules detects non-compliance (today, remediations include automatic protection of public S3 buckets).
- An AWS Budget dedicated to the prototype defining a cost threshold not to be exceeded during the prototype.
- Notification mechanisms that will alert the customer, the AWS engineer(s) and the engagement manager of potential security threats through E-mails, Slack, or Teams Notifications.
- A CloudTrail trail that logs all the actions occurring on the sandbox account in an encrypted bucket for traceability purposes. ([More information](./docs/components.md#aws-cloudtrail-audit-log))
- A set of additional security perimeter measures used to further improve the security of the sandbox account. ([More information](./docs/security-perimeter-rules.md))

## 📘 Architecture

Below is the architecture diagram describing the resources that the Prototype Engagement Pack can create depending on the selected options.

<div align="center">
  <img src="../assets/diagrams/security-diagram.png" />
  <div align="center"><sub>The Prototype Engagement Pack (click to enlarge)</sub></div>
</div>

### Using VPC Endpoints

Some customers have hard requirements on using exclusively internal traffic to the AWS Cloud for security and compliance reasons. For this reason, the Prototype Engagement Pack has a feature that can be enabled to place Lambda functions within a VPC and creates the required VPC Endpoints to allow these Lambda functions to interact with AWS services.

<div align="center">
  <img src="../assets/diagrams/security-diagram-vpc.png" />
  <div align="center"><sub>The Prototype Engagement Pack with VPC Endpoints</sub></div>
</div>

## 🖥️ Development Environment

The Prototype Engagement Pack also includes an optional **Development Environment** module that provisions a secure, cloud-based VS Code server running inside the customer's sandbox account, with development tools pre-installed and access over SSM port forwarding (no direct internet access required). It is enabled through the wizard.

> For features, architecture, and connection instructions, see the [Development Environment documentation](../docs/dev-environment.md).

## 👀 See Also

- The [Components](docs/components.md) documentation.
- The [Security Perimeter Rules](docs/security-perimeter-rules.md) documentation.
- The [License](LICENSE) of the project.
