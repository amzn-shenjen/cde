# Partition, region, and currency detection.

data "aws_partition" "current" {}
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.region
  partition  = data.aws_partition.current.partition

  # Currency per partition.
  currency = {
    "aws"        = "USD"
    "aws-cn"     = "CNY"
    "aws-us-gov" = "USD"
    "aws-eusc"   = "EUR"
  }[local.partition]

  # AWS Budgets is only available in the commercial partition
  budgets_available = local.partition == "aws"

  is_china    = local.partition == "aws-cn"
  is_govcloud = local.partition == "aws-us-gov"
  is_eusc     = local.partition == "aws-eusc"

  # Whether GuardDuty is enabled in this deployment.
  guardduty_enabled = var.guardduty != null && var.guardduty.enabled

  # GuardDuty service principal differs in China
  guardduty_principal = local.is_china ? "guardduty.amazonaws.com.cn" : "guardduty.amazonaws.com"

  # Public AWS console host per partition.
  console_host = {
    "aws"        = "console.aws.amazon.com"
    "aws-cn"     = "console.amazonaws.cn"
    "aws-us-gov" = "console.amazonaws-us-gov.com"
    "aws-eusc"   = "console.amazonaws.eu"
  }[local.partition]

  # Determine which features need the SNS topic
  sns_required = (
    var.budget != null ||
    local.guardduty_enabled ||
    var.config != null ||
    var.notification != null ||
    var.security_policies != null
  )

  # True when at least one component is configured
  has_configuration = (
    var.engagement != null ||
    var.config != null ||
    var.budget != null ||
    local.guardduty_enabled ||
    var.inspector != null ||
    var.cloudtrail != null ||
    var.security_policies != null ||
    var.dev_environment != null
  )
}

# Wizard check.
# This check ensures that the user has run the configuration wizard,
# which generates the necessary configuration for Terraform.

check "wizard_configuration" {
  assert {
    condition     = local.has_configuration
    error_message = <<-EOT
      ⚠️  No components are configured. Did you forget to run the wizard?

          ./wizard.sh

      The wizard generates a pep.auto.tfvars.json file with your configuration.
      Without it, Terraform has nothing to deploy.
    EOT
  }
}
