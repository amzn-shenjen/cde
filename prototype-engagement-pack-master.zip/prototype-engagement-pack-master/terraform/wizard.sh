#!/bin/bash
set -e

# Resolve the repository root regardless of where this script is run from.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Run the unified wizard, telling it to emit a Terraform configuration.
cd "$REPO_ROOT"
npm ci --silent
npx tsx bin/wizard/index.ts \
  --output-format=terraform \
  --output="$SCRIPT_DIR"
