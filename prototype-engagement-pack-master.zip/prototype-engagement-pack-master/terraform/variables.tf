# Engagement / Cross-Account Role.

variable "engagement" {
  description = "Cross-account role configuration for AWS team access."
  type = object({
    role = object({
      trust_mode        = string
      source_account_id = string
      source_role_arn   = optional(string, "")
      source_usernames  = optional(list(string), [])
      managed_policies  = optional(list(string), [])
    })
    start = string
    end   = string
  })
  default = null

  validation {
    condition     = var.engagement == null || contains(["role", "user", "account"], var.engagement.role.trust_mode)
    error_message = "engagement.role.trust_mode must be 'role', 'user' or 'account'."
  }

  validation {
    condition = (
      var.engagement == null
      || var.engagement.role.trust_mode != "role"
      || can(regex("^arn:aws[a-z-]*:iam::[0-9]{12}:role/.+$", var.engagement.role.source_role_arn))
    )
    error_message = "engagement.role.source_role_arn must be a valid IAM role ARN when trust_mode is 'role'."
  }

  # IAM caps a role trust policy at 2048 characters, which five user
  # ARNs fit inside.
  # See here for a documentation on the quotas https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_iam-quotas.html
  validation {
    condition = (
      var.engagement == null
      || var.engagement.role.trust_mode != "user"
      || (
        length(var.engagement.role.source_usernames) >= 1
        && length(var.engagement.role.source_usernames) <= 5
      )
    )
    error_message = "engagement.role.source_usernames must hold between 1 and 5 IAM user names when trust_mode is 'user'."
  }

  validation {
    condition = (
      var.engagement == null
      || var.engagement.role.trust_mode != "user"
      || alltrue([
        for username in var.engagement.role.source_usernames :
        can(regex("^[\\w+=,.@-]{1,64}$", username))
      ])
    )
    error_message = "engagement.role.source_usernames must contain valid IAM user names when trust_mode is 'user'."
  }

  validation {
    condition = (
      var.engagement == null
      || var.engagement.role.trust_mode != "user"
      || length(distinct([for username in var.engagement.role.source_usernames : lower(username)])) == length(var.engagement.role.source_usernames)
    )
    error_message = "engagement.role.source_usernames must not contain duplicates."
  }
}

# Network.

variable "network" {
  description = "VPC endpoint configuration for private connectivity."
  type = object({
    use_vpc_endpoints = optional(bool, false)
  })
  default = null
}

# Security Policies. The CDK variant also exposes `enable_stack_protection`,
# which guards a CloudFormation stack from accidental deletion. Terraform has
# no stack-level construct, so the equivalent isn't surfaced here — protect
# individual resources via `lifecycle.prevent_destroy` if needed.

variable "security_policies" {
  description = "Account-wide security guardrails."
  type = object({
    enable_s3_public_access_block    = optional(bool, true)
    enable_large_instance_protection = optional(bool, false)
  })
  default = null
}

# CloudTrail.

variable "cloudtrail" {
  description = "AWS CloudTrail audit logging configuration."
  type = object({
    multi_region = optional(bool, true)
  })
  default = null
}

# AWS Config Rules. The wizard's `config` and `genai` screens both
# write into this single deduped array; each entry self-describes
# its kind so the module dispatches without separate buckets.
#
# `id` must match an entry in the wizard's catalog
# (`lib/constructs/config/catalog.ts`).

variable "config" {
  description = "AWS Config rules — managed, custom Lambda-backed, and VPC endpoint."
  type = object({
    rules = list(object({
      id                 = string
      kind               = string
      enable_remediation = optional(bool, false)
    }))
  })
  default = null

  validation {
    condition = var.config == null || alltrue([
      for r in var.config.rules : contains(["managed", "custom", "vpc-endpoint"], r.kind)
    ])
    error_message = "Each rule's `kind` must be one of 'managed', 'custom', or 'vpc-endpoint'."
  }
}

# Budget.

variable "budget" {
  description = "AWS Budgets monthly spending limit."
  type = object({
    limit = number
  })
  default = null

  validation {
    condition     = var.budget == null || var.budget.limit > 0
    error_message = "Budget limit must be a positive number."
  }
}

# GuardDuty.

variable "guardduty" {
  description = "Amazon GuardDuty threat detection configuration."
  type = object({
    enabled = bool
  })
  default = null
}

# Inspector.

variable "inspector" {
  description = "Amazon Inspector vulnerability scanning."
  type = object({
    enabled = optional(bool, true)
  })
  default = null
}

# Notification.

variable "notification" {
  description = "Notification channel configuration."
  type = object({
    email = optional(object({
      sender  = string
      targets = list(string)
    }), null)
    slack = optional(object({
      slack_channel_id   = string
      slack_workspace_id = string
    }), null)
    teams = optional(object({
      webhook_url = string
    }), null)
  })
  default = null
}

# Development Environment.

variable "dev_environment" {
  description = "Cloud-based development environment configuration."
  type = object({
    enabled           = optional(bool, true)
    disk_space_gb     = optional(number, 50)
    instance_type     = optional(string, "m5.xlarge")
    ide_type          = optional(string, "code-server") # "code-server" or "vscode-ssh"
    vpc_id            = optional(string, null)
    subnet_id         = optional(string, null)
    availability_zone = optional(string, null)
  })
  default = null

  validation {
    condition     = var.dev_environment == null || (var.dev_environment.disk_space_gb >= 8 && var.dev_environment.disk_space_gb <= 200)
    error_message = "Disk space must be between 8 and 200 GB."
  }

  validation {
    condition     = var.dev_environment == null || contains(["m5.large", "m5.xlarge", "m5.2xlarge"], var.dev_environment.instance_type)
    error_message = "Instance type must be m5.large, m5.xlarge, or m5.2xlarge."
  }

  validation {
    condition     = var.dev_environment == null || contains(["code-server", "vscode-ssh"], var.dev_environment.ide_type)
    error_message = "IDE type must be 'code-server' or 'vscode-ssh'."
  }
}

# Tags.

variable "tags" {
  description = "Tags to apply to all resources."
  type        = map(string)
  default     = {}
}
