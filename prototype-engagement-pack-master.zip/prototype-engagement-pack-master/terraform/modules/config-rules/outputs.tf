output "managed_rule_arns" {
  description = "ARNs of the managed Config rules."
  value       = { for k, v in aws_config_config_rule.managed : k => v.arn }
}
