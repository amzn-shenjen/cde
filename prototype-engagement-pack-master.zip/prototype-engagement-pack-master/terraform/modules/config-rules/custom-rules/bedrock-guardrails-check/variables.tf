# Custom Config Rule — Bedrock Guardrails Check

variable "kms_key_arn" {
  type = string
}

variable "vpc_id" {
  type    = string
  default = null
}

variable "private_subnet_ids" {
  type    = list(string)
  default = []
}
