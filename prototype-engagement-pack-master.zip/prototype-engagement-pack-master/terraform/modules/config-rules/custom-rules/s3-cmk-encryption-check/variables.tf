# Custom Config Rule — S3 CMK Encryption Check

variable "kms_key_arn" {
  type = string
}

variable "vpc_id" {
  type    = string
  default = null
}

variable "private_subnet_ids" {
  type    = list(string)
  default = []
}
