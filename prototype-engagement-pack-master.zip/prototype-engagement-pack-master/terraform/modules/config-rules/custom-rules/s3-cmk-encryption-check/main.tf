resource "aws_security_group" "lambda" {
  # checkov:skip=CKV2_AWS_5:SG bound via the vpc_config in the Lambda module.
  # checkov:skip=CKV_AWS_382:Reaches S3, KMS and Config APIs not fronted by endpoints.
  count       = var.vpc_id != null ? 1 : 0
  name_prefix = "pep-config-s3-cmk-check-"
  description = "Security group for S3 CMK encryption check Lambda"
  vpc_id      = var.vpc_id

  egress {
    description = "Allow Lambda outbound to AWS APIs (S3, KMS, Config) over the VPC."
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

module "lambda" {
  # terraform-aws-modules/terraform-aws-lambda v8.8.0
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=b842374147fc07731d79028517223e9e0cbaab6d"

  function_name                     = "pep-config-s3-cmk-encryption-check"
  description                       = "Checks if S3 buckets are encrypted with Customer Managed Keys"
  handler                           = "index.handler"
  runtime                           = "nodejs24.x"
  timeout                           = 30
  memory_size                       = 128
  kms_key_arn                       = var.kms_key_arn
  cloudwatch_logs_retention_in_days = 30

  source_path = [{
    path = "${path.module}/../../../../../lib/lambdas/custom-config-rules/s3-cmk-encryption-check"
    commands = [
      "npx --yes esbuild@0.25.5 index.ts --platform=node --bundle --target=node24 --external:@aws-sdk/* --minify --outdir=dist",
      ":zip dist",
    ]
  }]

  # VPC
  vpc_subnet_ids         = var.vpc_id != null ? var.private_subnet_ids : null
  vpc_security_group_ids = var.vpc_id != null ? [aws_security_group.lambda[0].id] : null
  attach_network_policy  = var.vpc_id != null

  # IAM
  attach_policy_json = true
  policy_json = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "s3:GetBucketEncryption",
        "s3:GetEncryptionConfiguration",
        "kms:DescribeKey",
        "config:PutEvaluations",
      ]
      Resource = "*"
    }]
  })

  # Allow Config to invoke
  create_current_version_allowed_triggers = false
  allowed_triggers = {
    config = {
      principal = "config.amazonaws.com"
    }
  }
}

resource "aws_config_config_rule" "this" {
  name = "s3-cmk-encryption-check"

  source {
    owner             = "CUSTOM_LAMBDA"
    source_identifier = module.lambda.lambda_function_arn

    source_detail {
      message_type = "ConfigurationItemChangeNotification"
    }
  }

  scope {
    compliance_resource_types = ["AWS::S3::Bucket"]
  }

  depends_on = [module.lambda]
}
