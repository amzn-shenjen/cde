# modules/config-rules

# Bucketing the unified rules array by kind for the resource for_each
# expressions below.
locals {
  managed_rules      = [for r in var.rules : r if r.kind == "managed"]
  vpc_endpoint_rules = [for r in var.rules : r if r.kind == "vpc-endpoint"]
  custom_rule_ids    = toset([for r in var.rules : r.id if r.kind == "custom"])
  ecr_prefix         = var.is_eusc ? "eu" : "com"
}

# -----------------------------------------------------------------------------
# Managed Config Rules
# -----------------------------------------------------------------------------

resource "aws_config_config_rule" "managed" {
  for_each = { for r in local.managed_rules : r.id => r }

  name = lower(replace(each.value.id, "_", "-"))

  source {
    owner             = "AWS"
    source_identifier = each.value.id
  }
}

# -----------------------------------------------------------------------------
# VPC Endpoint Rules
# -----------------------------------------------------------------------------

resource "aws_config_config_rule" "vpc_endpoint" {
  for_each = { for r in local.vpc_endpoint_rules : r.id => r }

  name = lower(replace(each.value.id, "_", "-"))

  source {
    owner             = "AWS"
    source_identifier = "SERVICE_VPC_ENDPOINT_ENABLED"
  }

  input_parameters = jsonencode({
    serviceName = "${startswith(each.value.service, "ecr.") ? local.ecr_prefix : "com"}.amazonaws.${var.region}.${each.value.service}"
  })
}

# -----------------------------------------------------------------------------
# S3 Public Access Remediation
# -----------------------------------------------------------------------------

locals {
  s3_public_remediated_rules = [
    for r in local.managed_rules : r
    if contains(["S3_BUCKET_PUBLIC_READ_PROHIBITED", "S3_BUCKET_PUBLIC_WRITE_PROHIBITED"], r.id)
    && r.enable_remediation
    && !var.is_eusc
  ]
}

resource "aws_iam_role" "remediation" {
  count = length(local.s3_public_remediated_rules) > 0 ? 1 : 0

  name               = "pep-config-remediation-role"
  assume_role_policy = data.aws_iam_policy_document.remediation_assume[0].json
}

data "aws_iam_policy_document" "remediation_assume" {
  count = length(local.s3_public_remediated_rules) > 0 ? 1 : 0

  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["ssm.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role_policy_attachment" "remediation_ssm" {
  count = length(local.s3_public_remediated_rules) > 0 ? 1 : 0

  role       = aws_iam_role.remediation[0].name
  policy_arn = "arn:${var.partition}:iam::aws:policy/service-role/AmazonSSMAutomationRole"
}

resource "aws_iam_role_policy" "remediation_s3" {
  count = length(local.s3_public_remediated_rules) > 0 ? 1 : 0

  name   = "s3-remediation"
  role   = aws_iam_role.remediation[0].id
  policy = data.aws_iam_policy_document.remediation_s3[0].json
}

data "aws_iam_policy_document" "remediation_s3" {
  count = length(local.s3_public_remediated_rules) > 0 ? 1 : 0

  # checkov:skip=CKV_AWS_109:Remediation must reach any public bucket account-wide.
  # checkov:skip=CKV_AWS_356:Remediation must reach any public bucket account-wide.
  statement {
    effect = "Allow"
    actions = [
      "s3:GetBucketAcl",
      "s3:GetBucketPolicy",
      "s3:PutBucketAcl",
      "s3:PutBucketPolicy",
      "s3:PutBucketPublicAccessBlock",
    ]
    resources = ["*"]
  }
}

resource "aws_config_remediation_configuration" "s3_public" {
  for_each = { for r in local.s3_public_remediated_rules : r.id => r }

  config_rule_name = lower(replace(each.value.id, "_", "-"))
  target_type      = "SSM_DOCUMENT"
  target_id        = "AWS-DisableS3BucketPublicReadWrite"
  automatic        = true

  maximum_automatic_attempts = 5
  retry_attempt_seconds      = 60

  parameter {
    name         = "AutomationAssumeRole"
    static_value = aws_iam_role.remediation[0].arn
  }

  parameter {
    name           = "S3BucketName"
    resource_value = "RESOURCE_ID"
  }

  depends_on = [aws_config_config_rule.managed]
}

# -----------------------------------------------------------------------------
# EventBridge — Config compliance changes → SNS
# -----------------------------------------------------------------------------

resource "aws_cloudwatch_event_rule" "config_compliance" {
  name        = "pep-config-compliance-changes"
  description = "Listens to events sent by AWS Config on compliance updates."

  event_pattern = jsonencode({
    source      = ["aws.config"]
    detail-type = ["Config Rules Compliance Change"]
    detail = {
      newEvaluationResult = {
        complianceType = ["NON_COMPLIANT"]
      }
    }
  })
}

resource "aws_cloudwatch_event_target" "config_sns" {
  rule      = aws_cloudwatch_event_rule.config_compliance.name
  target_id = "config-to-sns"
  arn       = var.sns_topic_arn
}

# -----------------------------------------------------------------------------
# Custom Config Rules
# -----------------------------------------------------------------------------

module "s3_cmk_check" {
  source = "./custom-rules/s3-cmk-encryption-check"
  count  = contains(local.custom_rule_ids, "S3_ENCRYPTED_WITH_CMK") ? 1 : 0

  kms_key_arn        = var.kms_key_arn
  vpc_id             = var.vpc_id
  private_subnet_ids = var.private_subnet_ids
}

module "bedrock_guardrails_check" {
  source = "./custom-rules/bedrock-guardrails-check"
  count  = contains(local.custom_rule_ids, "BEDROCK_GUARDRAILS_CHECK") ? 1 : 0

  kms_key_arn        = var.kms_key_arn
  vpc_id             = var.vpc_id
  private_subnet_ids = var.private_subnet_ids
}
