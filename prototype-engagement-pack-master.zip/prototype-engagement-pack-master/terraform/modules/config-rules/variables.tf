# modules/config-rules

variable "rules" {
  description = "Self-describing AWS Config rules. Dispatched on `kind`."
  type = list(object({
    id                 = string
    kind               = string                # "managed" | "custom" | "vpc-endpoint"
    enable_remediation = optional(bool, false) # only honoured for managed rules
    service            = optional(string)      # required for `vpc-endpoint` entries
  }))
  default = []
}

variable "sns_topic_arn" {
  type = string
}

variable "kms_key_arn" {
  type = string
}

variable "partition" {
  type = string
}

variable "region" {
  type = string
}

variable "account_id" {
  type = string
}

variable "is_eusc" {
  type    = bool
  default = false
}

variable "vpc_id" {
  description = "VPC ID for Lambda functions (null = no VPC)."
  type        = string
  default     = null
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Lambda functions."
  type        = list(string)
  default     = []
}
