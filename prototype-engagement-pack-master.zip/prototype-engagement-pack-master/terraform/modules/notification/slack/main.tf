# modules/notification/slack — AWS Chatbot SNS → Slack integration

resource "aws_iam_role" "chatbot" {
  name               = "pep-chatbot-slack-role"
  assume_role_policy = data.aws_iam_policy_document.chatbot_assume.json
}

data "aws_iam_policy_document" "chatbot_assume" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["chatbot.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_chatbot_slack_channel_configuration" "this" {
  configuration_name = "slack-prototype-${var.region}"
  iam_role_arn       = aws_iam_role.chatbot.arn
  slack_channel_id   = var.slack_channel_id
  slack_team_id      = var.slack_workspace_id
  sns_topic_arns     = [var.sns_topic_arn]

  logging_level = "NONE"
}
