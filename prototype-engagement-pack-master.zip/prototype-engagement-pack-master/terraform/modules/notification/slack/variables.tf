# modules/notification/slack

variable "slack_channel_id" {
  description = "Slack channel ID."
  type        = string
}

variable "slack_workspace_id" {
  description = "Slack workspace ID."
  type        = string
}

variable "sns_topic_arn" {
  type = string
}

variable "region" {
  type = string
}
