output "chatbot_arn" {
  description = "ARN of the Chatbot Slack channel configuration."
  value       = aws_chatbot_slack_channel_configuration.this.chat_configuration_arn
}
