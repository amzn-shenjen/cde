# modules/notification/email

variable "sender" {
  description = "Sender email address."
  type        = string
}

variable "targets" {
  description = "List of recipient email addresses."
  type        = list(string)
}

variable "sns_topic_arn" {
  type = string
}

variable "kms_key_arn" {
  type = string
}

variable "region" {
  type = string
}

variable "account_id" {
  type = string
}

variable "vpc_id" {
  type    = string
  default = null
}

variable "private_subnet_ids" {
  type    = list(string)
  default = []
}
