# modules/notification/email — SES identity verification + Lambda transformer

locals {
  all_emails = distinct(concat([var.sender], var.targets))
}

data "aws_partition" "current" {}

# SES Email Identity Verification.

resource "aws_ses_email_identity" "this" {
  for_each = toset(local.all_emails)
  email    = each.value
}

# Lambda — SNS → SES email transformer.

resource "aws_security_group" "lambda" {
  # checkov:skip=CKV2_AWS_5:SG bound via the vpc_config in the Lambda module.
  # checkov:skip=CKV_AWS_382:SES API has no PrivateLink endpoint; egress required.
  count       = var.vpc_id != null ? 1 : 0
  name_prefix = "pep-email-transformer-"
  description = "Security group for email transformer Lambda"
  vpc_id      = var.vpc_id

  egress {
    description = "Allow Lambda outbound to AWS APIs (SES, SNS, KMS) over the VPC."
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

module "transformer" {
  # terraform-aws-modules/terraform-aws-lambda v8.8.0
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=b842374147fc07731d79028517223e9e0cbaab6d"

  function_name                     = "pep-email-transformer"
  description                       = "Transforms SNS notifications to email via SES"
  handler                           = "index.handler"
  runtime                           = "nodejs24.x"
  timeout                           = 30
  memory_size                       = 128
  kms_key_arn                       = var.kms_key_arn
  cloudwatch_logs_retention_in_days = 30

  # Bundle the TS handler with esbuild and ship `static/template.html`
  # alongside it.
  source_path = [{
    path = "${path.module}/../../../../lib/constructs/notification/destinations/email/lambdas/transformer"
    commands = [
      "npx --yes esbuild@0.25.5 index.ts --platform=node --bundle --target=node24 --external:@aws-sdk/* --minify --outdir=dist",
      "mkdir -p dist/static && cp lib/static/template.html dist/static/template.html",
      ":zip dist",
    ]
  }]

  environment_variables = {
    SENDER     = var.sender
    RECIPIENTS = jsonencode(var.targets)
  }

  # VPC.
  vpc_subnet_ids         = var.vpc_id != null ? var.private_subnet_ids : null
  vpc_security_group_ids = var.vpc_id != null ? [aws_security_group.lambda[0].id] : null
  attach_network_policy  = var.vpc_id != null

  # IAM — SES send permissions
  attach_policy_json = true
  policy_json        = data.aws_iam_policy_document.ses_send.json

  # Allow SNS to invoke
  create_current_version_allowed_triggers = false
  allowed_triggers = {
    sns = {
      principal  = "sns.amazonaws.com"
      source_arn = var.sns_topic_arn
    }
  }
}

data "aws_iam_policy_document" "ses_send" {
  statement {
    effect  = "Allow"
    actions = ["ses:SendEmail"]
    resources = [
      for email in local.all_emails :
      "arn:${data.aws_partition.current.partition}:ses:${var.region}:${var.account_id}:identity/${email}"
    ]
  }
}

# SNS Subscription.

resource "aws_sns_topic_subscription" "email" {
  topic_arn = var.sns_topic_arn
  protocol  = "lambda"
  endpoint  = module.transformer.lambda_function_arn
}
