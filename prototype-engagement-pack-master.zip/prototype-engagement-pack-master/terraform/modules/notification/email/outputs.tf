output "lambda_arn" {
  description = "ARN of the email transformer Lambda."
  value       = module.transformer.lambda_function_arn
}
