# modules/notification/teams

variable "webhook_url" {
  description = "Microsoft Teams webhook URL."
  type        = string
  sensitive   = true
}

variable "sns_topic_arn" {
  type = string
}

variable "kms_key_arn" {
  type = string
}

variable "vpc_id" {
  type    = string
  default = null
}

variable "private_subnet_ids" {
  type    = list(string)
  default = []
}
