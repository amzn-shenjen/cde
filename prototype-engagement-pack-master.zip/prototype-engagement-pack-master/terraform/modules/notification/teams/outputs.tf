output "lambda_arn" {
  description = "ARN of the Teams transformer Lambda."
  value       = module.transformer.lambda_function_arn
}
