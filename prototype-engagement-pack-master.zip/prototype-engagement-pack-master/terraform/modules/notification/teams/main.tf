# modules/notification/teams — Lambda SNS → Teams webhook

resource "aws_security_group" "lambda" {
  # checkov:skip=CKV2_AWS_5:SG bound via the vpc_config in the Lambda module.
  # checkov:skip=CKV_AWS_382:Posts to an external Teams webhook; egress required.
  count       = var.vpc_id != null ? 1 : 0
  name_prefix = "pep-teams-transformer-"
  description = "Security group for Teams transformer Lambda"
  vpc_id      = var.vpc_id

  egress {
    description = "Allow Lambda outbound to the Teams webhook URL and AWS APIs."
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

module "transformer" {
  # terraform-aws-modules/terraform-aws-lambda v8.8.0
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=b842374147fc07731d79028517223e9e0cbaab6d"

  function_name                     = "pep-teams-transformer"
  description                       = "Transforms SNS notifications to Teams webhook messages"
  handler                           = "index.handler"
  runtime                           = "nodejs24.x"
  timeout                           = 30
  memory_size                       = 128
  kms_key_arn                       = var.kms_key_arn
  cloudwatch_logs_retention_in_days = 30

  # Bundle the TS handler with esbuild.
  source_path = [{
    path = "${path.module}/../../../../lib/constructs/notification/destinations/teams/lambdas/transformer"
    commands = [
      "npx --yes esbuild@0.25.5 index.ts --platform=node --bundle --target=node24 --external:@aws-sdk/* --minify --outdir=dist",
      ":zip dist",
    ]
  }]

  environment_variables = {
    WEBHOOK = var.webhook_url
  }

  # VPC.
  vpc_subnet_ids         = var.vpc_id != null ? var.private_subnet_ids : null
  vpc_security_group_ids = var.vpc_id != null ? [aws_security_group.lambda[0].id] : null
  attach_network_policy  = var.vpc_id != null

  # Allow SNS to invoke
  create_current_version_allowed_triggers = false
  allowed_triggers = {
    sns = {
      principal  = "sns.amazonaws.com"
      source_arn = var.sns_topic_arn
    }
  }
}

# SNS Subscription.

resource "aws_sns_topic_subscription" "teams" {
  topic_arn = var.sns_topic_arn
  protocol  = "lambda"
  endpoint  = module.transformer.lambda_function_arn
}
