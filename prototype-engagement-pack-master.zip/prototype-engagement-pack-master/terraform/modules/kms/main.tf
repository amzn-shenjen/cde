# modules/kms — Customer Managed Key with service grants

resource "aws_kms_key" "this" {
  description             = "The KMS Customer Managed Key used to encrypt all of the resources created by the Prototype Engagement Pack."
  enable_key_rotation     = true
  deletion_window_in_days = 30
  policy                  = data.aws_iam_policy_document.key_policy.json
}

resource "aws_kms_alias" "this" {
  name          = "alias/pep-cmk"
  target_key_id = aws_kms_key.this.key_id
}

data "aws_iam_policy_document" "key_policy" {
  # Allow full key management by the account root
  # checkov:skip=CKV_AWS_109:Required KMS root statement; wildcard scopes to this key only.
  # checkov:skip=CKV_AWS_111:Required KMS root statement; wildcard scopes to this key only.
  # checkov:skip=CKV_AWS_356:Key-policy wildcard scopes to this key only.
  statement {
    sid    = "EnableRootAccountAccess"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.partition}:iam::${var.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  # Budgets
  dynamic "statement" {
    for_each = var.enable_budget_grant ? [1] : []
    content {
      sid    = "AllowBudgetsEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["budgets.amazonaws.com"]
      }
      actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = ["*"]
    }
  }

  # GuardDuty
  dynamic "statement" {
    for_each = var.enable_guardduty_grant ? [1] : []
    content {
      sid    = "AllowGuardDutyEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = [var.guardduty_principal]
      }
      actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = ["*"]
    }
  }

  # Config
  dynamic "statement" {
    for_each = var.enable_config_grant ? [1] : []
    content {
      sid    = "AllowConfigEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["config.amazonaws.com"]
      }
      actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = ["*"]
    }
  }

  # EventBridge
  dynamic "statement" {
    for_each = var.enable_events_grant ? [1] : []
    content {
      sid    = "AllowEventBridgeEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["events.amazonaws.com"]
      }
      actions = [
        "kms:Decrypt*",
        "kms:GenerateDataKey*",
      ]
      resources = ["*"]
    }
  }

  # CloudWatch
  dynamic "statement" {
    for_each = var.enable_cloudwatch_grant ? [1] : []
    content {
      sid    = "AllowCloudWatchEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["cloudwatch.amazonaws.com"]
      }
      actions = [
        "kms:Decrypt*",
        "kms:GenerateDataKey*",
      ]
      resources = ["*"]
    }
  }

  # CloudTrail
  dynamic "statement" {
    for_each = var.enable_cloudtrail_grant ? [1] : []
    content {
      sid    = "AllowCloudTrailEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["cloudtrail.amazonaws.com"]
      }
      actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = ["*"]
    }
  }

  # CloudWatch Logs
  dynamic "statement" {
    for_each = var.enable_cloudtrail_grant ? [1] : []
    content {
      sid    = "AllowCloudWatchLogsEncryption"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["logs.${var.region}.amazonaws.com"]
      }
      actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey",
      ]
      resources = ["*"]
      condition {
        test     = "ArnEquals"
        variable = "kms:EncryptionContext:aws:logs:arn"
        values   = ["arn:${var.partition}:logs:${var.region}:${var.account_id}:log-group:*"]
      }
    }
  }
}
