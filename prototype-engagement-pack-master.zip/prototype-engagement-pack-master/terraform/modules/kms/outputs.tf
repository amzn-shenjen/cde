output "key_arn" {
  description = "ARN of the KMS Customer Managed Key."
  value       = aws_kms_key.this.arn
}

output "key_id" {
  description = "ID of the KMS Customer Managed Key."
  value       = aws_kms_key.this.key_id
}
