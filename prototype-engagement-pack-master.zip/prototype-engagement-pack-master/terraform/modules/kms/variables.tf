# modules/kms - Customer Managed Key for PEP resource encryption

variable "partition" {
  type = string
}

variable "region" {
  type = string
}

variable "account_id" {
  type = string
}

variable "guardduty_principal" {
  type    = string
  default = "guardduty.amazonaws.com"
}

variable "enable_budget_grant" {
  type    = bool
  default = false
}

variable "enable_guardduty_grant" {
  type    = bool
  default = false
}

variable "enable_config_grant" {
  type    = bool
  default = false
}

variable "enable_events_grant" {
  type    = bool
  default = false
}

variable "enable_cloudwatch_grant" {
  type    = bool
  default = false
}

variable "enable_cloudtrail_grant" {
  type    = bool
  default = false
}
