output "s3_public_access_block_id" {
  description = "ID of the S3 account public access block."
  value       = var.enable_s3_public_access_block ? aws_s3_account_public_access_block.this[0].id : null
}
