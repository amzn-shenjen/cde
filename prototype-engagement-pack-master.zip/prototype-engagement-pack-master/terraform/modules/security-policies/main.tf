# modules/security-policies — Account-wide security guardrails

# -----------------------------------------------------------------------------
# S3 Account-Level Public Access Block
# -----------------------------------------------------------------------------

resource "aws_s3_account_public_access_block" "this" {
  count = var.enable_s3_public_access_block ? 1 : 0

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# -----------------------------------------------------------------------------
# Large Instance Protection
# -----------------------------------------------------------------------------

resource "aws_cloudwatch_log_metric_filter" "large_instance" {
  count = var.enable_large_instance_protection && var.cloudtrail_log_group_name != null ? 1 : 0

  name           = "pep-large-ec2-instance-usage"
  log_group_name = var.cloudtrail_log_group_name

  pattern = "{ (($.eventName = RunInstances) || ($.eventName = StartInstances)) && (($.requestParameters.instanceType = *.32xlarge) || ($.requestParameters.instanceType = *.24xlarge) || ($.requestParameters.instanceType = *.18xlarge) || ($.requestParameters.instanceType = *.16xlarge) || ($.requestParameters.instanceType = *.12xlarge) || ($.requestParameters.instanceType = *.10xlarge) || ($.requestParameters.instanceType = *.9xlarge) || ($.requestParameters.instanceType = *.8xlarge) || ($.requestParameters.instanceType = *.4xlarge)) }"

  metric_transformation {
    name      = "EC2LargeInstanceEventCount"
    namespace = "CloudTrailMetrics"
    value     = "1"
  }
}

resource "aws_cloudwatch_metric_alarm" "large_instance" {
  count = var.enable_large_instance_protection && var.cloudtrail_log_group_name != null && var.enable_notifications ? 1 : 0

  alarm_name          = "Large EC2 Instance Usage"
  alarm_description   = "A CloudWatch Alarm that triggers if a usage of an EC2 large instance is detected."
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "EC2LargeInstanceEventCount"
  namespace           = "CloudTrailMetrics"
  period              = 60
  statistic           = "Sum"
  threshold           = 1
  treat_missing_data  = "missing"

  alarm_actions = [var.sns_topic_arn]
}

