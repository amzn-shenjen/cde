# modules/security-policies

variable "enable_s3_public_access_block" {
  type    = bool
  default = true
}

variable "enable_large_instance_protection" {
  type    = bool
  default = false
}

variable "account_id" {
  type = string
}

variable "partition" {
  type = string
}

variable "region" {
  type = string
}

variable "sns_topic_arn" {
  description = "SNS topic ARN for alarms."
  type        = string
  default     = null
}

variable "enable_notifications" {
  description = "Whether SNS notifications are enabled (must be known at plan time)."
  type        = bool
  default     = false
}

variable "kms_key_arn" {
  type = string
}

variable "cloudtrail_log_group_name" {
  description = "CloudTrail CloudWatch log group name (required for large instance protection)."
  type        = string
  default     = null
}

