# modules/budget — AWS Budgets with SNS alerts at 80% and 100%

variable "limit" {
  description = "Monthly budget limit."
  type        = number
}

variable "currency" {
  description = "Currency code (USD, CNY, EUR)."
  type        = string
}

variable "sns_topic_arn" {
  description = "ARN of the SNS topic for budget alerts."
  type        = string
}
