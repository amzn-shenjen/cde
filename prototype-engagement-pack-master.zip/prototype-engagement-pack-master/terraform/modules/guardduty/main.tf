# modules/guardduty — Threat detection with EventBridge → SNS

# Bootstrap Lambda.
module "bootstrap_lambda" {
  # terraform-aws-modules/terraform-aws-lambda v8.8.0
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=b842374147fc07731d79028517223e9e0cbaab6d"

  function_name                     = "pep-guardduty-bootstrap"
  description                       = "Ensures a single enabled GuardDuty detector exists in the deploying account and region."
  handler                           = "index.handler"
  runtime                           = "nodejs24.x"
  timeout                           = 30
  memory_size                       = 128
  kms_key_arn                       = var.kms_key_arn
  cloudwatch_logs_retention_in_days = 30

  source_path = [{
    path = "${path.module}/../../../lib/constructs/guardduty/lambdas/bootstrap"
    commands = [
      "npx --yes esbuild@0.25.5 index.ts --platform=node --bundle --target=node24 --external:@aws-sdk/* --minify --outdir=dist",
      ":zip dist",
    ]
  }]

  attach_policy_json = true
  policy_json = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "guardduty:ListDetectors",
          "guardduty:CreateDetector"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "guardduty:UpdateDetector",
          "guardduty:DeleteDetector"
        ]
        Resource = "arn:${var.partition}:guardduty:${var.region}:${var.account_id}:detector/*"
      },
      {
        Effect = "Allow"
        Action = "iam:CreateServiceLinkedRole"
        Resource = [
          "arn:${var.partition}:iam::${var.account_id}:role/aws-service-role/${var.guardduty_principal}/AWSServiceRoleForAmazonGuardDuty",
          "arn:${var.partition}:iam::${var.account_id}:role/aws-service-role/malware-protection.guardduty.amazonaws.com/AWSServiceRoleForAmazonGuardDutyMalwareProtection"
        ]
        Condition = {
          StringLike = {
            "iam:AWSServiceName" = [
              var.guardduty_principal,
              "malware-protection.guardduty.amazonaws.com"
            ]
          }
        }
      },
      {
        Effect = "Allow"
        Action = "iam:GetRole"
        Resource = [
          "arn:${var.partition}:iam::${var.account_id}:role/aws-service-role/${var.guardduty_principal}/AWSServiceRoleForAmazonGuardDuty",
          "arn:${var.partition}:iam::${var.account_id}:role/aws-service-role/malware-protection.guardduty.amazonaws.com/AWSServiceRoleForAmazonGuardDutyMalwareProtection"
        ]
      }
    ]
  })
}

# Synthesises a CFN-style event and invokes the bootstrap Lambda
# at apply time.
resource "aws_lambda_invocation" "bootstrap" {
  function_name = module.bootstrap_lambda.lambda_function_name

  input = jsonencode({
    RequestType        = "Create"
    StackId            = "pep-terraform"
    RequestId          = "pep-terraform"
    LogicalResourceId  = "GuardDutyBootstrap"
    ResourceType       = "Custom::PepGuardDutyBootstrap"
    ResourceProperties = {}
  })
}

locals {
  bootstrap_response = jsondecode(aws_lambda_invocation.bootstrap.result)
  detector_id        = local.bootstrap_response.Data.DetectorId
}

# EventBridge Rule.

resource "aws_cloudwatch_event_rule" "guardduty" {
  name        = "pep-guardduty-findings"
  description = "Routes GuardDuty findings to the PEP SNS topic."

  event_pattern = jsonencode({
    source      = ["aws.guardduty"]
    detail-type = ["GuardDuty Finding"]
  })
}

resource "aws_cloudwatch_event_target" "guardduty_sns" {
  rule      = aws_cloudwatch_event_rule.guardduty.name
  target_id = "guardduty-to-sns"
  arn       = var.sns_topic_arn

  input_transformer {
    input_paths = {
      type   = "$.detail.type"
      region = "$.region"
    }
    input_template = "\"WARNING: Amazon GuardDuty has discovered a <type> security issue (<region>). Please go to https://<region>.${var.console_host}/guardduty/ to find out more details.\""
  }
}
