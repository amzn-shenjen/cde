# modules/guardduty

variable "sns_topic_arn" {
  type = string
}

variable "region" {
  type = string
}

variable "partition" {
  type = string
}

variable "account_id" {
  type = string
}

variable "kms_key_arn" {
  type = string
}

variable "console_host" {
  description = "AWS console host for the active partition (e.g. console.aws.amazon.com)."
  type        = string
}

variable "guardduty_principal" {
  description = "GuardDuty service principal for the active partition (e.g. guardduty.amazonaws.com)."
  type        = string
}
