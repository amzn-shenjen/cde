output "detector_id" {
  description = "GuardDuty detector ID."
  value       = local.detector_id
}
