# modules/vpc

variable "region" {
  type = string
}
