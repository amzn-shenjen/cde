# modules/inspector

variable "sns_topic_arn" {
  description = "ARN of the SNS topic for high/critical findings."
  type        = string
  default     = null
}

variable "enable_notifications" {
  description = "Whether to create EventBridge rules for SNS notifications (must be known at plan time)."
  type        = bool
  default     = false
}

variable "partition" {
  type = string
}
