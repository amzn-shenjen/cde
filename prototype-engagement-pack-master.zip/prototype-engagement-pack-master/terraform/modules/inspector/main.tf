# modules/inspector — Vulnerability scanning for EC2, ECR, Lambda

locals {
  resource_types = ["ECR", "EC2", "LAMBDA"]
}

resource "aws_inspector2_enabler" "this" {
  account_ids    = [data.aws_caller_identity.current.account_id]
  resource_types = local.resource_types
}

data "aws_caller_identity" "current" {}

# EventBridge Rule.

resource "aws_cloudwatch_event_rule" "inspector" {
  count = var.enable_notifications ? 1 : 0

  name        = "pep-inspector-findings"
  description = "Listens to events sent by Amazon Inspector"

  event_pattern = jsonencode({
    source      = ["aws.inspector2"]
    detail-type = ["Inspector2 Finding"]
    detail = {
      severity = ["HIGH", "CRITICAL"]
      status   = ["ACTIVE"]
    }
  })
}

resource "aws_cloudwatch_event_target" "inspector_sns" {
  count = var.enable_notifications ? 1 : 0

  rule      = aws_cloudwatch_event_rule.inspector[0].name
  target_id = "inspector-to-sns"
  arn       = var.sns_topic_arn
}
