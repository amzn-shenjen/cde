output "enabled_resource_types" {
  description = "Resource types enabled for Inspector scanning."
  value       = local.resource_types
}
