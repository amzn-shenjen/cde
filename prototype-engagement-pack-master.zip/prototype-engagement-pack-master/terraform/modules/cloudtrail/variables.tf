# modules/cloudtrail

variable "multi_region" {
  description = "Whether to enable multi-region CloudTrail logging."
  type        = bool
  default     = true
}

variable "kms_key_arn" {
  type = string
}

variable "kms_key_id" {
  type = string
}

variable "partition" {
  type = string
}

variable "region" {
  type = string
}

variable "account_id" {
  type = string
}
