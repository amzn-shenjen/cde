# modules/sns — Centralized notification topic

variable "kms_key_arn" {
  type = string
}

variable "enable_budget_publish" {
  type    = bool
  default = false
}

variable "enable_guardduty_publish" {
  type    = bool
  default = false
}

variable "enable_config_publish" {
  type    = bool
  default = false
}

variable "enable_events_publish" {
  type    = bool
  default = false
}

variable "enable_cloudwatch_publish" {
  type    = bool
  default = false
}

variable "guardduty_principal" {
  type    = string
  default = "guardduty.amazonaws.com"
}

variable "partition" {
  type = string
}

variable "region" {
  type = string
}

variable "account_id" {
  type = string
}
