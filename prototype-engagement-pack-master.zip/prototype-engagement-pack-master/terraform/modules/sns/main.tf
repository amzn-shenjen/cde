# modules/sns — Encrypted SNS topic with service publish permissions

resource "aws_sns_topic" "this" {
  name              = "PrototypeEngagementAlerts"
  kms_master_key_id = var.kms_key_arn
}

resource "aws_sns_topic_policy" "this" {
  arn    = aws_sns_topic.this.arn
  policy = data.aws_iam_policy_document.topic_policy.json
}

data "aws_iam_policy_document" "topic_policy" {
  statement {
    sid    = "DefaultAccountAccess"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.partition}:iam::${var.account_id}:root"]
    }
    actions = [
      "sns:GetTopicAttributes",
      "sns:SetTopicAttributes",
      "sns:AddPermission",
      "sns:RemovePermission",
      "sns:DeleteTopic",
      "sns:Subscribe",
      "sns:ListSubscriptionsByTopic",
      "sns:Publish",
    ]
    resources = [aws_sns_topic.this.arn]
  }

  dynamic "statement" {
    for_each = var.enable_budget_publish ? [1] : []
    content {
      sid    = "AllowBudgetsPublish"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["budgets.amazonaws.com"]
      }
      actions   = ["sns:Publish"]
      resources = [aws_sns_topic.this.arn]
    }
  }

  dynamic "statement" {
    for_each = var.enable_guardduty_publish ? [1] : []
    content {
      sid    = "AllowGuardDutyPublish"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = [var.guardduty_principal]
      }
      actions   = ["sns:Publish"]
      resources = [aws_sns_topic.this.arn]
    }
  }

  dynamic "statement" {
    for_each = var.enable_config_publish ? [1] : []
    content {
      sid    = "AllowConfigPublish"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["config.amazonaws.com"]
      }
      actions   = ["sns:Publish"]
      resources = [aws_sns_topic.this.arn]
    }
  }

  dynamic "statement" {
    for_each = var.enable_events_publish ? [1] : []
    content {
      sid    = "AllowEventBridgePublish"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["events.amazonaws.com"]
      }
      actions   = ["sns:Publish"]
      resources = [aws_sns_topic.this.arn]
    }
  }

  dynamic "statement" {
    for_each = var.enable_cloudwatch_publish ? [1] : []
    content {
      sid    = "AllowCloudWatchPublish"
      effect = "Allow"
      principals {
        type        = "Service"
        identifiers = ["cloudwatch.amazonaws.com"]
      }
      actions   = ["sns:Publish"]
      resources = [aws_sns_topic.this.arn]
      condition {
        test     = "ArnLike"
        variable = "aws:SourceArn"
        values   = ["arn:${var.partition}:cloudwatch:${var.region}:${var.account_id}:alarm:Large EC2 Instance Usage"]
      }
    }
  }
}
