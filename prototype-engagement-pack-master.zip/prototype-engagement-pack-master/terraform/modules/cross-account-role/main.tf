# modules/cross-account-role — Time-bound, MFA-required IAM role

locals {
  # `role` trusts a specific IAM role in the source account; `user`
  # trusts named IAM users in the source account; `account` trusts the
  # source account as a whole. Every mode but `role` relies on
  # long-lived credentials and adds an MFA condition at assume-time.
  mfa_required = var.trust_mode != "role"

  # The trusted principals are rendered as a single `Principal.AWS`
  # array, keeping the trust policy under the IAM 2048 character limit.
  principal_arns = {
    role    = [var.source_role_arn]
    user    = [for username in var.source_usernames : "arn:${var.partition}:iam::${var.source_account_id}:user/${username}"]
    account = [var.source_account_id]
  }[var.trust_mode]
}

data "aws_iam_policy_document" "assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "AWS"
      identifiers = local.principal_arns
    }

    actions = [
      # sts:AssumeRole allows AWS staff to assume the customer role.
      "sts:AssumeRole",

      # sts:SetSourceIdentity allows the AWS Staff to stamp their access
      # with their identity.
      "sts:SetSourceIdentity"
    ]

    dynamic "condition" {
      for_each = local.mfa_required ? [1] : []
      content {
        test     = "Bool"
        variable = "aws:MultiFactorAuthPresent"
        values   = ["true"]
      }
    }

    # Time-bound access
    condition {
      test     = "DateGreaterThan"
      variable = "aws:CurrentTime"
      values   = [var.start_time]
    }

    condition {
      test     = "DateLessThan"
      variable = "aws:CurrentTime"
      values   = [var.end_time]
    }
  }
}

resource "aws_iam_role" "this" {
  name                 = "PrototypeEngagementRole"
  description          = "A role to be assumed by the AWS team to access and operate on customer accounts."
  max_session_duration = 43200
  assume_role_policy   = data.aws_iam_policy_document.assume_role.json
}

resource "aws_iam_role_policy_attachment" "managed" {
  for_each = toset(var.managed_policies)

  role       = aws_iam_role.this.name
  policy_arn = each.value
}
