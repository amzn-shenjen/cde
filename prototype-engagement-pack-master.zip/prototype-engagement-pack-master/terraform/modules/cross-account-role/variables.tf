# modules/cross-account-role

variable "trust_mode" {
  description = "Trust target — 'role' to trust a specific IAM role in the source account, 'user' to trust named IAM users in the source account with MFA, 'account' to trust the source account as a whole with MFA."
  type        = string

  validation {
    condition     = contains(["role", "user", "account"], var.trust_mode)
    error_message = "trust_mode must be 'role', 'user' or 'account'."
  }
}

variable "source_account_id" {
  description = "AWS account ID of the trusted principal."
  type        = string
}

variable "source_role_arn" {
  description = "ARN of the IAM role in the source account. Required when trust_mode is 'role'."
  type        = string
  default     = ""
}

variable "source_usernames" {
  description = "Names of the IAM users in the source account. Required when trust_mode is 'user'."
  type        = list(string)
  default     = []
}

variable "partition" {
  description = "AWS partition used to build the trusted IAM user ARNs."
  type        = string
}

variable "managed_policies" {
  description = "List of managed policy ARNs to attach to the role."
  type        = list(string)
  default     = []
}

variable "start_time" {
  description = "ISO 8601 start datetime for role validity."
  type        = string
}

variable "end_time" {
  description = "ISO 8601 end datetime for role validity."
  type        = string
}
