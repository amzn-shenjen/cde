# modules/dev-environment

variable "disk_space_gb" {
  type    = number
  default = 50
}

variable "instance_type" {
  type    = string
  default = "m5.xlarge"
}

variable "ide_type" {
  description = "IDE type: 'code-server' (browser) or 'vscode-ssh' (local client)."
  type        = string
  default     = "code-server"
}

variable "vpc_id" {
  description = "Existing VPC ID (null = create new VPC)."
  type        = string
  default     = null
}

variable "subnet_id" {
  description = "Existing subnet ID (required if vpc_id is set)."
  type        = string
  default     = null
}

variable "availability_zone" {
  description = "Availability zone (required if vpc_id is set)."
  type        = string
  default     = null
}

variable "region" {
  type = string
}

variable "partition" {
  type    = string
  default = "aws"
}

variable "kms_key_arn" {
  description = "PEP CMK used to encrypt the code-server password secret."
  type        = string
}
