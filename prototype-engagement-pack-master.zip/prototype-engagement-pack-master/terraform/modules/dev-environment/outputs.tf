output "instance_id" {
  description = "EC2 instance ID."
  value       = aws_instance.this.id
}

output "ssm_command" {
  description = "AWS CLI command to start an SSM session."
  value = (
    local.use_code_srv
    ? "aws ssm start-session --region ${var.region} --target ${aws_instance.this.id} --document-name AWS-StartPortForwardingSession --parameters 'portNumber=8080,localPortNumber=8080'"
    : "aws ssm start-session --region ${var.region} --target ${aws_instance.this.id}"
  )
}

output "code_server_url" {
  description = "Local URL for code-server (after SSM port-forwarding)."
  value       = local.use_code_srv ? "http://localhost:8080/?folder=/workspace" : null
}

output "code_server_secret_arn" {
  description = "ARN of the Secrets Manager secret containing the code-server password."
  value       = local.use_code_srv ? aws_secretsmanager_secret.code_server[0].arn : null
}
