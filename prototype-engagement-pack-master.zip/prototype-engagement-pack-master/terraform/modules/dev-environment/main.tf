# modules/dev-environment — Cloud-based development environment (EC2 + code-server/SSH)

locals {
  create_vpc   = var.vpc_id == null
  use_code_srv = var.ide_type == "code-server"
}

data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

data "aws_availability_zones" "available" {
  state = "available"
}

# VPC.

resource "aws_vpc" "this" {
  # checkov:skip=CKV2_AWS_11:Flow logs opted out for sandbox and cost reasons.
  count = local.create_vpc ? 1 : 0

  cidr_block           = "10.1.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = { Name = "pep-dev-vpc" }
}

# Lock down the VPC's default security group.
resource "aws_default_security_group" "this" {
  count  = local.create_vpc ? 1 : 0
  vpc_id = aws_vpc.this[0].id
}

resource "aws_subnet" "public" {
  # checkov:skip=CKV_AWS_130:Public subnet hosts the NAT gateway; auto-assigned IPs are required.
  count = local.create_vpc ? 1 : 0

  vpc_id                  = aws_vpc.this[0].id
  cidr_block              = "10.1.0.0/24"
  availability_zone       = data.aws_availability_zones.available.names[0]
  map_public_ip_on_launch = true

  tags = { Name = "pep-dev-public" }
}

resource "aws_subnet" "private" {
  count = local.create_vpc ? 1 : 0

  vpc_id            = aws_vpc.this[0].id
  cidr_block        = "10.1.100.0/24"
  availability_zone = data.aws_availability_zones.available.names[0]

  tags = { Name = "pep-dev-private" }
}

resource "aws_internet_gateway" "this" {
  count  = local.create_vpc ? 1 : 0
  vpc_id = aws_vpc.this[0].id
  tags   = { Name = "pep-dev-igw" }
}

resource "aws_eip" "nat" {
  count  = local.create_vpc ? 1 : 0
  domain = "vpc"
  tags   = { Name = "pep-dev-nat-eip" }
}

resource "aws_nat_gateway" "this" {
  count = local.create_vpc ? 1 : 0

  allocation_id = aws_eip.nat[0].id
  subnet_id     = aws_subnet.public[0].id
  tags          = { Name = "pep-dev-nat" }

  depends_on = [aws_internet_gateway.this]
}

resource "aws_route_table" "public" {
  count  = local.create_vpc ? 1 : 0
  vpc_id = aws_vpc.this[0].id
  tags   = { Name = "pep-dev-public-rt" }
}

resource "aws_route" "public_internet" {
  count                  = local.create_vpc ? 1 : 0
  route_table_id         = aws_route_table.public[0].id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.this[0].id
}

resource "aws_route_table_association" "public" {
  count          = local.create_vpc ? 1 : 0
  subnet_id      = aws_subnet.public[0].id
  route_table_id = aws_route_table.public[0].id
}

resource "aws_route_table" "private" {
  count  = local.create_vpc ? 1 : 0
  vpc_id = aws_vpc.this[0].id
  tags   = { Name = "pep-dev-private-rt" }
}

resource "aws_route" "private_nat" {
  count                  = local.create_vpc ? 1 : 0
  route_table_id         = aws_route_table.private[0].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.this[0].id
}

resource "aws_route_table_association" "private" {
  count          = local.create_vpc ? 1 : 0
  subnet_id      = aws_subnet.private[0].id
  route_table_id = aws_route_table.private[0].id
}

locals {
  resolved_subnet_id = local.create_vpc ? aws_subnet.private[0].id : var.subnet_id
}

# Secrets Manager — code-server password.

resource "aws_secretsmanager_secret" "code_server" {
  # checkov:skip=CKV2_AWS_57:Rotating the code-server password breaks active SSM sessions.
  count       = local.use_code_srv ? 1 : 0
  name_prefix = "pep-code-server-password-"
  description = "Password for VS Code server authentication"
  kms_key_id  = var.kms_key_arn
}

resource "aws_secretsmanager_secret_version" "code_server" {
  count     = local.use_code_srv ? 1 : 0
  secret_id = aws_secretsmanager_secret.code_server[0].id

  secret_string = jsonencode({
    username = "admin"
    password = random_password.code_server[0].result
  })
}

resource "random_password" "code_server" {
  count            = local.use_code_srv ? 1 : 0
  length           = 30
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

# IAM Role for EC2.

resource "aws_iam_role" "instance" {
  name               = "pep-dev-instance-role"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume.json
}

data "aws_iam_policy_document" "ec2_assume" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.instance.name
  policy_arn = "arn:${var.partition}:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_role_policy" "secrets" {
  count = local.use_code_srv ? 1 : 0

  name   = "secrets-access"
  role   = aws_iam_role.instance.id
  policy = data.aws_iam_policy_document.secrets[0].json
}

# Grants the instance permission to read the code-server password
# from Secrets Manager and decrypt it via the PEP CMK.
data "aws_iam_policy_document" "secrets" {
  count = local.use_code_srv ? 1 : 0

  statement {
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.code_server[0].arn]
  }

  statement {
    effect    = "Allow"
    actions   = ["kms:Decrypt"]
    resources = [var.kms_key_arn]
  }
}

resource "aws_iam_instance_profile" "this" {
  name = "pep-dev-instance-profile"
  role = aws_iam_role.instance.name
}

# EC2 Instance.

resource "aws_instance" "this" {
  ami                         = data.aws_ami.al2023.id
  instance_type               = var.instance_type
  iam_instance_profile        = aws_iam_instance_profile.this.name
  subnet_id                   = local.resolved_subnet_id
  associate_public_ip_address = false
  monitoring                  = true
  ebs_optimized               = true

  root_block_device {
    volume_size = var.disk_space_gb
    volume_type = "gp3"
    encrypted   = true
  }

  user_data = local.user_data

  tags = { Name = "pep-dev-instance" }

  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }
}

# User-data.
locals {
  base_script        = file("${path.module}/../../../lib/constructs/dev-environment/user-data/base.sh")
  code_server_script = file("${path.module}/../../../lib/constructs/dev-environment/user-data/code-server.sh")
  code_server_exports = local.use_code_srv ? join("\n", [
    "export CODE_SERVER_SECRET_ARN='${aws_secretsmanager_secret.code_server[0].arn}'",
    "export AWS_DEFAULT_REGION='${var.region}'",
  ]) : ""

  user_data = local.use_code_srv ? join("\n", [
    local.base_script,
    local.code_server_exports,
    local.code_server_script,
  ]) : local.base_script
}
