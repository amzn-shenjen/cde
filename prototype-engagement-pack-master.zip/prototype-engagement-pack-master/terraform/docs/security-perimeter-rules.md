# Security Perimeter Rules

This is a set of additional security measures that can be deployed by the Prototype Engagement Pack to further improve the security of the sandbox account. Below is a description of the different security perimeter rules implemented in the Prototype Engagement Pack.

## Block S3 Public Access

The Amazon S3 Block Public Access feature will block public access to S3 access points, S3 buckets. By default, new buckets, access points, and objects don't allow public access. However, users can modify bucket policies, access point policies, or object permissions to allow public access. S3 Block Public Access settings override these policies and permissions so that you can limit public access to these resources.

This feature will override S3 Public ACLs on buckets and S3 Public Bucket Policies to ensure no S3 bucket in the account can be made publicly accessible.

> We strongly advise enabling this option to protect a sandbox account. There is no additional cost involved in enabling this feature.

## Alerting for large EC2 instances

This feature will trigger an alert when an EC2 instance that is larger than 4xlarge is launched and will use the notification channels you enabled via the Prototype Engagement Pack to send a notification to the account stakeholders.

> This option can be kept disabled for some prototypes where large EC2 instances are required (ML, Big Data, HPC/HTC), but should be enabled otherwise.
