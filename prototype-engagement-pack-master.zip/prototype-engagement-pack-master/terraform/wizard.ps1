#Requires -Version 5.1
$ErrorActionPreference = 'Stop'

# Resolve the repository root regardless of where this script is run from.
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $ScriptDir

# Run the unified wizard, telling it to emit a Terraform configuration.
Push-Location $RepoRoot
try {
  npm ci --silent
  if ($LASTEXITCODE -ne 0) { throw "npm ci failed with exit code $LASTEXITCODE." }

  npx tsx bin/wizard/index.ts `
    --output-format=terraform `
    --output="$ScriptDir"
  if ($LASTEXITCODE -ne 0) { throw "The wizard exited with code $LASTEXITCODE." }
}
finally {
  Pop-Location
}
