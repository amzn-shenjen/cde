# KMS — Customer Managed Key.

module "kms" {
  source = "./modules/kms"

  partition  = local.partition
  region     = local.region
  account_id = local.account_id

  # Grant access to services that will be enabled
  enable_budget_grant     = var.budget != null && local.budgets_available
  enable_guardduty_grant  = local.guardduty_enabled
  enable_config_grant     = var.config != null
  enable_events_grant     = local.guardduty_enabled || var.inspector != null || var.config != null
  enable_cloudwatch_grant = var.security_policies != null
  enable_cloudtrail_grant = var.cloudtrail != null

  guardduty_principal = local.guardduty_principal
}

# SNS — Notification Topic.

module "sns" {
  source = "./modules/sns"
  count  = local.sns_required ? 1 : 0

  kms_key_arn = module.kms.key_arn

  enable_budget_publish     = var.budget != null && local.budgets_available
  enable_guardduty_publish  = local.guardduty_enabled
  enable_config_publish     = var.config != null
  enable_events_publish     = local.guardduty_enabled || var.inspector != null || var.config != null
  enable_cloudwatch_publish = var.security_policies != null

  guardduty_principal = local.guardduty_principal
  partition           = local.partition
  region              = local.region
  account_id          = local.account_id
}

# VPC — Optional isolated VPC with VPC endpoints.

module "vpc" {
  source = "./modules/vpc"
  count  = var.network != null && var.network.use_vpc_endpoints ? 1 : 0
  region = local.region
}

# Budget.

module "budget" {
  source = "./modules/budget"
  count  = var.budget != null && local.budgets_available ? 1 : 0

  limit         = var.budget.limit
  currency      = local.currency
  sns_topic_arn = module.sns[0].topic_arn
}

# CloudTrail.

module "cloudtrail" {
  source = "./modules/cloudtrail"
  count  = var.cloudtrail != null ? 1 : 0

  multi_region = var.cloudtrail.multi_region
  kms_key_arn  = module.kms.key_arn
  kms_key_id   = module.kms.key_id
  partition    = local.partition
  region       = local.region
  account_id   = local.account_id
}

# GuardDuty.

module "guardduty" {
  source = "./modules/guardduty"
  count  = local.guardduty_enabled ? 1 : 0

  sns_topic_arn       = module.sns[0].topic_arn
  region              = local.region
  partition           = local.partition
  account_id          = local.account_id
  kms_key_arn         = module.kms.key_arn
  console_host        = local.console_host
  guardduty_principal = local.guardduty_principal
}

# Inspector.

module "inspector" {
  source = "./modules/inspector"
  count  = var.inspector != null && !local.is_eusc ? 1 : 0

  sns_topic_arn        = local.sns_required ? module.sns[0].topic_arn : null
  enable_notifications = local.sns_required
  partition            = local.partition
}

# AWS Config Rules.

module "config" {
  source = "./modules/config-rules"
  count  = var.config != null ? 1 : 0

  rules         = var.config.rules
  sns_topic_arn = module.sns[0].topic_arn
  kms_key_arn   = module.kms.key_arn
  partition     = local.partition
  region        = local.region
  account_id    = local.account_id
  is_eusc       = local.is_eusc

  vpc_id             = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].vpc_id : null
  private_subnet_ids = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].private_subnet_ids : []
}

# Cross-Account Role.

module "cross_account_role" {
  source = "./modules/cross-account-role"
  count  = var.engagement != null ? 1 : 0

  trust_mode        = var.engagement.role.trust_mode
  source_account_id = var.engagement.role.source_account_id
  source_role_arn   = var.engagement.role.source_role_arn
  source_usernames  = var.engagement.role.source_usernames
  partition         = local.partition
  managed_policies  = var.engagement.role.managed_policies
  start_time        = var.engagement.start
  end_time          = var.engagement.end
}

# Notification — Email.

module "notification_email" {
  source = "./modules/notification/email"
  count  = var.notification != null && var.notification.email != null ? 1 : 0

  sender        = var.notification.email.sender
  targets       = var.notification.email.targets
  sns_topic_arn = module.sns[0].topic_arn
  kms_key_arn   = module.kms.key_arn
  region        = local.region
  account_id    = local.account_id

  vpc_id             = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].vpc_id : null
  private_subnet_ids = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].private_subnet_ids : []
}

# Notification — Slack.

module "notification_slack" {
  source = "./modules/notification/slack"
  count  = var.notification != null && var.notification.slack != null ? 1 : 0

  slack_channel_id   = var.notification.slack.slack_channel_id
  slack_workspace_id = var.notification.slack.slack_workspace_id
  sns_topic_arn      = module.sns[0].topic_arn
  region             = local.region
}

# Notification — Teams.

module "notification_teams" {
  source = "./modules/notification/teams"
  count  = var.notification != null && var.notification.teams != null ? 1 : 0

  webhook_url   = var.notification.teams.webhook_url
  sns_topic_arn = module.sns[0].topic_arn
  kms_key_arn   = module.kms.key_arn

  vpc_id             = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].vpc_id : null
  private_subnet_ids = var.network != null && var.network.use_vpc_endpoints ? module.vpc[0].private_subnet_ids : []
}

# Security Policies.

module "security_policies" {
  source = "./modules/security-policies"
  count  = var.security_policies != null ? 1 : 0

  enable_s3_public_access_block    = var.security_policies.enable_s3_public_access_block
  enable_large_instance_protection = var.security_policies.enable_large_instance_protection

  account_id                = local.account_id
  partition                 = local.partition
  region                    = local.region
  sns_topic_arn             = local.sns_required ? module.sns[0].topic_arn : null
  enable_notifications      = local.sns_required
  kms_key_arn               = module.kms.key_arn
  cloudtrail_log_group_name = var.cloudtrail != null ? module.cloudtrail[0].log_group_name : null
}

# Development Environment.

module "dev_environment" {
  source = "./modules/dev-environment"
  count  = var.dev_environment != null && var.dev_environment.enabled ? 1 : 0

  disk_space_gb     = var.dev_environment.disk_space_gb
  instance_type     = var.dev_environment.instance_type
  ide_type          = var.dev_environment.ide_type
  vpc_id            = var.dev_environment.vpc_id
  subnet_id         = var.dev_environment.subnet_id
  availability_zone = var.dev_environment.availability_zone
  region            = local.region
  partition         = local.partition
  kms_key_arn       = module.kms.key_arn
}
