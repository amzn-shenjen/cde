# Components

You will find below a documentation of the different components that the Prototype Engagement Pack can deploy on sandbox accounts.

## 🔑 Cross-Account Role

When accessing customer accounts, AWS engineers are required to assume a role provided by the customer instead of using AWS credentials which can be compromised. The role assumed by AWS engineers is generally bound to the [PowerUserAccess](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies_job-functions.html#jf_developer-power-user) managed policy. Additional permissions can be attached to the role used by the AWS team by the owner of the sandbox account.

This role can be assumed using the AWS console and allows AWS engineers to switch role to the customer account, it also allows AWS CLI and AWS SDK access to the sandbox account under the defined policy. Multi-factor authentication (MFA) is required to assume this role if an IAM User is the trusted principal.

The wizard offers three ways to establish the trust, and they are mutually exclusive.

Trust mode | Trusted principal | MFA required
---------- | ----------------- | ------------
**Trust an AWS Account** | The AWS source account as a whole, meaning any principal in that account allowed to assume the role. | Yes
**Trust an IAM Role** | A single named IAM role in the AWS source account, provided as an ARN. The source account identifier is parsed from that ARN. | No, the role is already assumed with MFA
**Trust an IAM User** | Up to 5 named IAM users in the AWS source account. The wizard asks for the source account identifier, then for each username. | Yes

<br /><div align="center">
  <img width="700" src="../assets/diagrams/assume-role.png" />
  <div align="center"><sub>The Assume Role Flow (click to enlarge)</sub></div>
</div><br />

Additionally, the assumed role is time-bound, meaning that it is only valid within a specific time frame associated with the start date of the prototype and the expected end date of the prototype. This is to ensure that AWS teams automatically lose access to customer accounts even if the customer did not remove the role from their account at the end of the engagement.

## 🔏 AWS CloudTrail Audit Log

The Prototype Engagement Pack can optionally create an AWS CloudTrail audit trail used to record every actions that occur during the prototype on the sandbox account. The trail is cryptographically signed by AWS CloudTrail and stored on a private and encrypted S3 bucket within the sandbox account. This means that the audit trail cannot be tampered with without noticing it.

You can choose whether you want AWS CloudTrail to record actions from every AWS regions (for a multi-region development for example) or only from the target region in which the Prototype Engagement Pack is deployed.

> Note that additional charges may apply if AWS CloudTrail must record actions from every region.

## 🚧 AWS Config Rules

As explained in the Description section of the documentation, this stack can deploy several configurable AWS Config rules on the sandbox account in order to establish compliance rules that should not be broken during a prototype. Below is the detail of the different rules that can be deployed.

### Default Rules

The below rules are enabled by default when you select `AWS Config Rules` in the Prototype Engagement Pack wizard. They allow to detect the most common and potentially harmful security issues that can happen during a prototype.

Rule Name | Description | Category | Default value
--------- | ----------- | -------- | -------------
**S3_BUCKET_PUBLIC_READ_PROHIBITED** | Checks whether existing S3 buckets are publicly readable. | Security| Enabled
**S3_BUCKET_PUBLIC_WRITE_PROHIBITED** |	Checks whether existing S3 buckets are publicly writable. | Security | Enabled
**IAM_USER_MFA_ENABLED** | Checks whether MFA is enabled for IAM users. | Security | Enabled
**MFA_ENABLED_FOR_IAM_CONSOLE_ACCESS** | Checks whether MFA is enabled for console access. | Security | Enabled
**RDS_INSTANCE_PUBLIC_ACCESS_CHECK** | Checks whether the Amazon Relational Database Service instances are not publicly accessible | Security | Enabled
**RDS_SNAPSHOTS_PUBLIC_PROHIBITED** | Checks whether the Amazon Relational Database Service snapshots are not publicly accessible. | Security | Enabled
**EC2_INSTANCE_NO_PUBLIC_IP** | Checks whether EC2 instances are not publicly accessible. | Security | Enabled
**REDSHIFT_CLUSTER_PUBLIC_ACCESS_CHECK** | Checks whether Redshift clusters are not publicly accessible. | Security | Enabled
**EMR_MASTER_NO_PUBLIC_IP** | Checks whether EMR masters are not publicly accessible. | Security | Enabled
**SAGEMAKER_NOTEBOOK_NO_DIRECT_INTERNET_ACCESS** | Checks whether Sagemaker notebooks are not publicly accessible. | Security | Enabled
**INCOMING_SSH_DISABLED** | Checks if the incoming SSH traffic for the security groups is accessible. The rule is COMPLIANT when IP addresses of the incoming SSH traffic in the security groups are restricted (CIDR other than 0.0.0.0/0). This rule applies only to IPv4. | Security | Enabled
**EC2_VOLUME_INUSE_CHECK** | Checks that all EBS volumes are used. | Cost efficiency | Enabled
**EIP_ATTACHED** | Checks that all Elastic IPs are used. | Cost efficiency | Enabled

### Encryption Rules

The below rules are disabled by default in the Wizard but can be opted-in. They enforce best-practices for customers wanting to encrypt all of their AWS resources.

Rule Name | Description | Category | Default value
--------- | ----------- | -------- | -------------
**RDS_STORAGE_ENCRYPTED**	| A Config rule that checks whether storage encryption is enabled for your RDS DB instances. | Encryption | Disabled
**ENCRYPTED_VOLUMES**	| Checks that all EBS volumes are encrypted. | Encryption | Disabled
**DYNAMODB_TABLE_ENCRYPTION_ENABLED** | Checks that all DynamoDB tables are encrypted. | Encryption | Disabled
**ELASTICSEARCH_ENCRYPTED_AT_REST** | Checks that all ElasticSearch domains are encrypted. | Encryption | Disabled
**ELASTICSEARCH_NODE_TO_NODE_ENCRYPTION_CHECK** | Checks that all ElasticSearch domains have node-to-node encryption enabled. | Encryption | Disabled
**EFS_ENCRYPTED_CHECK** | Checks that all EFS clusters are encrypted. | Encryption | Disabled
**SNS_ENCRYPTED_KMS** | Checks that all SNS topics are encrypted. | Encryption | Disabled
**S3_BUCKET_SERVER_SIDE_ENCRYPTION_ENABLED** | Checks that all S3 buckets are encrypted. | Encryption | Disabled

### Additional Rules

The below rules are disabled by default in the Wizard but can be opted-in. They enforce best-practices for customers wanting to further protect their AWS resources.

Rule Name | Description | Category | Default value
--------- | ----------- | -------- | -------------
**LAMBDA_INSIDE_VPC** | Checks if Lambda functions are VPC-enabled | Network Security | Disabled
**SERVICE_VPC_ENDPOINT_ENABLED_SSM** | Checks if AWS Secrets Manager vpc endpoints are enabled in the VPC | Network Security | Disabled
**SERVICE_VPC_ENDPOINT_ENABLED_S3** | Checks if S3 vpc endpoints are enabled in the VPC | Network Security | Disabled
**S3_ENCRYPTED_WITH_CMK (custom rule)** | Checks if S3 buckets are encrypted with a customer managed key | Data Protection | Disabled
**OPENSEARCH_IN_VPC_ONLY** | Checks if OpenSearch domains are in a VPC | Network Security | Disabled
**GUARDDUTY_ENABLED_CENTRALIZED** | Checks if GuardDuty is enabled | Security Monitoring | Disabled
