# 🖥️ Development Environment

The Prototype Engagement Pack includes an optional development environment that provides a secure, cloud-based development environment for prototyping activities, running inside the customer's sandbox account. It is available in both the CDK and Terraform variants and can be enabled through the wizard.

## Features

- **VS Code Server**: Pre-configured VS Code server accessible via web browser through secure SSM port forwarding.
- **Configurable Instance**: Customizable instance type and disk space with encrypted EBS volumes.
- **Pre-installed Development Tools**:
  - Node.js and npm for JavaScript/TypeScript development
  - Python 3 and pip for Python development
  - Git for version control with an initialized workspace repository
  - Docker for containerized development
  - AWS CLI and tools for cloud development
- **Secure Access**:
  - No direct internet access required — access is via AWS Systems Manager (SSM) port forwarding
  - Automatically generated secure passwords stored in AWS Secrets Manager
  - Option to use an existing VPC and subnet, or create a new isolated VPC

## Architecture

Below is the architecture diagram describing the resources that the Development Environment will create if enabled.

<div align="center">
  <img src="../assets/diagrams/dev-environment-architecture.jpg" />
  <div align="center"><sub>The Prototype Engagement Dev Environment</sub></div>
</div>

## Accessing the environment

1. Start the SSM tunnel:
   - **CDK**: use the SSM tunnel command from the stack outputs.
   - **Terraform**: use the `ssm_command` output.
2. Retrieve the code-server password from the AWS Secrets Manager console:
   - **CDK**: follow the console link in the stack outputs.
   - **Terraform**: use the `code_server_secret_arn` output.
3. Open and use the IDE in your local browser at `http://localhost:8080`.

## Connecting to VS Code Server in the customer AWS account

You can connect to the VS Code server running in the customer AWS account using two methods:

1. **Browser-based VS Code (Code Server)** — Access VS Code directly in your browser.
2. **Local VS Code via SSH over SSM** — Connect your local VS Code to the remote server.

To connect using your local VS Code:

1. **Select the correct AWS profile** — Click the three dots in the AWS Toolkit extension to select the appropriate AWS profile for the customer account.

<br />
<div align="center">
  <img width="800" src="../assets/aws-toolkit-connect-profile.png" />
  <div align="center"><sub>Selecting the correct AWS profile in VS Code</sub></div>
</div>
<br />

2. **Connect to the EC2 instance** — In the AWS Explorer panel, find the EC2 instance and click the first icon next to the instance ID to open a new VS Code window connected to the EC2 `/workspace` folder via SSH over SSM.

<br />
<div align="center">
  <img width="600" src="../assets/work-in-customer-account.png" />
  <div align="center"><sub>Connecting to EC2 instance via SSH over SSM</sub></div>
</div>
<br />

3. **Start working in the remote environment** — Once connected, you'll have full access to the development environment with all pre-installed tools and can work directly in the customer's AWS account.
