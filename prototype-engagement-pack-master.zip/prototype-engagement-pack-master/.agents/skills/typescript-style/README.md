<br />
<p align="center">
  <img width="220" src="assets/icon.png">
  <br />
  <p align="center">🏷️ Agent skill for TypeScript code guideline.</p>
  <p align="center">
    <a href="https://github.com/codespaces/new/HQarroum/writing-typescript"><img alt="Github Codespaces" src="https://github.com/codespaces/badge.svg" /></a>
  </p>
</p>
<br />

## 🔖 Scope

- **Best Practices**: Enforce consistent coding standards with coding agents across TypeScript codebases.
- **Code Style Guidelines**: Provide clear rules for formatting, naming, and structuring TypeScript code.
- **Naming Conventions**: Define consistent naming patterns for variables, functions, classes, interfaces, and types.
- **Logging Standards**: Define structured logging practices for TypeScript applications.
- **Architectural Patterns**: Recommend design patterns and architectural principles for scalable TypeScript applications.
- **Tools**: Prompts agents to use select tools for tests, linting, formatting, and static analysis.

## 📦 Install

Use Vercel's [skills](https://github.com/vercel-labs/skills) tool to add your skill to your project.

```bash
npx skills add HQarroum/writing-typescript
```

## 📄 Size

| Skill                                                      | Tokens |
|------------------------------------------------------------|--------|
| [`SKILL.md`](SKILL.md)                                     | ~3.4k  |
| [`typescript-architecture.md`](references/typescript-architecture.md) | ~200   |
| [`typescript-logging.md`](references/typescript-logging.md)           | ~500   |
| [`typescript-security.md`](references/typescript-security.md)         | ~1.1k  |

> Based on the `gpt-5` [OpenAI tokenizer](https://platform.openai.com/tokenizer).
