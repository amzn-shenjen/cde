---
name: typescript-security
description: Enforces security best practices in TypeScript projects.
---

# Security

## Core Principles

- **Never trust external input.** All data crossing a trust boundary (HTTP requests, file reads, environment variables, agent inference, message queues, third-party APIs) must be validated and verified before use.
- **Least privilege.** Grant the minimum permissions required.
- **Defense in depth.** Layer multiple security controls — input validation, parameterized queries, output encoding, and CSP headers — a failure in one layer does not compromise the system.
- **Fail securely.** Errors must never leak internal state, stack traces, or sensitive data to external consumers.

## Input Validation

- Validate all external input at the boundary using Zod schemas. Once parsed, trust the types downstream.
- Reject unexpected fields using `.strict()` on Zod object schemas exposed to external input.
- Constrain string lengths, numeric ranges, and array sizes to prevent abuse.

```ts
/**
 * Schema for incoming user registration requests.
 */
const RegistrationSchema = z
  .object({

    /**
     * The user's display name.
     * @min 1 character
     * @max 100 characters
     */
    name: z
      .string()
      .min(1)
      .max(100)
      .trim(),

    /**
     * The user's email address.
     * @max 254 characters (RFC 5321)
     */
    email: z
      .string()
      .email()
      .max(254)
      .toLowerCase()
  })
  .strict();
```

## Injection Prevention

### SQL Injection

- Always use parameterized queries. Never concatenate user input into SQL strings.
- When using Drizzle or Kysely, rely on their built-in parameterization — never use `sql.raw()` with user input.

```ts
// Wrong — vulnerable to SQL injection.
const query = `SELECT * FROM users WHERE id = '${userId}'`;

// Right — parameterized via Drizzle.
const user = await db
  .select()
  .from(users)
  .where(eq(users.id, userId));
```

### XSS (Cross-Site Scripting)

- Never insert unsanitized user input into HTML, templates, or DOM.
- In React, avoid `dangerouslySetInnerHTML`. When unavoidable, sanitize with a library like `DOMPurify`.
- Set appropriate Content Security Policy (CSP) headers to restrict inline scripts and untrusted sources.

### Child Process Safety

- Avoid `child_process` when possible.
- Never pass unsanitized user input to any `child_process` method.
- Always validate and whitelist command arguments.

## Secrets Management

- Never hardcode secrets (API keys, passwords, tokens) in source code.
- Use environment variables loaded via a validated `env.ts` file.
- Add `.env*` to `.gitignore` to prevent accidental commits of local secret files.
- Rotate secrets regularly and use short-lived tokens where possible.
- Use the `files` field in `package.json` or an `.npmignore` file to prevent secrets and internal files from being published to the npm registry.

## Sensitive Data Handling

### Logging

- Never log passwords, tokens, API keys, credit card numbers, or personally identifiable information (PII).
- Use Pino's `redact` option to automatically strip sensitive fields from log output.

```ts
import pino from 'pino';

const logger = pino({
  redact: [
    'password',
    'token',
    'authorization',
    'cookie',
    '*.password',
    '*.token'
  ]
});
```

## Dependency Security

- Run `pnpm audit` (or `npm audit`) in CI pipelines.
- Use `--frozen-lockfile` in CI to ensure reproducible installs.
- Pin major versions and review changelogs before upgrading.
- Prefer well-maintained, widely-used packages. Evaluate dependencies for known vulnerabilities before adoption.
- Remove unused dependencies promptly.

## Authentication & Authorization

- Never implement custom cryptography or password hashing — use established libraries.
- Validate JWTs on every request. Verify signature, expiration, issuer, and audience.
- Use short-lived access tokens with refresh token rotation.

## HTTP Security Headers

Set these headers on all HTTP responses:

| Header | Value | Purpose |
|--------|-------|---------|
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains; preload` | Enforce HTTPS. |
| `X-Content-Type-Options` | `nosniff` | Prevent MIME-type sniffing. |
| `X-Frame-Options` | `DENY` | Prevent clickjacking. |
| `Content-Security-Policy` | Per-application policy | Restrict resource loading. |
| `Referrer-Policy` | `strict-origin-when-cross-origin` | Control referrer information. |
| `Permissions-Policy` | Per-application policy | Restrict browser features. |

## Anti-Patterns

- No `eval()`, `Function()`, or `new Function()` with dynamic input.
- No secrets in source code, logs, or client-side bundles.
- No `*` CORS origins in production — whitelist specific origins.
- No disabled CSRF protection.
- No storing sensitive data client side (e.g., in localStorage) without encryption and proper access controls.
- Don't trust client-side validation alone, always verify server-side.
- No `exec()` with user input, use `execFile()` with an argument array.
- No unbounded regex patterns with user-supplied input, guard against ReDoS.
