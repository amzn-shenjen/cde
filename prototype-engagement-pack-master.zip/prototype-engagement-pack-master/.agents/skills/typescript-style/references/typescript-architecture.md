---
name: typescript-architecture
description: Enforces TypeScript architecture principles.
---

# TypeScript Architecture Guidelines

## Principles

- **Parse, don't validate.** Transform unstructured data into typed structures at the boundary of your system (API handlers, file readers, message consumers) using Zod schemas. Once parsed, trust the types, do not re-validate deeper in the call stack.
- **Composition over inheritance.** Prefer concise, self-contained, composable functions and components over complex inheritance. Use classes for stateful entities or when modeling real-world objects, and functions for a more functional style.
- **Prefer re-entrant, stateless, pure functions.** Functions should avoid side effects and shared mutable state.
- **Fail fast.** Invalid state should be caught and surfaced at the earliest possible point — ideally at compile time via types, otherwise at runtime via schema validation.

### Monorepos

Always use monorepos for projects involving multiple packages that are either functional (different components of the same application, e.g front-end, back-end, mobile application), or technical (e.g different libraries, utilities). Monorepos simplify dependency management, code sharing, and refactoring across packages.

Choose [Turborepo](https://skills.sh/vercel/turborepo/turborepo) for monorepo management.
