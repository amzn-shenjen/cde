---
name: typescript-logging
description: Enforces structured logging standards in TypeScript projects.
---

# Logging

## Core Principles

- Logs are structured data, and must be a JSON object with consistent, queryable fields.
- Use asynchronous, non-blocking loggers.
- Use `pino` as the default logging library.
- Use `pino-pretty` for development to format logs in a human-readable way.

## Log Levels

| Level   | Numeric | When to Use                                       |
|---------|---------|-------------------------------------------------- |
| `fatal` | 60      | Unrecoverable failures.                           |
| `error` | 50      | Operation-level failures requiring investigation. |
| `warn`  | 40      | Unexpected but non-breaking situations.           |
| `info`  | 30      | Significant application events.                   |
| `debug` | 20      | Detailed diagnostic data for development.         |
| `trace` | 10      | Very fine-grained diagnostic data.                |

## Structured Logs

Every log entry must contain these required fields.

| Field         | Type     | Description                                  |
|---------------|----------|----------------------------------------------|
| `timestamp`   | `string` | ISO 8601 (UTC) with milliseconds.            |
| `level`       | `string` | Uppercase severity (`INFO`, `ERROR`, etc.).  |
| `service`     | `string` | Service name identifier.                     |
| `msg`         | `string` | Static event description.                    |
| `version`     | `string` | Deployed semantic version.                   |
| `environment` | `string` | `development`, `staging`, or `production`.   |

## Structured Attributes

Pass context as the first argument, and the message as the second argument.

```ts
// Wrong.
logger.info(`User ${userId} completed order ${orderId} for ${amount}`);

// Right.
logger.info({
  'user.id': 'usr_123',
  'order.id': 'ord_456',
  'order.amount': 99.99,
  'order.currency': 'USD'
}, 'Order completed');
```

Use dot-notation, lowercase, snake_case attribute names. Follow OpenTelemetry semantic conventions where applicable.

```ts
// Good.
{ 'user.id': 'usr_123', 'http.method': 'POST', 'db.duration_ms': 45 }
```

## HTTP Request Logging

Use `pino-http` to automatically log HTTP requests and responses for web frameworks.

## Anti-Patterns

- No `console.*` in application code.
- No string interpolation in log messages.
- No `pino-pretty` in production.
- No logging of full request/response bodies by default, log only what is necessary for debugging.
- No synchronous file writes.
