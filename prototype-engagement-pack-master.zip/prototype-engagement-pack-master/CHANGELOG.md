# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.4.0] - 2026-08-02

### Added

- A third cross-account trust mode, **Trust an IAM User**, alongside **Trust an AWS Account** and **Trust an IAM Role**. The wizard asks for the source account identifier, then for each IAM user name in turn, up to 5 users. MFA is required at assume-time. Available in both the CDK and Terraform variants.

### Changed

- Lowered the minimum NodeJS requirement from 22 to **20** (`engines.node` is now `>=20`), so the wizard and deployment run on the NodeJS version shipped by default on Amazon Linux 2023 and on older customer machines. Both READMEs now state NodeJS 20+.

## [3.3.0] - 2026-07-31

### Changed

- The KMS Customer Managed Key and the SNS alert topic are now created on first use instead of unconditionally.
- Replaced `ts-node` with `tsx` as the TypeScript runner for the CDK app and the wizard, in both the CDK and Terraform variants.
- Moved `typescript` to `devDependencies` and upgraded it to 7.0.2.
- Removed `source-map-support`, which nothing imported.
- Bumped dependencies: AWS SDK v3 clients, `aws-cdk` / `aws-cdk-lib`, `constructs`, `@smithy/*`, and the `oxlint` / `oxfmt` toolchain.

### Fixed

- Bumped `aws-cdk-lib` to 2.263.0, which ships the patched `brace-expansion` and clears CVE-2026-14257.

## [3.2.1] - 2026-07-23

### Changed

- Bumped `aws-cdk-lib` from 2.261.0 to 2.262.0 (resolves the bundled `brace-expansion` advisory).

## [3.2.0] - 2026-07-22

### Added

- The GitLab CI pipeline now runs the full vitest suite and a TypeScript type-check on every commit, so dependency upgrades and code changes are regression-checked before they ship. The suite runs entirely offline and needs no AWS credentials.

### Changed

- Removed the `postinstall` compile step. Nothing consumed its output: the wizard, synth, and deploy all run from source through ts-node. Installs are faster and no longer depend on lifecycle scripts, and the type-check guard moved to CI.
- Bumped dependencies: AWS SDK v3 clients, `aws-cdk` / `aws-cdk-lib`, AWS Lambda Powertools, `constructs`, and the `oxlint` / `oxfmt` / `vitest` toolchain.
- Removed the unused `inquirer` and `@aws-sdk/client-ecr` dependencies, both leftovers from before the 2.1.0 refactor, shrinking the installed footprint.

### Fixed

- Raised the vitest hook timeout so the GuardDuty and Config rule synthesis tests no longer time out on slow CI runners.

## [3.1.0] - 2026-07-06

### Added

- The cross-account role trust policy now allows `sts:SetSourceIdentity`, so the accessing engineer's identity can be stamped onto the assumed session for CloudTrail attribution in the customer account.

### Changed

- The wizard lists the required Cross-Account Role first, and only offers components available in the target partition: AWS Budgets in the commercial partition, Amazon GuardDuty and Amazon Inspector everywhere except the European Sovereign Cloud.
- Moved the checkov suppressions into inline `#checkov:skip` comments next to the resources they annotate, so the justifications are visible to customers reviewing the Terraform.
- Split the shared development-environment guide into its own document linked from both READMEs, and dropped the obsolete CloudShell deploy section.

### Security

- Raised CloudTrail CloudWatch log retention from 30 days to 1 year to allow customers reviewing cloudtrail activity after the engagement. This also matches NIST recommendation.
- Locked down each VPC's default security group to deny all traffic (`aws_default_security_group` with no rules in Terraform, `restrictDefaultSecurityGroup` in CDK).

## [3.0.2] - 2026-07-04

A maintenance release.

### Changed

- Publish versioned GitLab releases on tag, with release notes from the changelog and the source archive attached automatically.

## [3.0.1] - 2026-07-04

A maintenance release.

### Changed

- Bumped dependencies: AWS SDK v3 clients, `@smithy/*`, `aws-cdk` / `aws-cdk-lib`, and the `oxlint` / `oxfmt` toolchain.

## [3.0.0] - 2026-06-06

Version 3.0.0 is the first step towards better tooling for the field. Over the past months and years, the code quality of the PEP had drifted — causing failed deploys with customers, vulnerable packages, duplication, and rough edges throughout. This release rebuilds the foundation.

### Added

- A new **Terraform variant** of the PEP, sharing the same wizard, configuration shape, and feature set as the CDK variant — for customers and teams who prefer Terraform over CDK.
- A new optional **Development Environment** (cloud-based VS Code server on EC2, accessed over SSM port-forwarding, with code-server or local VS Code via SSH-over-SSM), available in both variants.
- New **GitLab CI validation** — every commit is now exercised through SAST rules and unit tests, plus `terraform validate` for the Terraform variant.
- New **coding standards** enforced through `oxlint` and `oxfmt`, replacing ESLint.
- A `terraform-aws-modules/lambda/aws` 8.x-based Lambda packaging path for the Terraform variant, keeping Lambda parity (runtime, log retention, IMDSv2, encryption) with the CDK variant.

### Changed

- **Fully refactored codebase** — clearer construct boundaries, tighter types across the wizard and constructs, and consistent style across CDK and Terraform.
- Refactored the GenAI Config rules into a single declarative, partition-aware **rule catalog** as the source of truth, replacing the duplicated rule lists.
- Migrated the notification transformer Lambdas to **Powertools decorators** on a class-based handler, with structured logging and tracing.
- Bumped runtimes and pins: Lambda runtime `nodejs24.x`, AWS Provider `6.49.0`, Lambda module `8.x`, Node 22+ requirement.
- Migrated tests from Jest to **vitest** (4.x).
- **Trust an IAM Role** mode now takes the source role's **ARN** directly instead of a separate account id and role name — the account id is parsed from the ARN, so the operator provides a single value. The configuration field `role.sourceRoleName` is replaced by `role.sourceRoleArn` (CDK) / `source_role_arn` (Terraform). **Trust an AWS Account** mode is unchanged.
- Updated wording across the project — removed Prototype Architect-specific phrasing so the documentation reflects use by **DevTx and CDE teams** as well.
- Promoted `aws-cdk`, `aws-cdk-lib`, `constructs`, `typescript`, `ts-node`, and `esbuild` to runtime `dependencies` to match how the project is built and deployed.

### Fixed

- Fully updated all dependencies — **no known vulnerable packages**, clean SBOM.
- Functional **code-server bootstrap**: the cloud-init userdata now exports `HOME` before invoking the upstream installer, fixing the silent boot failure that produced an `ERR_EMPTY_RESPONSE` on first connect.
- Resolved deploy-blocking deprecations on the Terraform side (`data.aws_region.current.name`, `base64encode(local.user_data)`).
- Resolved a Bedrock guardrails check bug where unpaginated `ListGuardrails` results could miss guardrails and report a false-compliant account.
- Fixed AWS Budgets being skipped when only `AWS_REGION` (not `CDK_DEFAULT_REGION`) was set, by resolving the region through the shared `getRegion()` helper.
- Declared the previously-undeclared `@smithy/node-config-provider` and `@smithy/config-resolver` dependencies used by region resolution.
- Fixed Terraform `terraform destroy` blocked by `prevent_destroy` lifecycle rules on CloudTrail buckets — now `force_destroy` cleanly tears the stack down.

### Removed

- Dropped dead features and dead branches: the non-functional `ECR_NO_PUBLIC_ACCESS` custom Config rule and its Lambda, the deprecated `INSPECTOR_LAMBDA_CODE_SCAN_ENABLED` rule, the unused `@aws-sdk/client-lambda` and `@aws-sdk/client-ecr-public` dependencies, the workspace S3 bucket on the Dev Environment, and GovCloud-specific Inspector branching that was no longer required.
- Dropped the deprecated `logRetention`, `installLatestAwsSdk`, and `base64encode` paths to silence CDK / Terraform synth warnings.

## [2.0.2] - 2024-02-26

### Added

- Upgraded NodeJS in several lambda functions as NodeJS14 runtime was no longer working.

## [2.0.1] - 2023-09-08

### Added

- Upgraded npm package versions to address npm audit vulnerabilites. Added a section in README on using AWS CloudShell for deploying PEP. Bumping mimnimum Node version to 18+

## [2.0.0] - 2023-05-03

### Added

- The PEP is now AWS CDK v2.x project, it no longer depends on AWS CDK v1.x

## [1.0.0] - 2021-05-15

### Added

- AWS Config module management to deploy selected config rules to the sandbox account.
- AWS CloudTrail module management to audit actions on the sandbox account.
- AWS Budgets management to monitor the cost of a prototype on the sandbox account.
- Cross-account role management to allow Prototyping Teams to access the sandbox account.
- Security rules management to protect the sandbox account.
- Notification channels management to alert individuals part of the prototype.
- VPC endpoints support.
- Initial modular structure of the Prototype Engagement pack reading from a configuration file.
- A wizard allowing users to generate a configuration file.
