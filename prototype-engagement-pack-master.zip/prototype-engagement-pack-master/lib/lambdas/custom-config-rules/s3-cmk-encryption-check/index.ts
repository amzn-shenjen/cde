import { S3Client, GetBucketEncryptionCommand } from '@aws-sdk/client-s3';
import { KMSClient, DescribeKeyCommand } from '@aws-sdk/client-kms';
import { ComplianceType } from '@aws-sdk/client-config-service';
import { Logger } from '@aws-lambda-powertools/logger';
import { putEvaluation } from '../helpers';

import type { ConfigRuleEvent } from '../helpers';
import type { Evaluation } from '@aws-sdk/client-config-service';

/**
 * Powertools logger emitting structured JSON logs.
 */
const logger = new Logger({
  serviceName: 'pep-s3-cmk-encryption-check'
});

/**
 * S3 server-side-encryption algorithm that denotes KMS-based
 * encryption. Buckets using `AES256` (SSE-S3) never qualify as
 * customer-managed.
 */
const KMS_SSE_ALGORITHM = 'aws:kms';

/**
 * `KeyManager` value returned by `DescribeKey` for keys the
 * customer owns, as opposed to AWS-managed keys (e.g. `aws/s3`).
 */
const CUSTOMER_KEY_MANAGER = 'CUSTOMER';

/**
 * Resource type emitted by AWS Config for S3 buckets. The rule
 * only evaluates resources of this type.
 */
const S3_BUCKET_RESOURCE_TYPE = 'AWS::S3::Bucket';

/**
 * Shared S3 client, reused across invocations within the same
 * Lambda execution environment.
 */
const s3Client = new S3Client({});

/**
 * Shared KMS client, reused across invocations within the same
 * Lambda execution environment.
 */
const kmsClient = new KMSClient({});

/**
 * The AWS Config configuration item carried in the invoking
 * event, narrowed to the fields this rule reads.
 */
type ConfigurationItem = {

  /**
   * Resource type of the evaluated resource, e.g.
   * `AWS::S3::Bucket`.
   */
  resourceType: string;

  /**
   * Stable identifier of the evaluated resource, reported back
   * to AWS Config as the compliance resource id.
   */
  resourceId: string;

  /**
   * Human-readable resource name — the S3 bucket name used to
   * look up the bucket's encryption configuration.
   */
  resourceName: string;
};

/**
 * The AWS Config rule invocation event for this handler.
 * Extends the shared `ConfigRuleEvent` (which carries the
 * `resultToken`) with the stringified invoking-event payload.
 */
type S3EncryptionCheckEvent = ConfigRuleEvent & {

  /**
   * JSON-encoded invoking event. Parsed to extract the
   * `configurationItem` describing the changed resource.
   */
  invokingEvent: string;
};

/**
 * Outcome of evaluating a single bucket — the compliance
 * verdict plus a human-readable annotation. Both fields are
 * always present, unlike the SDK's looser `Evaluation` shape.
 */
type BucketEvaluation = Required<Pick<Evaluation, 'ComplianceType' | 'Annotation'>>;

/**
 * AWS Config custom-rule handler that flags S3 buckets whose
 * default encryption does not use a customer-managed KMS key.
 *
 * The flow is:
 * 1. Parse the invoking event and read its configuration item.
 * 2. Short-circuit non-bucket resources as `NOT_APPLICABLE`.
 * 3. Evaluate the bucket's default encryption configuration.
 * 4. Report the verdict back to AWS Config via `putEvaluation`.
 *
 * @param event - The AWS Config rule invocation event.
 * @throws When the invoking event carries no configuration item.
 */
export const handler = async (event: S3EncryptionCheckEvent): Promise<void> => {
  const invokingEvent = JSON.parse(event.invokingEvent) as {
    configurationItem?: ConfigurationItem;
  };
  const configurationItem = invokingEvent.configurationItem;

  // A missing configuration item means the event is malformed.
  if (!configurationItem) {
    throw new Error('No configuration item found in the invoking event');
  }

  // Config scopes this rule to S3 buckets.
  if (configurationItem.resourceType !== S3_BUCKET_RESOURCE_TYPE) {
    await putEvaluation(event, {
      ComplianceType: ComplianceType.Not_Applicable,
      Annotation: 'Resource is not an S3 bucket',
      ComplianceResourceId: configurationItem.resourceId,
      ComplianceResourceType: configurationItem.resourceType
    });
    return;
  }

  // Evaluate the bucket.
  const evaluation = await evaluateBucket(configurationItem.resourceName);

  // Store the result of the evaluation.
  await putEvaluation(event, {
    ...evaluation,
    ComplianceResourceId: configurationItem.resourceId,
    ComplianceResourceType: configurationItem.resourceType
  });
};

/**
 * Evaluates whether a bucket's default encryption uses a
 * customer-managed KMS key. A bucket is compliant only when at
 * least one default-encryption rule applies `aws:kms` with a key
 * whose `KeyManager` is `CUSTOMER`. Any error is treated as
 * `NOT_APPLICABLE` so a transient failure does not flip a bucket
 * to non-compliant.
 *
 * @param bucketName - Name of the S3 bucket to evaluate.
 * @returns The compliance verdict and its annotation.
 */
const evaluateBucket = async (bucketName: string): Promise<BucketEvaluation> => {
  try {
    const response = await s3Client.send(
      new GetBucketEncryptionCommand({ Bucket: bucketName })
    );
    const encryptionRules = response.ServerSideEncryptionConfiguration?.Rules ?? [];

    for (const rule of encryptionRules) {
      const sseAlgorithm = rule.ApplyServerSideEncryptionByDefault?.SSEAlgorithm;
      const kmsMasterKeyId = rule.ApplyServerSideEncryptionByDefault?.KMSMasterKeyID;

      // Only KMS-encrypted rules with a key id can be customer-managed.
      if (sseAlgorithm === KMS_SSE_ALGORITHM && kmsMasterKeyId) {
        const keyDetails = await kmsClient.send(
          new DescribeKeyCommand({ KeyId: kmsMasterKeyId })
        );

        if (keyDetails.KeyMetadata?.KeyManager === CUSTOMER_KEY_MANAGER) {
          return ({
            ComplianceType: ComplianceType.Compliant,
            Annotation: `Bucket ${bucketName} is encrypted with a Customer Managed Key`
          });
        }
      }
    }

    return ({
      ComplianceType: ComplianceType.Non_Compliant,
      Annotation: `Bucket ${bucketName} is not encrypted with a Customer Managed Key`
    });
  } catch (error) {
    logger.error(`Error evaluating bucket ${bucketName}`, { error });
    return ({
      ComplianceType: ComplianceType.Not_Applicable,
      Annotation: `Error evaluating bucket ${bucketName}: ${error}`
    });
  }
};
