import { ComplianceType } from '@aws-sdk/client-config-service';
import { Logger } from '@aws-lambda-powertools/logger';
import { putEvaluation } from '../helpers';

import type { ConfigRuleEvent } from '../helpers';
import type { GuardrailSummary } from '@aws-sdk/client-bedrock';
import type { Evaluation } from '@aws-sdk/client-config-service';

import {
  BedrockClient,
  GetGuardrailCommand,
  paginateListGuardrails
} from '@aws-sdk/client-bedrock';

/**
 * Powertools logger emitting structured JSON logs.
 */
const logger = new Logger({
  serviceName: 'pep-bedrock-guardrails-check'
});

/**
 * Compliance resource id reported to AWS Config. This is an
 * account-level rule, so a single synthetic resource stands in
 * for the account's guardrail posture.
 */
const COMPLIANCE_RESOURCE_ID = 'BedrockGuardrails';

/**
 * Compliance resource type reported to AWS Config for the
 * account-level evaluation.
 */
const COMPLIANCE_RESOURCE_TYPE = 'AWS::::Account';

/**
 * Shared Bedrock client, reused across invocations within the
 * same Lambda execution environment.
 */
const bedrockClient = new BedrockClient({});

/**
 * The compliance verdict and annotation produced by the
 * evaluation. Both fields are always present, unlike the SDK's
 * looser `Evaluation` shape.
 */
type GuardrailEvaluation = Required<Pick<Evaluation, 'ComplianceType' | 'Annotation'>>;

/**
 * AWS Config custom-rule handler that flags an account whose
 * Bedrock guardrails do not all enforce PII protection.
 *
 * No API reports whether Bedrock itself is "enabled", so for
 * GenAI engagements this rule treats the presence of guardrails
 * — each configured with a sensitive-information (PII) policy —
 * as the compliance signal. The account is:
 * - `NON_COMPLIANT` when no guardrails exist, or when any
 *   guardrail lacks PII entities.
 * - `COMPLIANT` when every guardrail enforces PII.
 * - `NOT_APPLICABLE` when the evaluation itself errors, so a
 *   transient Bedrock failure does not flip the account to
 *   non-compliant.
 *
 * @param event - The AWS Config rule invocation event.
 */
export const handler = async (event: ConfigRuleEvent): Promise<void> => {
  const evaluation = await evaluateGuardrails();

  await putEvaluation(event, {
    ...evaluation,
    ComplianceResourceId: COMPLIANCE_RESOURCE_ID,
    ComplianceResourceType: COMPLIANCE_RESOURCE_TYPE
  });
};

/**
 * Lists every guardrail in the account and decides the
 * compliance verdict.
 */
const evaluateGuardrails = async (): Promise<GuardrailEvaluation> => {
  try {
    const guardrails = await listAllGuardrails();

    if (guardrails.length === 0) {
      return ({
        ComplianceType: ComplianceType.Non_Compliant,
        Annotation: 'No Bedrock guardrails are in place. Enable Bedrock Guardrails including the PII check (required).'
      });
    }

    const guardrailsWithoutPii = await findGuardrailsWithoutPii(guardrails);

    if (guardrailsWithoutPii.length > 0) {
      return ({
        ComplianceType: ComplianceType.Non_Compliant,
        Annotation: `Not all guardrails protect against PII. Please add this as a check to the following guardrails: ${guardrailsWithoutPii.join(', ')}`
      });
    }

    return ({
      ComplianceType: ComplianceType.Compliant,
      Annotation: 'Bedrock guardrails are in place and check for PII.'
    });
  } catch (error) {
    logger.error('Error during evaluation', { error });
    return ({
      ComplianceType: ComplianceType.Not_Applicable,
      Annotation: `Error during evaluation: ${error}`
    });
  }
};

/**
 * Lists every guardrail in the account, following pagination so
 * guardrails beyond the first page are not missed.
 */
const listAllGuardrails = async (): Promise<GuardrailSummary[]> => {
  const guardrails: GuardrailSummary[] = [];

  for await (const page of paginateListGuardrails({ client: bedrockClient }, {})) {
    guardrails.push(...(page.guardrails ?? []));
  }

  return (guardrails);
};

/**
 * Returns the names of guardrails that do not enforce any PII
 * entities. A guardrail without a sensitive-information policy,
 * or with an empty `piiEntities` list, is considered missing
 * PII protection.
 *
 * @param guardrails - Guardrail summaries to inspect.
 * @returns Names of the guardrails lacking PII protection.
 */
const findGuardrailsWithoutPii = async (
  guardrails: readonly GuardrailSummary[]
): Promise<string[]> => {
  const details = await Promise.all(guardrails.map(async (guardrail) => {
    const response = await bedrockClient.send(new GetGuardrailCommand({
      guardrailIdentifier: guardrail.id,
      guardrailVersion: guardrail.version
    }));
    return ({ guardrail, response });
  }));

  return (details
    .filter(({ response }) => {
      const piiEntities = response.sensitiveInformationPolicy?.piiEntities;
      return (!piiEntities || piiEntities.length === 0);
    })
    .map(({ guardrail }) => guardrail.name ?? 'guardrail name unknown'));
};
