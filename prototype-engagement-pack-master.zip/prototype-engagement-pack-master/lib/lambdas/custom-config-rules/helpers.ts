import type { Evaluation } from '@aws-sdk/client-config-service';
import {
  ConfigServiceClient,
  PutEvaluationsCommand
} from '@aws-sdk/client-config-service';

/**
 * The AWS Config invocation event delivered to a custom-rule
 * Lambda.
 */
export type ConfigRuleEvent = {

  /**
   * Opaque token forwarded back to `PutEvaluations` so the
   * service can correlate the response with its invocation.
   */
  resultToken: string;
};

/**
 * Caller-facing evaluation input.
 */
type EvaluationInput =
  & Omit<Evaluation, 'OrderingTimestamp' | 'ComplianceType'>
  & Required<Pick<Evaluation, 'ComplianceType'>>;

/**
 * The AWS Config client.
 */
const configClient = new ConfigServiceClient({});

/**
 * Reports a single evaluation result to AWS Config.
 * @param event - Inbound Config-rule invocation event (carries `resultToken`).
 * @param evaluation - The evaluation to report.
 */
export const putEvaluation = async (
  event: ConfigRuleEvent,
  evaluation: EvaluationInput
): Promise<void> => {
  await configClient.send(new PutEvaluationsCommand({
    ResultToken: event.resultToken,
    Evaluations: [{
      ...evaluation,
      OrderingTimestamp: new Date()
    }]
  }));
};
