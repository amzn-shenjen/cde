import { Construct } from 'constructs';
import { RemovalPolicy } from 'aws-cdk-lib';
import { Effect, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import type { Stack } from 'aws-cdk-lib';

import {
  AwsCustomResource,
  AwsCustomResourcePolicy,
  PhysicalResourceId,
} from 'aws-cdk-lib/custom-resources';

/**
 * The properties expected by the stack protection construct.
 */
export type IStackProtectionProps = {
  
  /**
   * The stack that needs to be protected.
   */
  stack: Stack;
};

export class StackProtectionConstruct extends Construct {
  
  /**
   * Enables stack protection for the Prototype Engagement Pack.
   * @param scope the construct scope.
   * @param id the identifier given the construct.
   * @param props the construct configuration.
   */
  constructor(scope: Construct, id: string, props: IStackProtectionProps) {
    super(scope, id);

    // The resource identifier associated with the custom resource.
    const resourceId = PhysicalResourceId.of('termination-protection');

    // CloudWatch log group for the custom resource handler.
    const logGroup = new LogGroup(this, 'StackTerminationProtectionLogGroup', {
      retention: RetentionDays.ONE_WEEK,
      removalPolicy: RemovalPolicy.DESTROY
    });

    // Protects the given stack from being accidentally terminated.
    new AwsCustomResource(this, 'StackTerminationProtection', {
      onCreate: {
        service: 'CloudFormation',
        action: 'updateTerminationProtection',
        parameters: {
          EnableTerminationProtection: true,
          StackName: props.stack.stackName,
        },
        physicalResourceId: resourceId,
      },
      policy: AwsCustomResourcePolicy.fromStatements([
        new PolicyStatement({
          effect: Effect.ALLOW,
          actions: ['cloudformation:UpdateTerminationProtection'],
          resources: [props.stack.stackId],
        }),
      ]),
      logGroup
    });
  }
}
