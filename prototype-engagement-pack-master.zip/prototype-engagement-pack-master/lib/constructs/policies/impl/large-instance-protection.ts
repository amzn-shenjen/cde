import { Construct } from 'constructs';
import { MetricFilter } from 'aws-cdk-lib/aws-logs';
import { Duration, Stack } from 'aws-cdk-lib';
import { PolicyStatement, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { SnsAction } from 'aws-cdk-lib/aws-cloudwatch-actions';

import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { CloudTrailConstruct } from '../../cloudtrail';
import type { IKey } from 'aws-cdk-lib/aws-kms';

import {
  Alarm,
  ComparisonOperator,
  Metric,
  TreatMissingData,
} from 'aws-cdk-lib/aws-cloudwatch';

/**
 * The name of the alarm to create for large instances.
 */
const ALARM_NAME = 'Large EC2 Instance Usage';

/**
 * The properties expected by the large instance protection construct.
 */
export type ILargeInstanceProtectionProps = {
  
  /**
   * The CloudTrail construct that is optionally used by policies
   * to create metric filters and AWS CloudWatch alarms.
   */
  cloudtrail: CloudTrailConstruct;

  /**
   * An SNS topic to which alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;
};

export class LargeInstanceProtectionConstruct extends Construct {
  
  /**
   * Creates a CloudWatch alarm monitoring creation of large
   * EC2 instances.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props the stack configuration.
   */
  constructor(
    scope: Construct,
    id: string,
    props: ILargeInstanceProtectionProps
  ) {
    super(scope, id);

    // A metric filter looking for large EC2 instances
    // and creates a CloudWatch metric that can be queried
    // by an AWS CloudWatch alarm.
    new MetricFilter(this, 'MetricFilter', {
      logGroup: props.cloudtrail.logGroup,
      filterPattern: {
        logPatternString: `{ (($.eventName = RunInstances) || ($.eventName = StartInstances)) &&
        (($.requestParameters.instanceType = *.32xlarge) || ($.requestParameters.instanceType = *.24xlarge) ||
        ($.requestParameters.instanceType = *.18xlarge) || ($.requestParameters.instanceType = *.16xlarge) ||
        ($.requestParameters.instanceType = *.12xlarge) || ($.requestParameters.instanceType = *.10xlarge) ||
        ($.requestParameters.instanceType = *.9xlarge) || ($.requestParameters.instanceType = *.8xlarge) ||
        ($.requestParameters.instanceType = *.4xlarge)) }`,
      },
      metricNamespace: 'CloudTrailMetrics',
      metricName: 'EC2LargeInstanceEventCount',
    });

    // A CloudWatch alarm that monitors usage of large EC2 instances.
    const alarm = new Alarm(this, 'Alarm', {
      alarmName: ALARM_NAME,
      alarmDescription:
        'A CloudWatch Alarm that triggers if a usage of an EC2 large instance is detected.',
      metric: new Metric({
        namespace: 'CloudTrailMetrics',
        metricName: 'EC2LargeInstanceEventCount',
        statistic: 'Sum',
        period: Duration.minutes(1),
      }),
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator: ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: TreatMissingData.MISSING
    });

    // Allowing AWS Budget to publish on the given topic.
    props.topic.grantPublish(
      new ServicePrincipal('cloudwatch.amazonaws.com', {
        conditions: {
          ArnLike: {
            'aws:SourceArn': `arn:${Stack.of(this).partition}:cloudwatch:${
              Stack.of(this).region
            }:${Stack.of(this).account}:alarm:${ALARM_NAME}`
          }
        }
      })
    );

    // Applying a policy on the key allowing the Log Group
    // to use the key to encrypt and decrypt it.
    props.key.addToResourcePolicy(
      new PolicyStatement({
        principals: [new ServicePrincipal('cloudwatch.amazonaws.com')],
        actions: ['kms:Decrypt*', 'kms:GenerateDataKey*'],
        resources: ['*'],
      })
    );

    // Adding the SNS topic as an action for the alarm.
    alarm.addAlarmAction(new SnsAction(props.topic));
  }
}
