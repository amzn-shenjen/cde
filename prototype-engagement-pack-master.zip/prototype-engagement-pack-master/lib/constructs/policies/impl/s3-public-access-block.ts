import { RemovalPolicy, Stack } from 'aws-cdk-lib';
import { Effect, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import {
  AwsCustomResource,
  AwsCustomResourcePolicy,
  PhysicalResourceId,
} from 'aws-cdk-lib/custom-resources';

export class S3PublicAccessBlockConstruct extends Construct {
  
  /**
   * Enable account-wide S3 public block.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props the stack configuration.
   */
  constructor(scope: Construct, id: string) {
    super(scope, id);

    // The resource identifier associated with the custom resource.
    const resourceId = PhysicalResourceId.of('PutPublicAccessBlock');

    // CloudWatch log group for the custom resource handler.
    const logGroup = new LogGroup(this, 'PublicAccessBlockLogGroup', {
      retention: RetentionDays.ONE_WEEK,
      removalPolicy: RemovalPolicy.DESTROY
    });

    // Creating the custom resource used to restrict S3 public access block.
    new AwsCustomResource(this, 'PublicAccessBlock', {
      onCreate: {
        service: 'S3Control',
        action: 'putPublicAccessBlock',
        parameters: {
          AccountId: Stack.of(this).account,
          PublicAccessBlockConfiguration: {
            BlockPublicAcls: true,
            BlockPublicPolicy: true,
            IgnorePublicAcls: true,
            RestrictPublicBuckets: true,
          },
        },
        physicalResourceId: resourceId,
      },
      policy: AwsCustomResourcePolicy.fromStatements([
        new PolicyStatement({
          effect: Effect.ALLOW,
          actions: ['s3:PutAccountPublicAccessBlock'],
          resources: ['*'],
        }),
      ]),
      logGroup
    });
  }
}
