import { S3PublicAccessBlockConstruct } from './impl/s3-public-access-block';
import { StackProtectionConstruct } from './impl/stack-protection';
import { LargeInstanceProtectionConstruct } from './impl/large-instance-protection';
import { Construct } from 'constructs';

import type { IConfiguration } from '../../../helpers/validators/configuration';
import type { CloudTrailConstruct } from '../cloudtrail';
import type { Stack } from 'aws-cdk-lib';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IKey } from 'aws-cdk-lib/aws-kms';

/**
 * The properties expected by the notification construct.
 */
export type ISecurityPoliciesProps = {
  
  /**
   * The stack that needs to be protected.
   */
  stack: Stack;

  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * The CloudTrail construct that is optionally used by policies
   * to create metric filters and AWS CloudWatch alarms.
   */
  cloudtrail?: CloudTrailConstruct;

  /**
   * An SNS topic to which alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;
};

export class SecurityPoliciesConstruct extends Construct {
  /**
   * Applies the defined security policies.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   */
  constructor(scope: Construct, id: string, props: ISecurityPoliciesProps) {
    super(scope, id);

    // Enabling account-wide S3 public access block.
    if (props.configuration.securityPolicies?.enableS3PublicAccessBlock === true) {
      new S3PublicAccessBlockConstruct(this, 'PublicAccessBlockConstruct');
    }

    // Creating the stack protection construct.
    if (props.configuration.securityPolicies?.enableStackProtection) {
      new StackProtectionConstruct(this, 'StackProtection', {
        stack: props.stack,
      });
    }

    // Creating the large instance protection construct.
    if (
      props.configuration.securityPolicies?.enableLargeInstanceProtection &&
      props.cloudtrail
    ) {
      new LargeInstanceProtectionConstruct(this, 'LargeInstanceProtection', {
        cloudtrail: props.cloudtrail,
        topic: props.topic,
        key: props.key,
      });
    }
  }
}
