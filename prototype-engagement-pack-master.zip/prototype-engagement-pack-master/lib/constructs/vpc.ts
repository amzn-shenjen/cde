import { Construct } from 'constructs';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';
import {
  InterfaceVpcEndpointAwsService,
  Peer,
  Port,
  SecurityGroup,
  SubnetType,
  Vpc
} from 'aws-cdk-lib/aws-ec2';

export class VpcConstruct extends Construct {
  
  /**
   * The VPC created as part of the construct.
   */
  public readonly vpc: IVpc;

  /**
   * Creates a cross-account role allowing the AWS team
   * to access customer accounts by assuming the role.
   * @param scope the construct scope.
   * @param id the identifier given the construct.
   * @param props the construct configuration.
   */
  constructor(scope: Construct, id: string) {
    super(scope, id);

    // Creating the VPC in which VPC endpoints will be deployed.
    this.vpc = new Vpc(this, 'Vpc', {
      enableDnsSupport: true,
      enableDnsHostnames: true,
      restrictDefaultSecurityGroup: true,
      maxAzs: 2,
      natGateways: 1,
      subnetConfiguration: [{
        name: 'public-subnet',
        subnetType: SubnetType.PUBLIC,
      }, {
        name: 'private-subnet',
        subnetType: SubnetType.PRIVATE_WITH_EGRESS,
      }]
    });

    // The default security group associated with VPC endpoints.
    const defaultSecurityGroup = new SecurityGroup(this, 'VpcEndpointSecurityGroup', {
      description: 'A security group for AWS VPC endpoints.',
      vpc: this.vpc,
      allowAllOutbound: false
    });

    // Allowing outbound HTTPS traffic.
    defaultSecurityGroup.addEgressRule(
      Peer.anyIpv4(),
      Port.tcp(443),
      'Provides egress access on port 443'
    );

    // Adding the CloudWatch Logs VPC Endpoint.
    this.vpc.addInterfaceEndpoint('logs', {
      service: InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS,
      privateDnsEnabled: true,
      securityGroups: [defaultSecurityGroup],
    });

    // Adding the KMS VPC Endpoint.
    this.vpc.addInterfaceEndpoint('kms', {
      service: InterfaceVpcEndpointAwsService.KMS,
      privateDnsEnabled: true,
      securityGroups: [defaultSecurityGroup],
    });
  }
}
