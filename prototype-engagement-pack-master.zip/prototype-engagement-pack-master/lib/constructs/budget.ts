import { Construct } from 'constructs';
import { ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { CfnBudget } from 'aws-cdk-lib/aws-budgets';
import { CURRENCY } from '../../helpers/currency';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IConfiguration } from '../../helpers/validators/configuration';
import type { IKey } from 'aws-cdk-lib/aws-kms';

/**
 * The properties expected by the budget construct.
 */
export type IBudgetProps = {
  
  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * An SNS topic to which budget alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;
};

export class BudgetConstruct extends Construct {
  
  /**
   * This construct creates an AWS Budget on a customer AWS account, and configures it
   * according to the given configuration (i.e budget limits and thresholds).
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   */
  constructor(scope: Construct, id: string, props: IBudgetProps) {
    super(scope, id);

    if (!props.configuration.budget) {
      return;
    }

    // Allowing AWS Budget to publish on the given topic.
    props.topic.grantPublish(
      new ServicePrincipal('budgets.amazonaws.com')
    );

    // Allowing AWS Budget to use the KMS key to publish on an encrypted SNS topic.
    props.key.grantEncryptDecrypt(
      new ServicePrincipal('budgets.amazonaws.com')
    );

    // Creating a budget for the Prototype engagement.
    new CfnBudget(this, 'Budget', {
      budget: {
        budgetName: 'prototype-budget',
        budgetType: 'COST',
        timeUnit: 'MONTHLY',
        budgetLimit: {
          unit: CURRENCY,
          amount: props.configuration.budget?.limit
        }
      },
      notificationsWithSubscribers: [
        {
          notification: {
            comparisonOperator: 'GREATER_THAN',
            notificationType: 'ACTUAL',
            threshold: 80,
            thresholdType: 'PERCENTAGE',
          },
          subscribers: [
            {
              subscriptionType: 'SNS',
              address: props.topic.topicArn,
            }
          ]
        },
        {
          notification: {
            comparisonOperator: 'GREATER_THAN',
            notificationType: 'ACTUAL',
            threshold: 100,
            thresholdType: 'PERCENTAGE',
          },
          subscribers: [
            {
              subscriptionType: 'SNS',
              address: props.topic.topicArn,
            }
          ]
        }
      ]
    });
  }
}
