import { Construct } from 'constructs';
import { Trail } from 'aws-cdk-lib/aws-cloudtrail';
import { RemovalPolicy, Stack } from 'aws-cdk-lib';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';

import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IConfiguration } from '../../helpers/validators/configuration';
import type { ILogGroup } from 'aws-cdk-lib/aws-logs';
import type { IBucket} from 'aws-cdk-lib/aws-s3';

import {
  Effect,
  PolicyStatement,
  ServicePrincipal
} from 'aws-cdk-lib/aws-iam';
import {
  BlockPublicAccess,
  Bucket,
  BucketEncryption
} from 'aws-cdk-lib/aws-s3';

/**
 * The properties expected by the CloudTrail construct.
 */
export type ICloudTrailProps = {
  
  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;
};

export class CloudTrailConstruct extends Construct {
  
  /**
   * The created AWS CloudTrail trail.
   */
  public readonly trail: Trail;

  /**
   * The created AWS CloudWatch log group to which
   * AWS CloudTrail will write.
   */
  public readonly logGroup: ILogGroup;

  /**
   * The created S3 bucket to which AWS CloudTrail
   * will write.
   */
  public readonly bucket: IBucket;

  /**
   * Creates a CloudTrail trail on the target AWS account, and configures it
   * to record all API actions globally in a secured, encrypted bucket.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props the stack configuration.
   */
  constructor(scope: Construct, id: string, props: ICloudTrailProps) {
    super(scope, id);

    // The bucket in which access logs associated wth the trail
    // bucket will be stored.
    const accessLogsBucket = new Bucket(this, 'AccessLogsBucket', {
      removalPolicy: RemovalPolicy.RETAIN,
      encryption: BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
      versioned: true
    });

    // The bucket in which Cloudtrail will persist the
    // authenticated actions that are taking place on
    // an AWS account.
    this.bucket = new Bucket(this, 'TrailBucket', {
      removalPolicy: RemovalPolicy.RETAIN,
      encryption: BucketEncryption.KMS,
      encryptionKey: props.key,
      enforceSSL: true,
      blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
      serverAccessLogsBucket: accessLogsBucket,
      versioned: true
    });

    // Allowing AWS CloudTrail to get the bucket ACL.
    this.bucket.addToResourcePolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        principals: [new ServicePrincipal('cloudtrail.amazonaws.com')],
        actions: ['s3:GetBucketAcl'],
        resources: [this.bucket.bucketArn]
      })
    );

    // Allowing AWS CloudTrail to put objects in the bucket.
    this.bucket.addToResourcePolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        principals: [new ServicePrincipal('cloudtrail.amazonaws.com')],
        actions: ['s3:PutObject'],
        resources: [
          this.bucket.arnForObjects(`AWSLogs/${Stack.of(this).account}/*`)
        ]
      })
    );

    // Allowing CloudTrail to encrypt logs using the provided KMS key.
    props.key.grantEncrypt(new ServicePrincipal('cloudtrail.amazonaws.com'));

    // The CloudWatch Log Group to which CloudTrail will send
    // logs.
    this.logGroup = new LogGroup(this, 'TrailLogGroup', {
      encryptionKey: props.key,
      retention: RetentionDays.ONE_YEAR
    });

    // Applying a policy on the key allowing the Log Group
    // to use the key to encrypt and decrypt it.
    props.key.addToResourcePolicy(
      new PolicyStatement({
        principals: [
          new ServicePrincipal(`logs.${Stack.of(this).region}.amazonaws.com`)
        ],
        actions: [
          'kms:Encrypt*',
          'kms:Decrypt*',
          'kms:ReEncrypt*',
          'kms:GenerateDataKey*',
          'kms:Describe*',
        ],
        resources: ['*'],
        conditions: {
          ArnEquals: {
            'kms:EncryptionContext:aws:logs:arn': `arn:${
              Stack.of(this).partition
            }:logs:${Stack.of(this).region}:${
              Stack.of(this).account
            }:log-group:*`
          }
        }
      })
    );

    // The AWS CloudTrail trail that keeps track of actions executed
    // by principals on the account.
    new Trail(this, 'Trail', {
      isMultiRegionTrail: props.configuration.cloudtrail?.multiRegion === true,
      includeGlobalServiceEvents: true,
      enableFileValidation: true,
      encryptionKey: props.key,
      sendToCloudWatchLogs: true,
      cloudWatchLogGroup: this.logGroup,
      bucket: this.bucket
    });
  }
}
