#!/bin/bash

# System packages used across both IDE modes.
dnf update -y
dnf install -y nodejs npm jq git python-pip docker

# Lets `git` push to / pull from S3-backed repos.
pip3 install git-remote-s3

# Workspace directory the IDE opens into.
mkdir -p /workspace
chown -R ec2-user:ec2-user /workspace
