# Export HOME.
export HOME=/root

# Install Code Server.
curl -fsSL https://code-server.dev/install.sh | sh

# Fetch the password the construct generated in Secrets Manager.
PASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id "$CODE_SERVER_SECRET_ARN" \
  --query SecretString --output text \
  | jq -r .password)

# Write the code-server config under the `ec2-user` home.
mkdir -p /home/ec2-user/.config/code-server
cat > /home/ec2-user/.config/code-server/config.yaml <<'EOF'
bind-addr: 127.0.0.1:8080
auth: password
password: __PASSWORD__
cert: false
EOF
sed -i "s|__PASSWORD__|${PASSWORD}|" /home/ec2-user/.config/code-server/config.yaml
chown -R ec2-user:ec2-user /home/ec2-user/.config

# Run code-server as a systemd service.
cat > /etc/systemd/system/code-server.service <<'EOF'
[Unit]
Description=code-server
After=network.target

[Service]
Type=simple
User=ec2-user
WorkingDirectory=/home/ec2-user
Environment=PATH=/usr/local/bin:/usr/bin:/bin
ExecStart=/usr/bin/code-server --config /home/ec2-user/.config/code-server/config.yaml
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable code-server
systemctl start code-server
