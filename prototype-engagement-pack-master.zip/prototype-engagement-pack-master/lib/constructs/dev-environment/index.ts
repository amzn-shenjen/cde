import * as fs from 'node:fs';
import * as path from 'node:path';

import { CfnOutput, Stack } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Secret } from 'aws-cdk-lib/aws-secretsmanager';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IConfiguration } from '../../../helpers/validators/configuration';

import {
  BlockDeviceVolume,
  EbsDeviceVolumeType,
  Instance,
  InstanceType,
  MachineImage,
  Subnet,
  SubnetType,
  UserData,
  Vpc
} from 'aws-cdk-lib/aws-ec2';
import {
  ManagedPolicy,
  Role,
  ServicePrincipal
} from 'aws-cdk-lib/aws-iam';
import type {
  InstanceProps,
  ISubnet,
  IVpc,
  SubnetSelection
} from 'aws-cdk-lib/aws-ec2';

/**
 * Properties expected by the dev-environment construct.
 */
export type IDevEnvironmentProps = {

  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * KMS key used to encrypt resources.
   */
  key: IKey;
};

/**
 * Default disk-space allocation, in GB.
 */
const DEFAULT_DISK_GB = 50;

/**
 * Default EC2 instance type.
 */
const DEFAULT_INSTANCE_TYPE = 'm5.xlarge';

/**
 * Default IDE access method.
 */
const DEFAULT_IDE_TYPE: 'code-server' | 'vscode-ssh' = 'code-server';

export class DevEnvironmentConstruct extends Construct {

  /**
   * Deploys an EC2-based development environment for the prototype:
   * an IDE (VS Code-server or VS Code over SSM-SSH), a workspace S3
   * bucket, and the IAM role plus optional VPC required to run them.
   * @param scope the construct scope.
   * @param id the identifier of the construct.
   * @param props the construct configuration.
   */
  constructor(scope: Construct, id: string, props: IDevEnvironmentProps) {
    super(scope, id);

    if (!props.configuration.devEnvironment?.enabled) {
      return;
    }

    const region = Stack.of(this).region;
    const devEnv = props.configuration.devEnvironment;

    // Resolve dev-environment defaults.
    const diskSpaceGb = devEnv.diskSpaceGb ?? DEFAULT_DISK_GB;
    const instanceType = devEnv.instanceType ?? DEFAULT_INSTANCE_TYPE;
    const ideType = devEnv.ideType ?? DEFAULT_IDE_TYPE;

    // Reuse an existing VPC and subnet when provided; otherwise
    // create a dedicated VPC with a public + private subnet pair.
    let vpc: IVpc;
    let subnet: ISubnet | undefined;

    if (devEnv.vpcId && devEnv.subnetId && devEnv.availabilityZone) {
      vpc = Vpc.fromLookup(this, 'ExistingVpc', { vpcId: devEnv.vpcId });
      subnet = Subnet.fromSubnetAttributes(this, 'ExistingSubnet', {
        subnetId: devEnv.subnetId,
        availabilityZone: devEnv.availabilityZone
      });
    } else {
      vpc = new Vpc(this, 'PrototypeDevVpc', {
        enableDnsSupport: true,
        enableDnsHostnames: true,
        restrictDefaultSecurityGroup: true,
        maxAzs: 2,
        natGateways: 1,
        subnetConfiguration: [{
          name: 'public',
          subnetType: SubnetType.PUBLIC
        }, {
          name: 'private',
          subnetType: SubnetType.PRIVATE_WITH_EGRESS
        }]
      });
    }

    // Generate a code-server password in Secrets Manager when the
    // browser-based IDE is selected.
    const codeServerSecret = ideType === 'code-server'
      ? new Secret(this, 'CodeServerSecret', {
        description: 'Password for VS Code server authentication',
        encryptionKey: props.key,
        generateSecretString: {
          secretStringTemplate: JSON.stringify({ username: 'admin' }),
          generateStringKey: 'password',
          excludeCharacters: '"@/\\\'',
          includeSpace: false,
          passwordLength: 30
        }
      })
      : undefined;

    // IAM role for the EC2 instance.
    const instanceRole = new Role(this, 'InstanceRole', {
      assumedBy: new ServicePrincipal('ec2.amazonaws.com'),
      description: 'IAM role for prototype development EC2 instance',
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore')
      ]
    });

    // On code server, grant read to the secret in AWS Secrets Manager.
    if (codeServerSecret) {
      codeServerSecret.grantRead(instanceRole);
    }

    // Load the base provisioning script.
    const userData = UserData.forLinux();
    userData.addCommands(
      fs.readFileSync(path.join(__dirname, 'user-data', 'base.sh'), 'utf8')
    );

    if (ideType === 'code-server' && codeServerSecret) {
      userData.addCommands(
        // The code-server bootstrap reads these from the environment.
        `export CODE_SERVER_SECRET_ARN='${codeServerSecret.secretArn}'`,
        `export AWS_DEFAULT_REGION='${region}'`,
        fs.readFileSync(path.join(__dirname, 'user-data', 'code-server.sh'), 'utf8')
      );
    }

    // EC2 instance.
    const vpcSubnets: SubnetSelection = subnet
      ? { subnets: [subnet] }
      : { subnetType: SubnetType.PRIVATE_WITH_EGRESS };

    const instanceConfig: InstanceProps = {
      vpc,
      instanceType: new InstanceType(instanceType),
      machineImage: MachineImage.latestAmazonLinux2023(),
      role: instanceRole,
      userData,
      vpcSubnets,
      requireImdsv2: true,
      blockDevices: [{
        deviceName: '/dev/xvda',
        volume: BlockDeviceVolume.ebs(diskSpaceGb, {
          encrypted: true,
          volumeType: EbsDeviceVolumeType.GP3
        })
      }]
    };

    const instance = new Instance(this, 'PrototypeDevInstance', instanceConfig);
    instance.node.addMetadata(
      'Description',
      'Prototype development instance accessible via SSM'
    );

    // Stack outputs documenting how to reach the instance.
    if (ideType === 'code-server' && codeServerSecret) {
      new CfnOutput(this, 'CodeServerInfo', {
        value: `aws ssm start-session --region ${region} --target ${instance.instanceId} --document-name AWS-StartPortForwardingSession --parameters 'portNumber=8080,localPortNumber=8080'`,
        description: 'Command to access VS Code server via SSM port forwarding'
      });

      new CfnOutput(this, 'CodeServerPasswordConsoleLink', {
        value: `https://${region}.console.aws.amazon.com/secretsmanager/secret?name=${codeServerSecret.secretName}&region=${region}`,
        description: 'AWS Console link to view the VS Code server password'
      });

      new CfnOutput(this, 'CodeServerLocalUrl', {
        value: 'http://localhost:8080/?folder=/workspace',
        description: 'Localhost URL to open code-server after SSM tunneling'
      });
    } else if (ideType === 'vscode-ssh') {
      new CfnOutput(this, 'VSCodeSSHInfo', {
        value: `aws ssm start-session --region ${region} --target ${instance.instanceId}`,
        description: 'Command to connect to the instance via SSM for VS Code SSH access'
      });
    }
  }
}
