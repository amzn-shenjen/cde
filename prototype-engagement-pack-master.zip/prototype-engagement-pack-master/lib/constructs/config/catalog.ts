import { MaximumExecutionFrequency } from 'aws-cdk-lib/aws-config';
import { CustomConfigRuleNames } from '../../../helpers/validators/config';
import { S3CmkEncryptionCheckConstruct } from './custom-checks/s3-cmk-encryption-check';
import { BedrockGuardrailsCheckConstruct } from './custom-checks/guardrails-enabled';

import type { Construct } from 'constructs';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

/**
 * The AWS partitions the Prototype Engagement Pack
 * supports about for rule availability.
 */
export type Partition =
  | 'aws'
  | 'aws-us-gov'
  | 'aws-eusc'
  | 'aws-cn';

/**
 * Wizard screens a rule may be surfaced through.
 */
export type ScreenCategory =
  | 'config'
  | 'genai';

/**
 * Identifier used by the AWS Config managed rule that gates VPC
 * endpoint coverage. All `vpc-endpoint` catalog entries deploy
 * under this single source identifier with a unique service
 * parameter.
 */
export const VPC_ENDPOINT_GATE_RULE = 'SERVICE_VPC_ENDPOINT_ENABLED';

/**
 * Identifier of the custom Bedrock guardrails check.
 */
export const BEDROCK_GUARDRAILS_CHECK_ID = 'BEDROCK_GUARDRAILS_CHECK';

/**
 * The set of every supported partition.
 */
const ALL_PARTITIONS: readonly Partition[] = [
  'aws',
  'aws-us-gov',
  'aws-eusc',
  'aws-cn'
];

/**
 * Per-screen presence and default-selection metadata.
 */
type CategoryPresence = {

  /**
   * Whether the rule is selected by default when the screen
   * surfaces it.
   */
  defaultSelected: boolean;
};

/**
 * Map of screens that surface the rule, with per-screen
 * default-selection metadata.
 */
type Categories = Partial<Record<ScreenCategory, CategoryPresence>>;

/**
 * Fields shared by every catalog entry, regardless of kind.
 */
type BaseEntry = {

  /**
   * Stable identifier used as the catalog key, the wizard's
   * prompt value, and the entry id persisted in
   * `prototype.context.json`.
   */
  id: string;

  /**
   * Human-readable description rendered next to the id in the
   * wizard prompt.
   */
  description: string;

  /**
   * Partitions in which the rule is supported. The wizard
   * disables the option outside this set; the construct silently
   * skips it at synth time so a hand-edited config never crashes
   * a deploy.
   */
  partitions: readonly Partition[];

  /**
   * Wizard screens that surface the entry.
   */
  categories: Categories;
};

/**
 * Managed AWS Config rule.
 */
export type ManagedRuleEntry = BaseEntry & {
  kind: 'managed';

  /**
   * Periodic evaluation cadence, when applicable.
   */
  maximumExecutionFrequency?: MaximumExecutionFrequency;

  /**
   * Whether the rule may be paired with an automatic remediation.
   * Today the only remediation is the S3 public-bucket fix; the
   * remediation construct itself decides which ids it can handle.
   */
  remediable?: boolean;
};

/**
 * Custom Lambda-backed AWS Config rule.
 */
export type CustomRuleEntry = BaseEntry & {
  kind: 'custom';

  /**
   * Factory that creates the construct backing the rule. Always
   * called with the optional VPC; the construct decides whether
   * to use it.
   */
  build: (scope: Construct, id: string, vpc?: IVpc) => void;
};

/**
 * Managed VPC endpoint rule. All entries of this kind deploy
 * under the same `SERVICE_VPC_ENDPOINT_ENABLED` source identifier,
 * differentiated by `serviceShortName`.
 */
export type VpcEndpointRuleEntry = BaseEntry & {
  kind: 'vpc-endpoint';

  /**
   * Service suffix of the VPC endpoint, e.g. `s3`, `bedrock`,
   * `ecr.api`. The full service name is resolved at deploy time
   * from the partition and region.
   */
  serviceShortName: string;
};

/**
 * One entry in the rule catalog.
 */
export type CatalogEntry =
  | ManagedRuleEntry
  | CustomRuleEntry
  | VpcEndpointRuleEntry;

/**
 * Resolves the full VPC endpoint service name for an entry in
 * the active region.
 * Note that ECR endpoints in the EUSC partition are
 * prefixed with `eu` instead of `com`; every other endpoint
 * uses `com`.
 * @param entry - The catalog entry to resolve.
 * @param region - AWS region of the deployment.
 */
export const getVpcEndpointServiceName = (
  entry: VpcEndpointRuleEntry,
  region: string
) => {
  const isEusc = region.startsWith('eusc-');
  const isEcr = entry.serviceShortName.startsWith('ecr.');
  const prefix = isEusc && isEcr ? 'eu' : 'com';
  return (`${prefix}.amazonaws.${region}.${entry.serviceShortName}`);
};

/**
 * Constructs a stable, partition-independent id for a VPC
 * endpoint rule based on its service short name.
 * @param serviceShortName - Service suffix, e.g. `bedrock-runtime`.
 */
const vpcEndpointId = (serviceShortName: string) => {
  const suffix = serviceShortName.toUpperCase().replace(/[.-]/g, '_');
  return (`${VPC_ENDPOINT_GATE_RULE}_${suffix}`);
};

/**
 * The complete catalog of selectable AWS Config rules. Rules
 * that appear in both the `config` and `genai` screens have
 * both keys populated; per-screen `defaultSelected` controls
 * the wizard's initial selection.
 *
 * Order drives the order shown in the wizard prompt — `config`
 * rules first, then GenAI-only additions, then VPC endpoints.
 */
export const RULE_CATALOG: readonly CatalogEntry[] = [
  {
    kind: 'managed',
    id: 'S3_BUCKET_PUBLIC_READ_PROHIBITED',
    description: 'Checks if S3 buckets disallow public read access',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: true } },
    maximumExecutionFrequency: MaximumExecutionFrequency.SIX_HOURS,
    remediable: true
  },
  {
    kind: 'managed',
    id: 'S3_BUCKET_PUBLIC_WRITE_PROHIBITED',
    description: 'Checks if S3 buckets disallow public write access',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: true } },
    maximumExecutionFrequency: MaximumExecutionFrequency.SIX_HOURS,
    remediable: true
  },
  {
    kind: 'managed',
    id: 'IAM_USER_MFA_ENABLED',
    description: 'Checks whether IAM users have MFA enabled',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { config: { defaultSelected: true } },
    maximumExecutionFrequency: MaximumExecutionFrequency.SIX_HOURS
  },
  {
    kind: 'managed',
    id: 'MFA_ENABLED_FOR_IAM_CONSOLE_ACCESS',
    description: 'Checks whether MFA is enabled for all IAM users',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { config: { defaultSelected: true } },
    maximumExecutionFrequency: MaximumExecutionFrequency.SIX_HOURS
  },
  {
    kind: 'managed',
    id: 'RDS_INSTANCE_PUBLIC_ACCESS_CHECK',
    description: 'Check whether RDS instances are not public',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'RDS_SNAPSHOTS_PUBLIC_PROHIBITED',
    description: 'Checks if RDS snapshots are public',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'EC2_INSTANCE_NO_PUBLIC_IP',
    description: 'Checks whether EC2 instances have a public IP association',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'REDSHIFT_CLUSTER_PUBLIC_ACCESS_CHECK',
    description: 'Checks if Redshift clusters are not public',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'EMR_MASTER_NO_PUBLIC_IP',
    description: "Checks if EMR clusters' master nodes have public IPs",
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'INCOMING_SSH_DISABLED',
    description: 'Checks if the incoming SSH traffic for the security groups is accessible',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'EC2_VOLUME_INUSE_CHECK',
    description: 'Checks if EBS volumes are attached to EC2 instances',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'EIP_ATTACHED',
    description: 'Checks if all Elastic IP addresses are in use',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'SAGEMAKER_NOTEBOOK_NO_DIRECT_INTERNET_ACCESS',
    description: 'Checks whether Amazon SageMaker notebook instances are not public',
    partitions: ['aws', 'aws-us-gov'],
    categories: { config: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'RDS_STORAGE_ENCRYPTED',
    description: 'Checks whether RDS DB instances are encrypted',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'ENCRYPTED_VOLUMES',
    description: 'Checks if EBS volumes are encrypted',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'DYNAMODB_TABLE_ENCRYPTION_ENABLED',
    description: 'Checks if DynamoDB tables are encrypted',
    partitions: ['aws', 'aws-cn'],
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'ELASTICSEARCH_ENCRYPTED_AT_REST',
    description: 'Checks if Elasticsearch domains have encryption enabled',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'ELASTICSEARCH_NODE_TO_NODE_ENCRYPTION_CHECK',
    description: 'Checks that ElasticSearch nodes are encrypted end to end',
    partitions: ['aws', 'aws-eusc'],
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'EFS_ENCRYPTED_CHECK',
    description: 'Checks if Amazon EFS is configured to encrypt data using AWS KMS',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'SNS_ENCRYPTED_KMS',
    description: 'Checks if SNS topics are encrypted with AWS KMS',
    partitions: ['aws', 'aws-eusc', 'aws-cn'],
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'S3_BUCKET_SERVER_SIDE_ENCRYPTION_ENABLED',
    description: 'Checks that your S3 buckets are encrypted',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: false } }
  },
  {
    kind: 'managed',
    id: 'LAMBDA_INSIDE_VPC',
    description: 'Checks if Lambda functions are VPC-enabled',
    partitions: ALL_PARTITIONS,
    categories: {
      config: { defaultSelected: false },
      genai: { defaultSelected: true }
    }
  },
  {
    kind: 'managed',
    id: 'OPENSEARCH_IN_VPC_ONLY',
    description: 'Checks if OpenSearch domains are in a VPC',
    partitions: ['aws', 'aws-cn'],
    categories: {
      config: { defaultSelected: false },
      genai: { defaultSelected: true }
    }
  },
  {
    kind: 'managed',
    id: 'GUARDDUTY_ENABLED_CENTRALIZED',
    description: 'Checks if GuardDuty is enabled',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: {
      config: { defaultSelected: false },
      genai: { defaultSelected: true }
    }
  },
  {
    kind: 'managed',
    id: 'APPSYNC_ASSOCIATED_WITH_WAF',
    description: 'Checks if AppSync APIs are associated with WAF',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'INSPECTOR_EC2_SCAN_ENABLED',
    description: 'Checks if Inspector EC2 scanning is enabled',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'INSPECTOR_LAMBDA_STANDARD_SCAN_ENABLED',
    description: 'Checks if Inspector Lambda standard scanning is enabled',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'INSPECTOR_ECR_SCAN_ENABLED',
    description: 'Checks if Inspector ECR scanning is enabled',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'SAGEMAKER_NOTEBOOK_INSTANCE_INSIDE_VPC',
    description: 'Checks if SageMaker notebook instances are inside a VPC',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'SAGEMAKER_DOMAIN_IN_VPC',
    description: 'Checks if SageMaker domains are in a VPC',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'SAGEMAKER_NOTEBOOK_INSTANCE_ROOT_ACCESS_CHECK',
    description: 'Checks if SageMaker notebook instance root access is controlled',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'managed',
    id: 'API_GWV2_AUTHORIZATION_TYPE_CONFIGURED',
    description: 'Checks if API Gateway v2 routes have authorization configured',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } }
  },
  {
    kind: 'custom',
    id: CustomConfigRuleNames.s3Cmk,
    description: 'Checks if S3 buckets are encrypted with a customer managed key',
    partitions: ALL_PARTITIONS,
    categories: {
      config: { defaultSelected: false },
      genai: { defaultSelected: true }
    },
    build: (scope, id, vpc) => {
      new S3CmkEncryptionCheckConstruct(scope, id, vpc);
    }
  },
  {
    kind: 'custom',
    id: BEDROCK_GUARDRAILS_CHECK_ID,
    description: 'Checks if Bedrock guardrails are in place',
    partitions: ['aws', 'aws-cn'],
    categories: { genai: { defaultSelected: true } },
    build: (scope, id, vpc) => {
      new BedrockGuardrailsCheckConstruct(scope, id, vpc);
    }
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('ssm'),
    description: 'Checks if AWS Systems Manager VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { config: { defaultSelected: false } },
    serviceShortName: 'ssm'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('s3'),
    description: 'Checks if S3 VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: {
      config: { defaultSelected: false },
      genai: { defaultSelected: true }
    },
    serviceShortName: 's3'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('bedrock'),
    description: 'Checks if Bedrock VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'bedrock'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('bedrock-runtime'),
    description: 'Checks if Bedrock Runtime VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'bedrock-runtime'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('bedrock-agent'),
    description: 'Checks if Bedrock Agent VPC endpoints are enabled in the VPC',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'bedrock-agent'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('bedrock-agent-runtime'),
    description: 'Checks if Bedrock Agent Runtime VPC endpoints are enabled in the VPC',
    partitions: ['aws', 'aws-us-gov', 'aws-cn'],
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'bedrock-agent-runtime'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('batch'),
    description: 'Checks if Batch VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'batch'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('ecr.api'),
    description: 'Checks if ECR API VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'ecr.api'
  },
  {
    kind: 'vpc-endpoint',
    id: vpcEndpointId('ecr.dkr'),
    description: 'Checks if ECR DKR VPC endpoints are enabled in the VPC',
    partitions: ALL_PARTITIONS,
    categories: { genai: { defaultSelected: true } },
    serviceShortName: 'ecr.dkr'
  }
];

/**
 * O(1) lookup of catalog entries by id.
 */
export const CATALOG_BY_ID: ReadonlyMap<string, CatalogEntry> = new Map(
  RULE_CATALOG.map((entry) => [entry.id, entry])
);

/**
 * Returns every catalog entry surfaced through the given screen.
 * @param category - The wizard screen the slice is for.
 */
export const entries = (category: ScreenCategory) => {
  return (RULE_CATALOG.filter((entry) => entry.categories[category] !== undefined));
};

/**
 * Returns whether a catalog entry is supported in the active
 * partition.
 * @param entry - The catalog entry to check.
 * @param partition - The active AWS partition.
 */
export const isSupportedInPartition = (
  entry: CatalogEntry,
  partition: Partition
) => {
  return (entry.partitions.includes(partition));
};
