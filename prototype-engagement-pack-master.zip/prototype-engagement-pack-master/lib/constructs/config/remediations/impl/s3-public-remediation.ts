import { Construct } from 'constructs';
import { CfnRemediationConfiguration } from 'aws-cdk-lib/aws-config';
import type { Remediation } from '../remediation';
import type { ManagedRule } from 'aws-cdk-lib/aws-config';
import {
  Effect,
  ManagedPolicy,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';

/**
 * SSM Automation document used to disable public read/write on
 * non-compliant S3 buckets.
 * @see https://docs.aws.amazon.com/systems-manager-automation-runbooks/latest/userguide/automation-aws-disables3bucketpublicreadwrite.html
 */
const AUTOMATION_DOCUMENT = 'AWS-DisableS3BucketPublicReadWrite';

/**
 * AWS Config managed-rule identifiers handled by this remediation.
 */
const SUPPORTED_RULES: readonly string[] = [
  'S3_BUCKET_PUBLIC_READ_PROHIBITED',
  'S3_BUCKET_PUBLIC_WRITE_PROHIBITED'
];

/**
 * A remediation construct implementing automation to disable
 * public access on S3 buckets.
 */
export class S3PublicRemediation extends Construct implements Remediation {

  /**
   * The IAM role used to remediate public S3 buckets.
   */
  private role: Role;

  /**
   * Entry point for the remediation action.
   * @param ruleId the identifier of the AWS Config rule.
   * @param ruleInstance the managed rule associated with the rule identifier.
   */
  public handle(ruleId: string, ruleInstance: ManagedRule): boolean {
    if (SUPPORTED_RULES.includes(ruleId)) {
      this.execute(ruleId, ruleInstance);
      return (true);
    }
    return (false);
  }

  /**
   * Deploys the required resources to remediate supported
   * non-compliant AWS Config rules.
   * @param ruleId the identifier of the AWS Config rule.
   * @param ruleInstance the managed rule associated with the rule identifier.
   */
  private execute(ruleId: string, ruleInstance: ManagedRule) {
    // If the role for the remediation does not exist, we create it.
    if (!this.role) {
      this.role = new Role(this, 'S3PublicWriteReadProhibitedRole', {
        description:
          'Allows SSM to remove public read and write access on public buckets.',
        assumedBy: new ServicePrincipal('ssm.amazonaws.com'),
        managedPolicies: [
          ManagedPolicy.fromAwsManagedPolicyName(
            'service-role/AmazonSSMAutomationRole'
          ),
        ],
      });

      // Allowing the role to update the non-compliant bucket ACLs and
      // public access block.
      this.role.addToPolicy(
        new PolicyStatement({
          effect: Effect.ALLOW,
          actions: [
            's3:GetBucketAcl',
            's3:GetBucketPolicy',
            's3:PutBucketAcl',
            's3:PutBucketPolicy',
            's3:PutBucketPublicAccessBlock',
          ],
          resources: ['*']
        })
      );
    }

    // Creating the remediation action.
    new CfnRemediationConfiguration(
      this,
      `Remediation-${ruleId}`,
      {
        automatic: true,
        configRuleName: ruleInstance.configRuleName,
        targetType: 'SSM_DOCUMENT',
        targetId: AUTOMATION_DOCUMENT,
        maximumAutomaticAttempts: 5,
        retryAttemptSeconds: 60,
        parameters: {
          AutomationAssumeRole: {
            StaticValue: {
              Values: [this.role.roleArn]
            },
          },
          S3BucketName: {
            ResourceValue: {
              Value: 'RESOURCE_ID'
            }
          }
        }
      }
    );
  }

  /**
   * Returns an array of AWS Config rules supported
   * by the remediation construct.
   */
  public getSupportedRules(): readonly string[] {
    return (SUPPORTED_RULES);
  }
}
