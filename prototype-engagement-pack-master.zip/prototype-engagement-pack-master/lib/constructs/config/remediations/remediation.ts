import type { ManagedRule } from 'aws-cdk-lib/aws-config';

/**
 * Describes the interface for a remediation construct.
 */
export type Remediation = {

  /**
   * Handles a given rule and deploys the required
   * resources to remediate rule non-compliance.
   * @param ruleId the identifier of the AWS Config rule.
   * @param ruleInstance the managed rule associated with the rule identifier.
   */
  handle(ruleId: string, ruleInstance: ManagedRule): boolean;

  /**
   * Returns an array of AWS Config rules supported
   * by the remediation construct.
   */
  getSupportedRules(): readonly string[];
};
