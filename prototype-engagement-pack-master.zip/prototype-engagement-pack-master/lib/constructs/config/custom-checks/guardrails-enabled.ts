import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as config from 'aws-cdk-lib/aws-config';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as path from 'path';

import { Construct } from 'constructs';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

export class BedrockGuardrailsCheckConstruct extends Construct {
  
  /**
   * `BedrockGuardrailsCheckConstruct` constructor.
   * @param scope the Construct scope
   * @param id the resource identifier
   * @param vpc an optional VPC to deploy the resources in.
   */
  constructor(scope: Construct, id: string, vpc?: IVpc) {
    super(scope, id);

    // CloudWatch log group for the Lambda.
    const logGroup = new LogGroup(this, 'BedrockGuardrailsCheckLogGroup', {
      retention: RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY
    });

    // Create the Lambda function.
    const lambdaFunction = new NodejsFunction(this, 'BedrockGuardrailsCheckFunction', {
      runtime: lambda.Runtime.NODEJS_24_X,
      handler: 'handler',
      entry: path.join(__dirname, '..', '..', '..', 'lambdas', 'custom-config-rules', 'guardrails-enabled', 'index.ts'),
      bundling: {
        minify: true,
        sourceMap: false,
        tsconfig: path.join(__dirname, '..', '..', '..', 'lambdas', 'custom-config-rules', 'guardrails-enabled', 'tsconfig.json'),
        forceDockerBundling: false,
        nodeModules: [
          '@aws-sdk/client-config-service',
          '@aws-sdk/client-bedrock'
        ],
        esbuildArgs: {
          '--bundle': '',
          '--platform': 'node'
        }
      },
      timeout: cdk.Duration.seconds(30),
      memorySize: 128,
      logGroup,
      vpc,
      vpcSubnets: vpc
        ? { subnets: vpc.privateSubnets }
        : undefined,
    })

    // Grant the Lambda function necessary permissions
    lambdaFunction.addToRolePolicy(new iam.PolicyStatement({
      actions: [
        'bedrock:ListGuardrails',
        'config:PutEvaluations',
        'bedrock:GetGuardrail'
      ],
      resources: ['*'],
    }));

    // Create the Config custom rule
    new config.CustomRule(this, 'BedrockGuardrailsCheckRule', {
      configRuleName: 'bedrock-guardrails-check',
      description: 'Checks if Bedrock guardrails are in place',
      lambdaFunction: lambdaFunction,
      periodic: true,
      maximumExecutionFrequency: config.MaximumExecutionFrequency.TWENTY_FOUR_HOURS,
      // This is a periodic check, not triggered by configuration changes.
      configurationChanges: false
    });
  }
}