import * as path from 'path';
import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as config from 'aws-cdk-lib/aws-config';
import * as iam from 'aws-cdk-lib/aws-iam';

import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

export class S3CmkEncryptionCheckConstruct extends Construct {
  
  /**
   * `S3CmkEncryptionCheckConstruct` constructor.
   * @param scope the Construct scope
   * @param id the resource identifier
   * @param vpc an optional VPC to deploy the resources in.
   */
  constructor(scope: Construct, id: string, vpc?: IVpc) {
    super(scope, id);

    // CloudWatch log group for the Lambda.
    const logGroup = new LogGroup(this, 'S3CmkEncryptionCheckLogGroup', {
      retention: RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY
    });

    // Create the Lambda function.
    const lambdaFunction = new NodejsFunction(this, 'S3CmkEncryptionCheckFunction', {
      runtime: lambda.Runtime.NODEJS_24_X,
      handler: 'handler',
      entry: path.join(__dirname, '..', '..', '..', 'lambdas', 'custom-config-rules', 's3-cmk-encryption-check', 'index.ts'),
      bundling: {
        minify: true,
        sourceMap: false,
        tsconfig: path.join(__dirname, '..', '..', '..', 'lambdas', 'custom-config-rules', 's3-cmk-encryption-check', 'tsconfig.json'),
        forceDockerBundling: false,
        nodeModules: [
          '@aws-sdk/client-config-service',
          '@aws-sdk/client-s3',
          '@aws-sdk/client-kms'
        ],
        esbuildArgs: {
          '--bundle': '',
          '--platform': 'node'
        }
      },
      timeout: cdk.Duration.seconds(30),
      memorySize: 128,
      logGroup,
      vpc,
      vpcSubnets: vpc
        ? { subnets: vpc.privateSubnets }
        : undefined,
    });

    // Grant the Lambda function permissions to describe S3 buckets
    lambdaFunction.addToRolePolicy(new iam.PolicyStatement({
      actions: ['s3:GetBucketEncryption', "s3:GetEncryptionConfiguration", 'kms:DescribeKey'],
      resources: ['*'],
    }));

    // Create the Config custom rule
    new config.CustomRule(this, 'S3CmkEncryptionCheckRule', {
      configRuleName: 's3-cmk-encryption-check',
      description: 'Checks if S3 buckets are encrypted with Customer Managed Keys',
      lambdaFunction: lambdaFunction,
      periodic: false,
      configurationChanges: true,
      ruleScope: config.RuleScope.fromResources([config.ResourceType.S3_BUCKET]),
    });
  }
}