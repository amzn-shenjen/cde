import { Construct } from 'constructs';
import { Stack } from 'aws-cdk-lib';
import { ManagedRule } from 'aws-cdk-lib/aws-config';
import { ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { Rule } from 'aws-cdk-lib/aws-events';
import { SnsTopic } from 'aws-cdk-lib/aws-events-targets';
import { S3PublicRemediation } from './remediations/impl/s3-public-remediation';
import { CATALOG_BY_ID, getVpcEndpointServiceName, isSupportedInPartition } from './catalog';
import { PARTITION } from '../../../helpers/partition';

import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';
import type { IConfiguration } from '../../../helpers/validators/configuration';
import type { ConfigRuleEntry } from '../../../helpers/validators/config';
import type { Remediation } from './remediations/remediation';
import type {
  CatalogEntry,
  CustomRuleEntry,
  ManagedRuleEntry,
  Partition,
  VpcEndpointRuleEntry
} from './catalog';

/**
 * Properties expected by the `ConfigConstruct`.
 */
export type IConfigProps = {

  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * SNS topic to which compliance changes will be sent.
   */
  topic: ITopic;

  /**
   * KMS key used to encrypt resources.
   */
  key: IKey;

  /**
   * Optional VPC in which custom-rule Lambda functions run.
   */
  vpc?: IVpc;
};

/**
 * One rule entry resolved against the catalog.
 */
type ResolvedRule = {
  rule: ConfigRuleEntry;
  entry: CatalogEntry;
};

/**
 * The `ConfigConstruct` deploys the AWS Config rules described in the
 * configuration on the sandbox account. Rules are looked up against
 * the shared rule catalog and dispatched on their kind — managed,
 * custom Lambda-backed, or VPC endpoint. An EventBridge rule forwards
 * non-compliant compliance changes to the shared SNS topic so the
 * notification channels can pick them up.
 */
export class ConfigConstruct extends Construct {

  /**
   * Deploys the described AWS Config rules from the configuration
   * and optionally executes remediation for non-compliant rules.
   * Creates an AWS EventBridge rule listening for compliance changes
   * and redirects them to the given SNS topic.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props the construct configuration.
   */
  constructor(scope: Construct, id: string, props: IConfigProps) {
    super(scope, id);

    const rules = props.configuration.config?.rules ?? [];
    if (rules.length === 0) {
      return;
    }

    // Allow AWS Config to publish on the SNS topic.
    props.topic.grantPublish(new ServicePrincipal('config.amazonaws.com'));

    // Allow AWS Config to encrypt configuration items using the provided KMS key.
    props.key.grantEncryptDecrypt(new ServicePrincipal('config.amazonaws.com'));

    // Resolve picks against the catalog.
    const resolved = this.resolve(rules);

    // Remediations are only meaningful for managed rules and are
    // not supported in EUSC.
    const remediations: Remediation[] = PARTITION === 'aws-eusc'
      ? []
      : [new S3PublicRemediation(this, 'S3PublicRemediation')];

    for (const item of resolved) {
      this.deployRule(item, remediations, props.vpc);
    }

    // Allow EventBridge to encrypt logs using the provided KMS key.
    props.key.grantEncryptDecrypt(new ServicePrincipal('events.amazonaws.com'));

    // Forward non-compliant compliance changes to the SNS topic.
    new Rule(this, 'ConfigRule', {
      description: 'Listens to events sent by AWS Config on compliance updates.',
      eventPattern: {
        source: ['aws.config'],
        detailType: ['Config Rules Compliance Change'],
        detail: {
          newEvaluationResult: {
            complianceType: ['NON_COMPLIANT']
          }
        }
      },
      targets: [new SnsTopic(props.topic)]
    });
  }

  /**
   * Resolves each persisted rule against the catalog, filtering
   * out unknown ids and ids unsupported in the active partition.
   * @param rules - The rule entries persisted in the configuration.
   */
  private resolve(rules: readonly ConfigRuleEntry[]): ResolvedRule[] {
    const partition = PARTITION as Partition;
    const resolved: ResolvedRule[] = [];

    for (const rule of rules) {
      const entry = CATALOG_BY_ID.get(rule.id);

      if (!entry || !isSupportedInPartition(entry, partition)) {
        continue;
      }
      resolved.push({ rule, entry });
    }

    return (resolved);
  }

  /**
   * Deploys one resolved rule, dispatching on its kind.
   * @param item - The resolved rule and its catalog entry.
   * @param remediations - The remediation handlers to consult for managed rules.
   * @param vpc - Optional VPC for custom rule Lambdas.
   */
  private deployRule(
    item: ResolvedRule,
    remediations: readonly Remediation[],
    vpc?: IVpc
  ): void {
    switch (item.entry.kind) {
      case 'managed':
        this.deployManagedRule(item.rule, item.entry, remediations);
        return;
      case 'custom':
        this.deployCustomRule(item.entry, vpc);
        return;
      case 'vpc-endpoint':
        this.deployVpcEndpointRule(item.entry);
        return;
    }
  }

  /**
   * Deploys a managed AWS Config rule and wires any matching
   * remediation.
   * @param rule - The rule entry from the configuration.
   * @param entry - The matching catalog entry.
   * @param remediations - The remediation handlers to consult.
   */
  private deployManagedRule(
    rule: ConfigRuleEntry,
    entry: ManagedRuleEntry,
    remediations: readonly Remediation[]
  ): void {
    const ruleInstance = new ManagedRule(this, `ManagedRule-${entry.id}`, {
      configRuleName: entry.id,
      identifier: entry.id,
      maximumExecutionFrequency: entry.maximumExecutionFrequency
    });

    if (rule.enableRemediation && entry.remediable) {
      for (const remediation of remediations) {
        remediation.handle(entry.id, ruleInstance);
      }
    }
  }

  /**
   * Deploys a custom Lambda-backed AWS Config rule.
   * @param entry - The matching catalog entry.
   * @param vpc - Optional VPC for the Lambda function.
   */
  private deployCustomRule(entry: CustomRuleEntry, vpc?: IVpc): void {
    entry.build(this, `CustomRule-${entry.id}`, vpc);
  }

  /**
   * Deploys a VPC endpoint AWS Config rule. All entries of this
   * kind use the `SERVICE_VPC_ENDPOINT_ENABLED` source identifier
   * and are differentiated by the `serviceName` input parameter.
   * @param entry - The matching catalog entry.
   */
  private deployVpcEndpointRule(entry: VpcEndpointRuleEntry): void {
    const region = Stack.of(this).region;
    
    new ManagedRule(this, `VpcEndpointRule-${entry.id}`, {
      configRuleName: entry.id,
      identifier: 'SERVICE_VPC_ENDPOINT_ENABLED',
      inputParameters: {
        serviceName: getVpcEndpointServiceName(entry, region)
      }
    });
  }
}
