import { Construct } from 'constructs';
import { PolicyStatement, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { Rule } from 'aws-cdk-lib/aws-events';
import { SnsTopic } from 'aws-cdk-lib/aws-events-targets';
import { AwsCustomResource, AwsCustomResourcePolicy } from 'aws-cdk-lib/custom-resources';
import { PARTITION } from '../../helpers/partition';

import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IConfiguration } from '../../helpers/validators/configuration';
import type { IKey } from 'aws-cdk-lib/aws-kms';

/**
 * The properties expected by the inspector construct.
 */
export type IInspectorProps = {
  
  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * An SNS topic to which guard duty alerts will be sent.
   */
  topic?: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key?: IKey;
};

export class InspectorConstruct extends Construct {
  /**
   * This construct enables Amazon Inspector  
   * and associates it with the SNS topic if given.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   */
  constructor(scope: Construct, id: string, props: IInspectorProps) {
    super(scope, id);

    if (!props.configuration.inspector) {
      return;
    }

    // Inspector is not available in EUSC
    if (PARTITION === 'aws-eusc') {
      console.warn('Amazon Inspector is not available in the aws-eusc partition. Skipping.');
      return;
    }

    // Standard scanning across EC2, ECR, and Lambda.
    const resourceTypes = ['ECR', 'EC2', 'LAMBDA'];

    // Custom CDK resource for enabling/disabling AWS Inspector.
    new AwsCustomResource(this, 'Inspector', {
      installLatestAwsSdk: true,
      onUpdate: {
        service: 'Inspector2',
        action: 'enable',
        physicalResourceId: { id: 'Inspector' },
        parameters: {
          resourceTypes
        }
      },
      onDelete: {
        service: 'Inspector2',
        action: 'disable',
        physicalResourceId: { id: 'Inspector' },
        parameters: {
          resourceTypes,
        },
      },
      policy: AwsCustomResourcePolicy.fromStatements([
        new PolicyStatement({
          actions: [
            'iam:CreateServiceLinkedRole',
            'inspector2:Enable',
            'inspector2:Disable',
          ],
          resources: AwsCustomResourcePolicy.ANY_RESOURCE,
        })
      ])
    });

    if (props.topic && props.key) {
      // Inspector publishes findings to EventBridge. We republish those events to the SNS topic
      // Allowing EventBridge to publish on the SNS topic
      props.topic.grantPublish(new ServicePrincipal('events.amazonaws.com'));
      props.key.grantEncryptDecrypt(
        new ServicePrincipal('events.amazonaws.com')
      );
      new Rule(this, 'InspectorFindings', {
        description: 'Listens to events sent by Amazon Inspector',
        eventPattern: {
          source: ['aws.inspector2'],
          detailType: ['Inspector2 Finding'],
          detail: {
            'severity': ['HIGH', 'CRITICAL'],
            'status': ['ACTIVE']
          }
        },
        targets: [new SnsTopic(props.topic)]
      });
    }
  }
}

