import { Construct } from 'constructs';
import { SlackChannelConfiguration } from 'aws-cdk-lib/aws-chatbot';
import { Stack } from 'aws-cdk-lib';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { ISlackProps } from '../../../../../helpers/validators/notification';

/**
 * The properties expected by the Slack notification construct.
 */
export type ISlackNotificationProps = {
  
  /**
   * An SNS topic to which budget alerts will be sent.
   */
  topic: ITopic;
};

export class SlackDestinationConstruct extends Construct {
  
  /**
   * Establishes a connection between the provided SNS topic and
   * the Slack integration provided by AWS Chatbot.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   * @param topic the SNS topic on which the Slack integration should listen.
   */
  constructor(
    scope: Construct,
    id: string,
    props: ISlackProps,
    inputs: ISlackNotificationProps
  ) {
    super(scope, id);

    // Creating a Slack connector listening to events flowing through
    // the given SNS topic.
    new SlackChannelConfiguration(this, 'SlackIntegration', {
      slackChannelConfigurationName: `slack-prototype-${Stack.of(this).region}`,
      notificationTopics: [inputs.topic],
      slackChannelId: props.slackChannelId,
      slackWorkspaceId: props.slackWorkspaceId,
    });
  }
}
