import path from 'path';

import { Construct } from 'constructs';
import { RemovalPolicy, Stack } from 'aws-cdk-lib';
import { Effect, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Runtime } from 'aws-cdk-lib/aws-lambda';
import { LambdaSubscription } from 'aws-cdk-lib/aws-sns-subscriptions';

import type { IEmailProps } from '../../../../../helpers/validators/notification';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

import {
  AwsCustomResource,
  AwsCustomResourcePolicy,
  PhysicalResourceId,
} from 'aws-cdk-lib/custom-resources';

/**
 * The properties expected by the E-mail notification construct.
 */
export type IEmailNotificationProps =  {
  
  /**
   * An SNS topic to which budget alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;

  /**
   * An optional VPC in which the Lambda function will be run.
   */
  vpc?: IVpc;
};

export class EmailDestinationConstruct extends Construct {
  
  /**
   * Deploys the required resources in order to enable customers
   * to leverage notifications and alerts via E-mails.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   * @param topic the SNS topic on which the Slack integration should listen.
   * @param key a KMS key used to encrypt resources.
   */
  constructor(
    scope: Construct,
    id: string,
    props: IEmailProps,
    inputs: IEmailNotificationProps
  ) {
    super(scope, id);

    // A set of all e-mail addresses to verify.
    const addresses = [props.sender, ...props.targets].filter(
      (value, idx, array) => array.indexOf(value) === idx
    );

    // For each e-mail targets defined in the configuration, we attempt
    // to verify the e-mail address within SES in order to be able to
    // send notification alerts to this e-mail address.
    addresses.forEach((target) => {
      
      // CloudWatch log group for the identity verification handler.
      const logGroup = new LogGroup(this, `IdentityLogGroup-${target}`, {
        retention: RetentionDays.ONE_WEEK,
        removalPolicy: RemovalPolicy.DESTROY
      });

      // Create the identity verification resource.
      new AwsCustomResource(this, `Identity-${target}`, {
        onCreate: {
          service: 'SES',
          action: 'verifyEmailIdentity',
          parameters: {
            EmailAddress: target,
          },
          physicalResourceId: PhysicalResourceId.of(`verify-${target}`),
        },
        onDelete: {
          service: 'SES',
          action: 'deleteIdentity',
          parameters: {
            Identity: target,
          },
        },
        policy: AwsCustomResourcePolicy.fromStatements([
          new PolicyStatement({
            effect: Effect.ALLOW,
            actions: ['ses:VerifyEmailIdentity', 'ses:DeleteIdentity'],
            resources: ['*'],
          }),
        ]),
        logGroup
      });
    });

    // The path to the transformer lambda function.
    const transformerPath = path.resolve(__dirname, 'lambdas', 'transformer');

    // The path to the static template, copied alongside the bundle so
    // `lib/index.ts` can read it at runtime.
    const templatePath = path.resolve(transformerPath, 'lib', 'static', 'template.html');

    // CloudWatch log group for the Lambda.
    const transformerLogGroup = new LogGroup(this, 'TransformerLogGroup', {
      retention: RetentionDays.ONE_MONTH,
      removalPolicy: RemovalPolicy.DESTROY
    });

    // Creating the Lambda function that will receive notifications
    // from the SNS topic, format the notifications and send them via e-mail.
    const transformer = new NodejsFunction(this, 'Transformer', {
      entry: path.resolve(transformerPath, 'index.ts'),
      description: 'Processes SNS notifications, transforms them into HTML messages and sends them by e-mail to the recepients.',
      runtime: Runtime.NODEJS_24_X,
      handler: 'handler',
      logGroup: transformerLogGroup,
      bundling: {
        nodeModules: [
          '@aws-lambda-powertools/logger',
          '@aws-lambda-powertools/tracer',
          '@aws-sdk/client-ses',
          'eta'
        ],
        commandHooks: {
          beforeBundling: () => [],
          beforeInstall: () => [],
          afterBundling: (_inputDir, outputDir) => [
            `mkdir -p ${outputDir}/static`,
            `cp ${templatePath} ${outputDir}/static/template.html`
          ]
        }
      },
      vpc: inputs.vpc,
      vpcSubnets: inputs.vpc
        ? { subnets: inputs.vpc.privateSubnets }
        : undefined,
      environmentEncryption: inputs.key,
      environment: {
        SENDER: props.sender,
        RECIPIENTS: JSON.stringify(props.targets),
      }
    });

    // Allowing the Lambda function to send e-mails to the specified targets.
    transformer.addToRolePolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        actions: ['ses:SendEmail'],
        resources: addresses.map(
          (target) =>
            `arn:${Stack.of(this).partition}:ses:${Stack.of(this).region}:${Stack.of(this).account}:identity/${target}`
        )
      })
    );

    // Subscribing the Lambda to the SNS topic.
    inputs.topic.addSubscription(new LambdaSubscription(transformer));
  }
}
