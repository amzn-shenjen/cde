import type { SNSEventRecord } from 'aws-lambda';
import type { TemplateParams } from '../factory';

/**
 * The shape of a CloudWatch alarm notification carried inside
 * the SNS `Message` payload.
 */
type CloudWatchAlarmEvent = {
  AlarmName: string;
  AlarmArn: string;
  AWSAccountId: string;
  Region: string;
  NewStateValue: string;
  NewStateReason: string;
  Trigger: {
    Namespace: string;
    MetricName: string;
    Dimensions?: Array<{
      name: string;
      value: string;
    }>;
  };
};

/**
 * @param message a cloudwatch alarm event.
 * @returns a  URL pointing to the CloudWatch console
 * for the given alarm.
 * @see https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html
 */
const getConsoleUrl = (message: CloudWatchAlarmEvent) => {
  const region  = message.AlarmArn.split(':')[3];
  const consoleUrl = new URL(`https://${region}.console.aws.amazon.com/cloudwatch/home`);

  consoleUrl.searchParams.set('region', region);
  consoleUrl.hash = `alarmsV2:alarm/${encodeURIComponent(message.AlarmName)}?~(alarmStateFilter~'ALARM)`;
  return (consoleUrl);
};

/**
 * Transforms the received CloudWatch Alarm into a description
 * to be used to generate the HTML e-mail.
 * @param record an SNS record.
 * @returns the template parameters associated
 * with this implementation.
 */
export const get = (record: SNSEventRecord): TemplateParams => {
  const message = JSON.parse(record.Sns.Message) as CloudWatchAlarmEvent;
  const url = getConsoleUrl(message);

  // An array containing details about the alarm.
  const array = [{
      key: 'Summary',
      value: message.NewStateValue === 'OK' ? 'An alert has been resolved' : 'A new alert has been triggered'
    }, {
      key: 'Account Details',
      value: `${message.AWSAccountId} (${message.Region})`
    }, {
      key: 'Reason',
      value: message.NewStateReason
    }, {
      key: 'Namespace',
      value: message.Trigger.Namespace
    }, {
      key: 'Metric',
      value: message.Trigger.MetricName
    }
  ];

  // Adding dimension data into the array.
  (message.Trigger.Dimensions || []).forEach((dimension) => array.push({ key: `Dimension (${dimension.name})`, value: dimension.value }));

  // Returning the description of the notification.
  return ({
    context: {
      title: 'CloudWatch Alarm Notification',
      description: 'Below are the data points associated with the CloudWatch Alarm notification.',
      elements: array,
      button: {
        text: 'See Alarm Details',
        url: url.toString()
      },
      help: {
        url: 'https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html'
      }
    }
  });
};

/**
 * @param record an SNS record.
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (record: SNSEventRecord): boolean => {
  let message: unknown = record.Sns.Message;

  // Attempting to parse the message as JSON.
  try {
    message = JSON.parse(record.Sns.Message);
  } catch {
    // The message is not in JSON.
  }

  return (typeof message === 'object'
    && message !== null
    && Boolean((message as { AlarmName?: unknown }).AlarmName)
    && Boolean((message as { NewStateValue?: unknown }).NewStateValue));
};
