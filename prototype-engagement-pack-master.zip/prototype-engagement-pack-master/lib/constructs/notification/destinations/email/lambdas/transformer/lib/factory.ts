import type { SNSEventRecord } from 'aws-lambda';

import * as budget from './impl/budget';
import * as config from './impl/config';
import * as cwAlarms from './impl/cw-alarms';
import * as defaultImpl from './impl/default-impl';

/**
 * The parameters used to render the e-mail HTML template.
 */
export type TemplateParams = {
  context: {
    title: string;
    description: string;
    elements: Array<{
      key: string;
      value: string;
    }>;
    button: {
      text: string;
      url: string;
    };
    help: {
      url: string;
    };
  };
};

/**
 * The contract every message implementation honours.
 */
export type Impl = {

  /**
   * @param record an SNS record.
   * @returns the template parameters associated with this
   * implementation.
   */
  get(record: SNSEventRecord): TemplateParams;

  /**
   * @param record an SNS record.
   * @returns whether the current implementation supports
   * the given record.
   */
  handles(record: SNSEventRecord): boolean;
};

/**
 * An array of implementations handling the different
 * messages that can be received from the SNS topic.
 */
const impl: Impl[] = [
  budget,
  config,
  cwAlarms,
  defaultImpl
];

/**
 * @param record an SNS record.
 * @returns the description associated with the given `record`.
 */
export const get = (record: SNSEventRecord): TemplateParams => {
  for (const handler of impl) {
    if (handler.handles(record)) {
      return (handler.get(record));
    }
  }

  throw new Error('No handler for the given record');
};
