import type { SNSEventRecord } from 'aws-lambda';
import type { TemplateParams } from '../factory';

/**
 * @param record an SNS record.
 * @returns the template parameters associated
 * with this implementation.
 */
export const get = (record: SNSEventRecord): TemplateParams => {
  const parts = record.Sns.Message.split('\n');
  return ({
    context: {
      title: 'AWS Budgets Notification',
      description: 'Below are the data points associated with the AWS Budgets notification.',
      elements: [{
          key: 'Budget Name',
          value: parts[7].split(': ')[1]
        }, {
          key: 'Budgeted Amount',
          value: parts[9].split(': ')[1]
        }, {
          key: 'Threshold',
          value: parts[10].split(': ')[1]
        }, {
          key: 'Actual Amount',
          value: parts[12].split(': ')[1]
        }
      ],
      button: {
        text: 'Open AWS Budgets',
        url: 'https://console.aws.amazon.com/billing/home#/budgets'
      },
      help: {
        url: 'https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/budgets-managing-costs.html'
      }
    }
  });
};

/**
 * @param record an SNS record.
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (record: SNSEventRecord): boolean => {
  return ((record.Sns.Subject || '').startsWith('AWS Budgets'));
};
