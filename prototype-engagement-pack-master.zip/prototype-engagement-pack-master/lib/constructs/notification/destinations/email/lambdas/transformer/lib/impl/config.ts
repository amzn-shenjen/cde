import type { SNSEventRecord } from 'aws-lambda';
import type { TemplateParams } from '../factory';

/**
 * The shape of an AWS Config notification carried inside the
 * SNS `Message` payload.
 */
type ConfigEvent = {
  source: string;
  account?: string;
  region?: string;
  detail: {
    messageType: string;
    configRuleName: string;
    resourceType: string;
    newEvaluationResult: {
      complianceType: string;
    };
  };
};

/**
 * @param message an AWS Config notification.
 * @returns a URL pointing to the AWS Config console for the given rule.
 */
const getConsoleUrl = (message: ConfigEvent) => {
  return (`https://console.aws.amazon.com/config/home#/rules/details`
    + `?configRuleName=${encodeURIComponent(message.detail.configRuleName)}`);
};

/**
 * @param record an SNS record.
 * @returns the template parameters associated
 * with this implementation.
 */
export const get = (record: SNSEventRecord): TemplateParams => {
  const message = JSON.parse(record.Sns.Message) as ConfigEvent;
  return ({
    context: {
      title: 'AWS Config Notification',
      description: 'Below are the data points associated with the AWS Config notification.',
      elements: [{
          key: 'Type',
          value: message.detail.messageType
        }, {
          key: 'Account',
          value: `${message.account} (${message.region})`
        }, {
          key: 'Rule',
          value: message.detail.configRuleName
        }, {
          key: 'Resource Type',
          value: message.detail.resourceType
        }, {
          key: 'Status',
          value: message.detail.newEvaluationResult.complianceType
        }
      ],
      button: {
        text: 'See Config Rule',
        url: getConsoleUrl(message)
      },
      help: {
        url: 'https://docs.aws.amazon.com/config/latest/developerguide/evaluate-config_use-managed-rules.html'
      }
    }
  });
};

/**
 * @param record an SNS record.
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (record: SNSEventRecord): boolean => {
  let message: unknown = record.Sns.Message;

  // Attempting to parse the message as JSON.
  try {
    message = JSON.parse(record.Sns.Message);
  } catch {
    // The message is not in JSON.
  }

  return (typeof message === 'object'
    && message !== null
    && (message as { source?: unknown }).source === 'aws.config');
};
