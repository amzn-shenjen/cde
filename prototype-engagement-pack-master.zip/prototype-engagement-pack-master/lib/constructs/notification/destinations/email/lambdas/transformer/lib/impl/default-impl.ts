import type { SNSEventRecord } from 'aws-lambda';
import type { TemplateParams } from '../factory';

/**
 * @param record an SNS record.
 * @returns the template parameters associated
 * with this implementation.
 */
export const get = (record: SNSEventRecord): TemplateParams => {
  const topic = record.Sns.TopicArn.split(':');
  return ({
    context: {
      title: 'SNS Notification',
      description: 'Below are the data points associated with the received notification.',
      elements: [{
          key: 'SNS Topic',
          value: topic[5]
        }, {
          key: 'Subject',
          value: record.Sns.Subject ?? ''
        }, {
          key: 'Event',
          value: record.Sns.Message
        }
      ],
      button: {
        text: 'View SNS Topic',
        url: `https://console.aws.amazon.com/sns/v3/home#/topic/${record.Sns.TopicArn}`
      },
      help: {
        url: 'https://docs.aws.amazon.com/sns/latest/dg/welcome.html'
      }
    }
  });
};

/**
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (): boolean => {
  return (true);
};
