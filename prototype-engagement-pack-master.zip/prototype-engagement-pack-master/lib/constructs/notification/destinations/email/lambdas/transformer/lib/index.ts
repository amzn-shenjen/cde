import * as fs from 'node:fs';
import * as path from 'node:path';
import * as factory from './factory';

import { Eta } from 'eta';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import type { SNSEventRecord } from 'aws-lambda';

/**
 * The sender address.
 */
const sender = process.env.SENDER;

/**
 * The array of recipients.
 */
const recipients = JSON.parse(process.env.RECIPIENTS ?? '[]') as string[];

/**
 * Creating the SES client.
 */
const sesClient = new SESClient({
  maxAttempts: 5,
  region: process.env.AWS_REGION
});

/**
 * The HTML template loaded once from the lambda bundle.
 */
const template = fs.readFileSync(
  path.resolve(__dirname, 'static', 'template.html'),
  'utf8'
);

/**
 * The Eta instance reused across invocations.
 */
const eta = new Eta();

/**
 * Creates an HTML message given a SNS record.
 * @param record the SNS record to process.
 * @returns the HTML message to send to recipients.
 */
export const createMessage = (record: SNSEventRecord): string => {
  // Retrieving the description from the handler.
  const params = factory.get(record);
  // Rendering the template.
  return (eta.renderString(template, params));
};

/**
 * Sends the generated message to the recipients.
 * @param html the HTML content of the e-mail.
 */
export const sendMessage = async (html: string) => {
  const command = new SendEmailCommand({
    Destination: {
      ToAddresses: recipients
    },
    Message: {
      Body: {
        Html: {
          Data: html
        }
      },
      Subject: { Data: 'Prototype Engagement Pack // Notification' }
    },
    Source: sender
  });

  return (await sesClient.send(command));
};

/**
 * Exporting the factory.
 */
export { factory };
