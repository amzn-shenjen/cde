import { describe, test, expect, beforeAll } from 'vitest';

import type * as Lib from '../lib';

// SES env vars must be set before the lib evaluates them at import.
process.env.SENDER ??= 'test@test.com';
process.env.RECIPIENTS ??= '[]';

let lib: typeof Lib;

beforeAll(async () => {
  lib = await import('../lib');
});

describe('E-mail factory translation tests', () => {

  /**
   * Testing AWS Config message translation.
   */
  test('AWS Config messages should be correctly translated', () => {
    const msg = lib.factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Subject: 'AWS Config',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {},
        Message: JSON.stringify({
          source: 'aws.config',
          detail: {
            awsAccountId: 'XXXXXXXXXXXX',
            configRuleName: 'cloudtrail-enabled',
            configRuleARN: 'arn:aws:config:us-east-2:XXXXXXXXXXXX:config-rule/config-rule-9rpvxc',
            resourceType: 'AWS::::Account',
            resourceId: 'XXXXXXXXXXXX',
            awsRegion: 'us-east-2',
            newEvaluationResult: {
              complianceType: 'COMPLIANT'
            },
            messageType: 'ComplianceChangeNotification'
          }
        })
      }
    });

    expect(msg).toEqual({
      context: {
        title: 'AWS Config Notification',
        description: 'Below are the data points associated with the AWS Config notification.',
        elements: [
          { key: 'Type', value: 'ComplianceChangeNotification' },
          { key: 'Account', value: 'undefined (undefined)' },
          { key: 'Rule', value: 'cloudtrail-enabled' },
          { key: 'Resource Type', value: 'AWS::::Account' },
          { key: 'Status', value: 'COMPLIANT' }
        ],
        button: {
          text: 'See Config Rule',
          url: 'https://console.aws.amazon.com/config/home#/rules/details?configRuleName=cloudtrail-enabled'
        },
        help: {
          url: 'https://docs.aws.amazon.com/config/latest/developerguide/evaluate-config_use-managed-rules.html'
        }
      }
    });
  });

  /**
   * Testing AWS CloudWatch alarm translation.
   */
  test('AWS CloudWatch alarm should be correctly translated', () => {
    const msg = lib.factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Subject: 'AWS CloudWatch Alarm',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {},
        Message: JSON.stringify({
          AlarmName: 'TestAlarm',
          AlarmArn: 'arn:aws:cloudwatch:eu-west-1:XXXXXXXXXXXX:alarm:test',
          AWSAccountId: 'XXXXXXXXXXXX',
          NewStateValue: 'ALARM',
          NewStateReason: 'Threshold Crossed: 1 datapoint (10.0) was greater than or equal to the threshold (1.0).',
          Region: 'EU - Ireland',
          Trigger: {
            MetricName: 'DeliveryErrors',
            Namespace: 'ExampleNamespace',
            Dimensions: []
          }
        })
      }
    });

    expect(msg).toEqual({
      context: {
        title: 'CloudWatch Alarm Notification',
        description: 'Below are the data points associated with the CloudWatch Alarm notification.',
        elements: [
          { key: 'Summary', value: 'A new alert has been triggered' },
          { key: 'Account Details', value: 'XXXXXXXXXXXX (EU - Ireland)' },
          { key: 'Reason', value: 'Threshold Crossed: 1 datapoint (10.0) was greater than or equal to the threshold (1.0).' },
          { key: 'Namespace', value: 'ExampleNamespace' },
          { key: 'Metric', value: 'DeliveryErrors' }
        ],
        button: {
          text: 'See Alarm Details',
          url: "https://eu-west-1.console.aws.amazon.com/cloudwatch/home?region=eu-west-1#alarmsV2:alarm/TestAlarm?~(alarmStateFilter~'ALARM)"
        },
        help: {
          url: 'https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html'
        }
      }
    });
  });

  /**
   * Testing AWS Budgets translation.
   */
  test('AWS Budgets should be correctly translated', () => {
    const msg = lib.factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Subject: 'AWS Budgets',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {},
        Message: `Dear AWS Customer,

        You requested that we alert you when the ACTUAL Cost associated with your Test budget is greater than $50.00 for the current month.\n The ACTUAL Cost associated with this budget is $128.17.\n You can find additional details below and by accessing the AWS Budgets dashboard [1].\n

        Budget Name: Test
        Budget Type: Cost
        Budgeted Amount: $50.00
        Alert Type: ACTUAL
        Alert Threshold: > $50.00
        ACTUAL Amount: $128.17

        [1] https://console.aws.amazon.com/billing/home#/budgets`
      }
    });

    expect(msg).toEqual({
      context: {
        title: 'AWS Budgets Notification',
        description: 'Below are the data points associated with the AWS Budgets notification.',
        elements: [
          { key: 'Budget Name', value: 'Test' },
          { key: 'Budgeted Amount', value: '$50.00' },
          { key: 'Threshold', value: 'ACTUAL' },
          { key: 'Actual Amount', value: '$128.17' }
        ],
        button: {
          text: 'Open AWS Budgets',
          url: 'https://console.aws.amazon.com/billing/home#/budgets'
        },
        help: {
          url: 'https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/budgets-managing-costs.html'
        }
      }
    });
  });

  /**
   * Testing the default implementation translation.
   */
  test('Default implementation should be correctly translated', () => {
    const msg = lib.factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        Subject: 'Test',
        Message: 'Test',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {}
      }
    });

    expect(msg).toEqual({
      context: {
        title: 'SNS Notification',
        description: 'Below are the data points associated with the received notification.',
        elements: [
          { key: 'SNS Topic', value: 'Test' },
          { key: 'Subject', value: 'Test' },
          { key: 'Event', value: 'Test' }
        ],
        button: {
          text: 'View SNS Topic',
          url: 'https://console.aws.amazon.com/sns/v3/home#/topic/arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test'
        },
        help: {
          url: 'https://docs.aws.amazon.com/sns/latest/dg/welcome.html'
        }
      }
    });
  });

  /**
   * Testing template rendering with the Eta engine.
   */
  test('Email template should render correctly with Eta engine for default notification', () => {
    const html = lib.createMessage({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-1:123456789012:TestTopic',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        Subject: 'Test Subject',
        Message: 'Test Message Content',
        TopicArn: 'arn:aws:sns:us-east-1:123456789012:TestTopic',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {}
      }
    });

    // Verifying the basic HTML structure.
    expect(html).toMatch(/<html>/);
    expect(html).toMatch(/<\/html>/);

    // Verifying interpolated values landed in the output.
    expect(html).toContain('SNS Notification');
    expect(html).toContain('TestTopic');
    expect(html).toContain('Test Subject');
    expect(html).toContain('Test Message Content');
    expect(html).toContain('View SNS Topic');
  });

  /**
   * Testing template rendering with HTML special characters.
   */
  test('Email template should escape HTML special characters', () => {
    const html = lib.createMessage({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-1:123456789012:Topic',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        Subject: 'Test with <special> & "characters"',
        Message: 'Message with <tags> & ampersands',
        TopicArn: 'arn:aws:sns:us-east-1:123456789012:SpecialTopic',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {}
      }
    });

    expect(html).toContain('Test with &lt;special&gt; &amp; &quot;characters&quot;');
    expect(html).toContain('Message with &lt;tags&gt; &amp; ampersands');
  });
});
