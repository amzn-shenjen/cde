# ✉️ email-transformer

A Lambda function implementation that transforms payloads received from different data sources on an SNS topic and builds an e-mail body that contains all the information carried by the data sources and sends it to a given list of receipent using AWS SES.

The supported data sources that can be converted are the following :

- **AWS Budgets** - Transforms budgets notifications into an e-mail format highlighting the budget name, amount, threshold and actuchal spent amount.
- **AWS CloudWatch Alarms** - Transforms AWS CloudWatch alarms into an e-mail format highlighting the alarm name, the state of the alarm, the namespace and metric associated with the alarm and the AWS Account and region details.
- **AWS Config** - Transforms AWS Config notifications into an e-mail format highlighting the config rule name, the state of the rule and the affected resource.

> A default implementation is also implemented as a fallback for unsupported data sources. The default implementation reports information such as the subject of the SNS record and its associated message body.

## Commands

Below is a list of different commands you can use with this Lambda function.

### Build the function

This should not be done manually, as the CDK stack the Lambda function is part of uses `esbuild` to bundle the Lambda function along with its dependencies. However, you can manually build the function for example to run tests.

```bash
npm install
```

### Run tests

In order to run the tests associated with the function, you need to run the below function.

```bash
npm run test
```

> Make sure you have run `npm install` beforehand.

### Lint the code

In order to lint the code associated with the function, you need to run the below function.

```bash
npm run lint
```

> Make sure you have run `npm install` beforehand.

### Build

In order to manually build the function and bundle it with `esbuild` run the following command.

```bash
npm run build
```
