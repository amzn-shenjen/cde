import { Logger } from '@aws-lambda-powertools/logger';
import { Tracer } from '@aws-lambda-powertools/tracer';

import * as lib from './lib';

import type { Context, SNSEvent } from 'aws-lambda';
import type { LambdaInterface } from '@aws-lambda-powertools/commons/types';

/**
 * Powertools logger emitting structured JSON logs enriched with
 * the Lambda context (function name, version, request id, cold start).
 */
const logger = new Logger({ serviceName: 'pep-email-transformer' });

/**
 * Powertools tracer wrapping the handler in an X-Ray segment so
 * SES `SendEmail` calls show up as subsegments.
 */
const tracer = new Tracer({ serviceName: 'pep-email-transformer' });

/**
 * Lambda handler. Processes SNS records, transforms them into
 * HTML messages and sends them by e-mail to the configured
 * recipients.
 */
class Handler implements LambdaInterface {

  /**
   * Lambda entry point.
   * @param event the event sent by AWS SNS to process and send
   * via e-mail to the recipients list.
   */
  @logger.injectLambdaContext({ logEvent: false })
  @tracer.captureLambdaHandler()
  public async handler(event: SNSEvent, _context: Context): Promise<void> {
    for (const record of (event.Records || [])) {
      // Creating the HTML message.
      const message = lib.createMessage(record);
      // Sending the e-mail.
      await lib.sendMessage(message);
    }
  }
}

const instance = new Handler();

/**
 * The bound Lambda handler.
 */
export const handler = instance.handler.bind(instance);

/**
 * Exporting the library for testing purposes.
 */
export { lib };
