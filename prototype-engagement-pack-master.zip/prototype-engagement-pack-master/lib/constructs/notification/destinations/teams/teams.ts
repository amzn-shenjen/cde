import path from 'path';

import { Construct } from 'constructs';
import { RemovalPolicy } from 'aws-cdk-lib';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Runtime } from 'aws-cdk-lib/aws-lambda';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { LambdaSubscription } from 'aws-cdk-lib/aws-sns-subscriptions';

import type { ITeamsProps } from '../../../../../helpers/validators/notification';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

/**
 * The properties expected by the Teams notification construct.
 */
export type ITeamsNotificationProps = {
  /**
   * An SNS topic to which budget alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;

  /**
   * An optional VPC in which the Lambda function will be run.
   */
  vpc?: IVpc;
};

export class TeamsDestinationConstruct extends Construct {
  /**
   * Converts received SNS messages into Teams messages.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   * @param topic the SNS topic on which the Teams integration should listen.
   * @param key a KMS key used to encrypt resources.
   */
  constructor(
    scope: Construct,
    id: string,
    props: ITeamsProps,
    inputs: ITeamsNotificationProps
  ) {
    super(scope, id);

    // The path to the transformer lambda function.
    const transformerPath = path.resolve(__dirname, 'lambdas', 'transformer');

    // CloudWatch log group for the Lambda.
    const logGroup = new LogGroup(this, 'TransformerLogGroup', {
      retention: RetentionDays.ONE_MONTH,
      removalPolicy: RemovalPolicy.DESTROY
    });

    // Creating the Lambda function that will receive notifications
    // from the SNS topic, format the notifications and send them to a Teams channel.
    const transformer = new NodejsFunction(this, 'Transformer', {
      entry: path.resolve(transformerPath, 'index.ts'),
      description: 'Processes SNS notifications, transforms them into Teams messages and sends them the provided webhook.',
      runtime: Runtime.NODEJS_24_X,
      handler: 'handler',
      logGroup,
      bundling: {
        nodeModules: [
          '@aws-lambda-powertools/logger',
          '@aws-lambda-powertools/tracer'
        ]
      },
      vpc: inputs.vpc,
      vpcSubnets: inputs.vpc
        ? { subnets: inputs.vpc.privateSubnets }
        : undefined,
      environmentEncryption: inputs.key,
      environment: {
        WEBHOOK: props.webhookUrl
      }
    });

    // Subscribing the Lambda to the SNS topic.
    inputs.topic.addSubscription(new LambdaSubscription(transformer));
  }
}
