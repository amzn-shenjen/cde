import { describe, test, expect } from 'vitest';

import { factory } from '../';

describe('Teams factory translation tests', () => {

  /**
   * Testing AWS Config message translation.
   */
  test('AWS Config messages should be correctly translated', () => {
    const msg = factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Subject: 'AWS Config',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {},
        Message: JSON.stringify({
          source: 'aws.config',
          detail: {
            configRuleName: 'cloudtrail-enabled',
            resourceType: 'AWS::::Account',
            newEvaluationResult: { complianceType: 'COMPLIANT' },
            messageType: 'ComplianceChangeNotification'
          }
        })
      }
    });

    expect(msg).toEqual({
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      themeColor: '0076D7',
      summary: 'A new compliance change has been received',
      sections: [{
        activityTitle: '![TestImage](https://emojicdn.elk.sh/✅)A new compliance change has been received',
        activitySubtitle: 'A rule has been detected as being compliant.',
        activityImage: 'https://emojicdn.elk.sh/✅',
        facts: [
          { name: 'Message Type', value: 'ComplianceChangeNotification' },
          { name: 'Account', value: 'undefined (undefined)' },
          { name: 'Rule', value: 'cloudtrail-enabled' },
          { name: 'Resource Type', value: 'AWS::::Account' },
          { name: 'Status', value: 'COMPLIANT' }
        ],
        markdown: true
      }],
      potentialAction: [{
        '@type': 'ActionCard',
        name: 'See Config Rule',
        actions: [{
          '@type': 'OpenUri',
          name: 'See the AWS Config Rule in the Console',
          targets: [{
            os: 'default',
            uri: 'https://console.aws.amazon.com/config/home#/rules/details?configRuleName=cloudtrail-enabled'
          }]
        }]
      }]
    });
  });

  /**
   * Testing AWS CloudWatch alarm translation.
   */
  test('AWS CloudWatch alarm should be correctly translated', () => {
    const msg = factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Subject: 'AWS CloudWatch Alarm',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {},
        Message: JSON.stringify({
          AlarmName: 'TestAlarm',
          AlarmArn: 'arn:aws:cloudwatch:eu-west-1:XXXXXXXXXXXX:alarm:test',
          AWSAccountId: 'XXXXXXXXXXXX',
          NewStateValue: 'ALARM',
          NewStateReason: 'Threshold Crossed: 1 datapoint (10.0) was greater than or equal to the threshold (1.0).',
          Region: 'EU - Ireland',
          Trigger: { MetricName: 'DeliveryErrors', Namespace: 'ExampleNamespace' }
        })
      }
    });

    expect(msg).toEqual({
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      themeColor: '0076D7',
      summary: 'A new alarm has been triggered',
      sections: [{
        activityTitle: '![TestImage](https://emojicdn.elk.sh/🚨)A new alarm has been triggered',
        activitySubtitle: 'Below are the details associated with the alarm',
        activityImage: 'https://emojicdn.elk.sh/🚨',
        facts: [
          { name: 'SNS Topic', value: 'Test' },
          { name: 'AWS Account', value: 'XXXXXXXXXXXX' },
          { name: 'AWS Region', value: 'EU - Ireland' },
          { name: 'Reason', value: 'Threshold Crossed: 1 datapoint (10.0) was greater than or equal to the threshold (1.0).' },
          { name: 'Namespace', value: 'ExampleNamespace' },
          { name: 'Metric', value: 'DeliveryErrors' }
        ],
        markdown: true
      }],
      potentialAction: [{
        '@type': 'ActionCard',
        name: 'See the Alarm',
        actions: [{
          '@type': 'OpenUri',
          name: 'See the Alarm in the Console',
          targets: [{
            os: 'default',
            uri: "https://eu-west-1.console.aws.amazon.com/cloudwatch/home?region=eu-west-1#alarmsV2:alarm/TestAlarm?~(alarmStateFilter~'ALARM)"
          }]
        }]
      }]
    });
  });

  /**
   * Testing the default implementation translation.
   */
  test('Default implementation should be correctly translated', () => {
    const msg = factory.get({
      EventVersion: '1.0',
      EventSubscriptionArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
      EventSource: 'aws:sns',
      Sns: {
        Type: 'Notification',
        MessageId: 'm',
        Subject: 'Test',
        Message: 'Test',
        TopicArn: 'arn:aws:sns:us-east-2:XXXXXXXXXXXX:Test',
        Timestamp: '',
        SignatureVersion: '1',
        Signature: '',
        SigningCertUrl: '',
        UnsubscribeUrl: '',
        MessageAttributes: {}
      }
    });

    expect(msg).toEqual({
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      themeColor: '0076D7',
      summary: 'A new event has been received',
      sections: [{
        activityTitle: '![TestImage](https://emojicdn.elk.sh/☁️)A new event has been received',
        activitySubtitle: 'Below are the details associated with the received event',
        activityImage: 'https://emojicdn.elk.sh/☁️',
        facts: [
          { name: 'SNS Topic', value: 'Test' },
          { name: 'Subject', value: 'Test' },
          { name: 'Event Source', value: 'aws:sns' },
          { name: 'Event', value: 'Test' }
        ],
        markdown: true
      }]
    });
  });
});
