import { Logger } from '@aws-lambda-powertools/logger';
import { Tracer } from '@aws-lambda-powertools/tracer';

import * as factory from './lib/factory';

import type { Context, SNSEvent } from 'aws-lambda';
import type { LambdaInterface } from '@aws-lambda-powertools/commons/types';
import type { TeamsCard } from './lib/factory';

/**
 * The URL associated with the Teams webhook.
 */
const webhook = process.env.WEBHOOK;

/**
 * Powertools logger emitting structured JSON logs enriched with
 * the Lambda context (function name, version, request id, cold start).
 */
const logger = new Logger({ serviceName: 'pep-teams-transformer' });

/**
 * Powertools tracer wrapping the handler in an X-Ray segment so
 * outbound webhook calls show up as subsegments.
 */
const tracer = new Tracer({ serviceName: 'pep-teams-transformer' });

/**
 * Sends the generated message to the recipients.
 * @param message the Teams message to send.
 */
const sendMessage = async (message: TeamsCard) => {
  if (!webhook) {
    throw new Error('WEBHOOK environment variable is not set');
  }
  return (fetch(webhook, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(message)
  }));
};

/**
 * Lambda handler. Processes SNS records, transforms them into
 * Teams messages and posts them to the configured webhook.
 */
class Handler implements LambdaInterface {

  /**
   * Lambda entry point.
   * @param event the event sent by AWS SNS to process and post
   * to the Teams webhook.
   */
  @logger.injectLambdaContext({ logEvent: false })
  @tracer.captureLambdaHandler()
  public async handler(event: SNSEvent, _context: Context): Promise<void> {
    for (const record of (event.Records || [])) {
      // Sending the message to Teams.
      await sendMessage(factory.get(record));
    }
  }
}

const instance = new Handler();

/**
 * The bound Lambda handler.
 */
export const handler = instance.handler.bind(instance);

/**
 * Exporting the factory for testing purposes.
 */
export { factory };
