import type { SNSEventRecord } from 'aws-lambda';
import type { TeamsCard } from '../factory';

/**
 * Shape of a CloudWatch Alarm notification body parsed out of
 * the SNS `Message` payload.
 */
type CloudWatchAlarmEvent = {
  AlarmName: string;
  AlarmArn: string;
  AWSAccountId: string;
  Region: string;
  NewStateValue: string;
  NewStateReason: string;
  Trigger: {
    Namespace: string;
    MetricName: string;
  };
};

/**
 * Determines whether the received message
 * is associated with an active alarm.
 * @param message the CloudWatch Alarm message.
 * @returns whether the alarm is active.
 */
const isActive = (message: CloudWatchAlarmEvent) => {
  return (message.NewStateValue === 'OK');
};

/**
 * @param message the CloudWatch Alarm message.
 * @returns a URL to an icon to be used within the Teams message.
 */
const getIcon = (message: CloudWatchAlarmEvent) => {
  return (isActive(message)
    ? 'https://emojicdn.elk.sh/✅'
    : 'https://emojicdn.elk.sh/🚨');
};

/**
 * @param message a cloudwatch alarm event.
 * @returns a URL pointing to the CloudWatch console
 * for the given alarm.
 * @see https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html
 */
const getConsoleUrl = (message: CloudWatchAlarmEvent) => {
  const region  = message.AlarmArn.split(':')[3];
  const consoleUrl = new URL(`https://${region}.console.aws.amazon.com/cloudwatch/home`);

  consoleUrl.searchParams.set('region', region);
  consoleUrl.hash = `alarmsV2:alarm/${encodeURIComponent(message.AlarmName)}?~(alarmStateFilter~'ALARM)`;
  return (consoleUrl);
};

/**
 * Transforms the received CloudWatch Alarm into a Teams message.
 * @param message the message contained in the SNS record.
 * @param record the original SNS record.
 * @returns the card associated with the given `record`.
 */
export const get = (message: unknown, record: SNSEventRecord): TeamsCard => {
  const event   = message as CloudWatchAlarmEvent;
  const topic   = record.Sns.TopicArn.split(':');
  const summary = isActive(event) ? 'An alarm has been resolved' : 'A new alarm has been triggered';
  const icon    = getIcon(event);
  return ({
    '@type': 'MessageCard',
    '@context': 'http://schema.org/extensions',
    themeColor: '0076D7',
    summary,
    sections: [{
      activityTitle: `![TestImage](${icon})${summary}`,
      activitySubtitle: 'Below are the details associated with the alarm',
      activityImage: icon,
      facts: [{
        name: 'SNS Topic',
        value: topic[5]
      }, {
        name: 'AWS Account',
        value: event.AWSAccountId
      }, {
        name: 'AWS Region',
        value: event.Region
      }, {
        name: 'Reason',
        value: event.NewStateReason
      }, {
        name: 'Namespace',
        value: event.Trigger.Namespace
      }, {
        name: 'Metric',
        value: event.Trigger.MetricName
      }],
      markdown: true
    }],
    potentialAction: [{
      '@type': 'ActionCard',
      name: 'See the Alarm',
      actions: [{
        '@type': 'OpenUri',
        name: 'See the Alarm in the Console',
        targets: [{
          os: 'default',
          uri: getConsoleUrl(event).toString()
        }]
      }]
    }]
  });
};

/**
 * @param message the message contained in the SNS record.
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (message: unknown): boolean => {
  return (typeof message === 'object'
    && message !== null
    && Boolean((message as { AlarmName?: unknown }).AlarmName)
    && Boolean((message as { NewStateValue?: unknown }).NewStateValue));
};
