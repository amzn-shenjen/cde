import * as config from './impl/config';
import * as cwAlarms from './impl/cw-alarms';
import * as defaultImpl from './impl/default-impl';

import type { SNSEventRecord } from 'aws-lambda';

/**
 * The Teams MessageCard payload posted to the webhook. Typed
 * loosely on purpose — every implementation builds the exact
 * MessageCard schema it needs.
 */
export type TeamsCard = Record<string, unknown>;

/**
 * The contract every message implementation honours.
 */
export type Impl = {

  /**
   * @param message the parsed SNS message body, JSON-decoded when
   * the original payload was JSON, or the raw string otherwise.
   * @param record the original SNS record.
   * @returns the card associated with the given `record`.
   */
  get(message: unknown, record: SNSEventRecord): TeamsCard;

  /**
   * @param message the parsed SNS message body.
   * @returns whether the current implementation supports the
   * given message.
   */
  handles(message: unknown): boolean;
};

/**
 * An array of implementations handling the different
 * messages that can be received from the SNS topic.
 */
const impl: Impl[] = [
  config,
  cwAlarms,
  defaultImpl
];

/**
 * @param record an SNS record.
 * @returns the card associated with the given `record`.
 */
export const get = (record: SNSEventRecord): TeamsCard => {
  let message: unknown = record.Sns.Message;

  // Attempting to parse the message as JSON.
  try {
    message = JSON.parse(record.Sns.Message);
  } catch {
    // The message is not in JSON.
  }

  for (const handler of impl) {
    if (handler.handles(message)) {
      return (handler.get(message, record));
    }
  }

  throw new Error('No handler for the given record');
};
