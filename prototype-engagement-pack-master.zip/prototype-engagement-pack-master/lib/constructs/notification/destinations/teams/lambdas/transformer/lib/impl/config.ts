import type { SNSEventRecord } from 'aws-lambda';
import type { TeamsCard } from '../factory';

/**
 * Shape of the AWS Config notification body parsed out of the
 * SNS `Message` payload.
 */
type ConfigEvent = {
  source: string;
  account?: string;
  region?: string;
  detail: {
    messageType: string;
    configRuleName: string;
    resourceType: string;
    newEvaluationResult: {
      complianceType: string;
    };
  };
};

/**
 * Determines whether the received compliance change
 * is a rule becoming compliant or non-compliant.
 * @param message the EventBridge enveloppe containing
 * the AWS Config notification.
 * @returns whether the rule is compliant.
 */
const isCompliant = (message: ConfigEvent) => {
  return (message.detail.newEvaluationResult.complianceType === 'COMPLIANT');
};

/**
 * @param message the EventBridge enveloppe containing
 * the AWS Config notification.
 * @returns a subtitle to be used within the Teams message.
 */
const getSubtitle = (message: ConfigEvent) => {
  return (`A rule has been detected as being ${isCompliant(message) ? 'compliant' : 'non-compliant'}.`);
};

/**
 * @param message the EventBridge enveloppe containing
 * the AWS Config notification.
 * @returns a URL to an icon to be used within the Teams message.
 */
const getIcon = (message: ConfigEvent) => {
  return (isCompliant(message)
    ? 'https://emojicdn.elk.sh/✅'
    : 'https://emojicdn.elk.sh/🚨');
};

/**
 * @param message an AWS Config notification.
 * @returns a URL pointing to the AWS Config console for the given rule.
 */
const getConsoleUrl = (message: ConfigEvent) => {
  return (`https://console.aws.amazon.com/config/home#/rules/details`
    + `?configRuleName=${encodeURIComponent(message.detail.configRuleName)}`);
};

/**
 * Creates the Teams message associated with an AWS Config event.
 * @param message the message contained in the SNS record.
 * @returns the template parameters associated
 * with this implementation.
 */
export const get = (message: unknown, _record: SNSEventRecord): TeamsCard => {
  const event   = message as ConfigEvent;
  const summary = 'A new compliance change has been received';
  const icon    = getIcon(event);
  return ({
    '@type': 'MessageCard',
    '@context': 'http://schema.org/extensions',
    themeColor: '0076D7',
    summary,
    sections: [{
      activityTitle: `![TestImage](${icon})${summary}`,
      activitySubtitle: getSubtitle(event),
      activityImage: icon,
      facts: [{
        name: 'Message Type',
        value: event.detail.messageType
      }, {
        name: 'Account',
        value: `${event.account} (${event.region})`
      }, {
        name: 'Rule',
        value: event.detail.configRuleName
      }, {
        name: 'Resource Type',
        value: event.detail.resourceType
      }, {
        name: 'Status',
        value: event.detail.newEvaluationResult.complianceType
      }],
      markdown: true
    }],
    potentialAction: [{
      '@type': 'ActionCard',
      name: 'See Config Rule',
      actions: [{
        '@type': 'OpenUri',
        name: 'See the AWS Config Rule in the Console',
        targets: [{
          os: 'default',
          uri: getConsoleUrl(event)
        }]
      }]
    }]
  });
};

/**
 * @param message the message contained in the SNS record.
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (message: unknown): boolean => {
  return (typeof message === 'object'
    && message !== null
    && (message as { source?: unknown }).source === 'aws.config');
};
