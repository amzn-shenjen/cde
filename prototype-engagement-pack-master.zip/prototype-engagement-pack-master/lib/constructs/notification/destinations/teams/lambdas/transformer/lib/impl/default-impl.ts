import type { SNSEventRecord } from 'aws-lambda';
import type { TeamsCard } from '../factory';

/**
 * Creates the Teams message associated with a raw SNS event.
 * @param message the message contained in the SNS record.
 * @param record the received SNS record.
 * @returns the card associated with the given `record`.
 */
export const get = (message: unknown, record: SNSEventRecord): TeamsCard => {
  const topic   = record.Sns.TopicArn.split(':');
  const summary = 'A new event has been received';
  return ({
    '@type': 'MessageCard',
    '@context': 'http://schema.org/extensions',
    themeColor: '0076D7',
    summary,
    sections: [{
      activityTitle: `![TestImage](https://emojicdn.elk.sh/☁️)${summary}`,
      activitySubtitle: 'Below are the details associated with the received event',
      activityImage: 'https://emojicdn.elk.sh/☁️',
      facts: [{
        name: 'SNS Topic',
        value: topic[5]
      }, {
        name: 'Subject',
        value: record.Sns.Subject
      }, {
        name: 'Event Source',
        value: record.EventSource || 'Unknown'
      }, {
        name: 'Event',
        value: message
      }],
      markdown: true
    }]
  });
};

/**
 * @returns whether the current implementation supports
 * the given record.
 */
export const handles = (): boolean => {
  return (true);
};
