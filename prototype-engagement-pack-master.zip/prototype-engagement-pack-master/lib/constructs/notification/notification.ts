import { Construct } from 'constructs';
import { SlackDestinationConstruct } from './destinations/slack/slack';
import { TeamsDestinationConstruct } from './destinations/teams/teams';
import { EmailDestinationConstruct } from './destinations/email/email';
import { INotificationType } from '../../../helpers/validators/notification';

import type { IConfiguration } from '../../../helpers/validators/configuration';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { IVpc } from 'aws-cdk-lib/aws-ec2';

import type {
  IEmailProps,
  ISlackProps,
  ITeamsProps
} from '../../../helpers/validators/notification';

/**
 * The properties expected by the notification construct.
 */
export type INotificationProps = {
  
  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * An SNS topic to which budget alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;

  /**
   * An optional VPC to use to deploy Lambda functions.
   */
  vpc?: IVpc;
};

export class NotificationConstruct extends Construct {
  
  /**
   * Deploys the required resources to notify prototype participants
   * of alerts that require attention to keep the account secure.
   * Multiple notification providers exist and are instanciated depending
   * on the provided configuration.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   */
  constructor(scope: Construct, id: string, props: INotificationProps) {
    super(scope, id);

    if (!props.configuration.notification) {
      return;
    }

    // Notification types described in the configuration.
    const keys = Object.keys(props.configuration.notification);

    // Adding the E-mail notification.
    if (keys.includes(INotificationType.EMAIL.toString())) {
      new EmailDestinationConstruct(
        this,
        'EmailDestinationConstruct',
        <IEmailProps>props.configuration.notification[INotificationType.EMAIL],
        { ...props }
      );
    }

    // Adding the Slack notification.
    if (keys.includes(INotificationType.SLACK.toString())) {
      new SlackDestinationConstruct(
        this,
        'SlackDestinationConstruct',
        <ISlackProps>props.configuration.notification[INotificationType.SLACK],
        { ...props }
      );
    }

    // Adding the Teams notification.
    if (keys.includes(INotificationType.TEAMS.toString())) {
      new TeamsDestinationConstruct(
        this,
        'TeamsDestinationConstruct',
        <ITeamsProps>props.configuration.notification[INotificationType.TEAMS],
        { ...props }
      );
    }
  }
}
