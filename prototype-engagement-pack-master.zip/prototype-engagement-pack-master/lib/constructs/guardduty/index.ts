import path from 'path';
import * as events from 'aws-cdk-lib/aws-events';

import { Construct } from 'constructs';
import { PolicyStatement, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Runtime, Tracing } from 'aws-cdk-lib/aws-lambda';
import { LogGroup, RetentionDays } from 'aws-cdk-lib/aws-logs';
import { Provider } from 'aws-cdk-lib/custom-resources';
import { PARTITION, getConsoleHost } from '../../../helpers/partition';

import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IConfiguration } from '../../../helpers/validators/configuration';
import type { IKey } from 'aws-cdk-lib/aws-kms';

import {
  CustomResource,
  Duration,
  RemovalPolicy,
  Stack,
  aws_events_targets as eventTargets
} from 'aws-cdk-lib';

/**
 * The principal name for the Malware protection service
 * in AWS GuardDuty.
 */
const MALWARE_PRINCIPAL = 'malware-protection.guardduty.amazonaws.com';

/**
 * @returns the GuardDuty service principal for the active
 * partition.
 */
const getPrincipal = (): string => {
  switch (PARTITION) {
    case 'aws-cn':
      return ('guardduty.amazonaws.com.cn');
    default:
      return ('guardduty.amazonaws.com');
  }
};

/**
 * The properties expected by the guardduty construct.
 */
export type IGuardDutyProps = {

  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;

  /**
   * An SNS topic to which guard duty alerts will be sent.
   */
  topic: ITopic;

  /**
   * A KMS key used to encrypt resources.
   */
  key: IKey;
};

export class GuardDutyConstruct extends Construct {

  /**
   * This construct enables Amazon GuardDuty on a customer AWS account,
   * and associates it with the SNS topic if given.
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the construct.
   */
  constructor(scope: Construct, id: string, props: IGuardDutyProps) {
    super(scope, id);

    if (!props.configuration.guardDuty?.enabled) {
      return;
    }

    // Allowing Amazon GuardDuty to publish on the given topic.
    props.topic.grantPublish(
      new ServicePrincipal(getPrincipal())
    );

    // Allowing Amazon GuardDuty to use the KMS key to publish on an encrypted SNS topic.
    props.key.grantEncryptDecrypt(
      new ServicePrincipal(getPrincipal())
    );

    // CloudWatch log group for the bootstrap Lambda.
    const bootstrapLogGroup = new LogGroup(this, 'BootstrapLogGroup', {
      retention: RetentionDays.ONE_MONTH,
      removalPolicy: RemovalPolicy.DESTROY
    });

    // Discovers any pre-existing detector at deploy time
    // and either creates a new one or enables the existing one.
    const bootstrapFn = new NodejsFunction(this, 'BootstrapFunction', {
      entry: path.resolve(__dirname, 'lambdas', 'bootstrap', 'index.ts'),
      description: 'Ensures a single enabled GuardDuty detector exists in the deploying account and region.',
      runtime: Runtime.NODEJS_24_X,
      handler: 'handler',
      timeout: Duration.seconds(30),
      memorySize: 128,
      tracing: Tracing.ACTIVE,
      logGroup: bootstrapLogGroup,
      environmentEncryption: props.key,
      bundling: {
        nodeModules: [
          '@aws-lambda-powertools/logger',
          '@aws-lambda-powertools/tracer'
        ]
      }
    });

    // CreateDetector and ListDetectors do not support
    // resource-level scoping. UpdateDetector and DeleteDetector
    // are scoped to the deploying account and region.
    bootstrapFn.addToRolePolicy(new PolicyStatement({
      actions: [
        'guardduty:ListDetectors',
        'guardduty:CreateDetector'
      ],
      resources: ['*']
    }));
    bootstrapFn.addToRolePolicy(new PolicyStatement({
      actions: [
        'guardduty:UpdateDetector',
        'guardduty:DeleteDetector'
      ],
      resources: [
        `arn:${Stack.of(this).partition}:guardduty:${Stack.of(this).region}:${Stack.of(this).account}:detector/*`
      ]
    }));

    // CreateDetector provisions two service-linked roles on first
    // use: the GuardDuty SLR and the Malware Protection for EC2
    // SLR.
    const slrArn = `arn:${Stack.of(this).partition}:iam::${Stack.of(this).account}:role/aws-service-role/${getPrincipal()}/AWSServiceRoleForAmazonGuardDuty`;
    const malwareSlrArn = `arn:${Stack.of(this).partition}:iam::${Stack.of(this).account}:role/aws-service-role/${MALWARE_PRINCIPAL}/AWSServiceRoleForAmazonGuardDutyMalwareProtection`;

    // Allowing the bootstrap function to create the two
    // service-linked roles if they don't exist.
    bootstrapFn.addToRolePolicy(new PolicyStatement({
      actions: ['iam:CreateServiceLinkedRole'],
      resources: [slrArn, malwareSlrArn],
      conditions: {
        StringLike: {
          'iam:AWSServiceName': [
            getPrincipal(),
            MALWARE_PRINCIPAL
          ]
        }
      }
    }));

    // Allowing the bootstrap function to retrieve the two
    // service-linked roles if they do exist.
    bootstrapFn.addToRolePolicy(new PolicyStatement({
      actions: ['iam:GetRole'],
      resources: [
        slrArn,
        malwareSlrArn
      ]
    }));

    // Custom-resource provider — calls the bootstrap Lambda on
    // every stack lifecycle event.
    const provider = new Provider(this, 'BootstrapProvider', {
      onEventHandler: bootstrapFn
    });

    new CustomResource(this, 'Bootstrap', {
      serviceToken: provider.serviceToken
    });

    // An EventBridge rule to capture AWS GuardDuty findings.
    const eventRule = new events.Rule(this, 'GuardDutyEventRule', {
      eventPattern: {
        source: ['aws.guardduty'],
        detailType: ['GuardDuty Finding']
      }
    });

    // Adding the SNS topic as a target for the rule.
    eventRule.addTarget(
      new eventTargets.SnsTopic(props.topic, {
        message: events.RuleTargetInput.fromText(
          `WARNING: Amazon GuardDuty has discovered a ${events.EventField.fromPath(
            '$.detail.type',
          )} security issue (${events.EventField.fromPath(
            '$.region',
          )}). Please go to https://${events.EventField.fromPath(
            '$.region',
          )}.${getConsoleHost()}/guardduty/ to find out more details.`
        )
      })
    );
  }
}
