import { Logger } from '@aws-lambda-powertools/logger';
import { Tracer } from '@aws-lambda-powertools/tracer';
import type { LambdaInterface } from '@aws-lambda-powertools/commons/types';

import {
  CreateDetectorCommand,
  DeleteDetectorCommand,
  GuardDutyClient,
  ListDetectorsCommand,
  UpdateDetectorCommand
} from '@aws-sdk/client-guardduty';
import type {
  CloudFormationCustomResourceCreateEvent,
  CloudFormationCustomResourceDeleteEvent,
  CloudFormationCustomResourceEvent,
  CloudFormationCustomResourceResponse,
  CloudFormationCustomResourceUpdateEvent,
  Context
} from 'aws-lambda';

/**
 * Powertools logger.
 */
const logger = new Logger({
  serviceName: 'pep-guardduty-bootstrap'
});

/**
 * Powertools tracer.
 */
const tracer = new Tracer({
  serviceName: 'pep-guardduty-bootstrap'
});

/**
 * The GuardDuty client.
 */
const guardduty = new GuardDutyClient({});

/**
 * Prefix marking a detector created by the Prototype Engagement
 * Pack. Encoded in the custom resource's PhysicalResourceId so
 * the delete handler knows the detector is ours to remove.
 */
const PEP_CREATED = 'pep-created:';

/**
 * Bootstrap outcome — the detector id and the matching
 * PhysicalResourceId, both written back to CloudFormation.
 */
type BootstrapResult = {
  physicalResourceId: string;
  detectorId: string;
};

/**
 * Returns the first detector id in the deploying region, or
 * `undefined` when none exists.
 */
const findExistingDetector = async (): Promise<string | undefined> => {
  const response = await guardduty.send(
    new ListDetectorsCommand({})
  );
  return (response.DetectorIds?.[0]);
};

/**
 * Ensures a single, enabled GuardDuty detector exists in the
 * deploying account and region. Creates one when none is found,
 * enables an existing one when AWS auto-provisioned a detector
 * before the stack ran.
 */
const ensureDetectorEnabled = async (): Promise<BootstrapResult> => {
  const existing = await findExistingDetector();

  if (existing) {    
    // Enabling existing GuardDuty detector.
    await guardduty.send(new UpdateDetectorCommand({
      DetectorId: existing,
      Enable: true
    }));
    return ({
      physicalResourceId: existing,
      detectorId: existing
    });
  }

  // No GuardDuty detector found.
  const created = await guardduty.send(new CreateDetectorCommand({
    Enable: true,
    FindingPublishingFrequency: 'SIX_HOURS'
  }));

  if (!created.DetectorId) {
    throw new Error('CreateDetector did not return a DetectorId');
  }

  return ({
    physicalResourceId: `${PEP_CREATED}${created.DetectorId}`,
    detectorId: created.DetectorId
  });
};

/**
 * Builds the SUCCESS response written back to CloudFormation.
 * @param event - The custom-resource event being responded to.
 * @param physicalResourceId - The PhysicalResourceId to record.
 * @param data - Optional response data exposed via `Fn::GetAtt`.
 */
const success = (
  event: CloudFormationCustomResourceEvent,
  physicalResourceId: string,
  data?: Record<string, string>
): CloudFormationCustomResourceResponse => ({
  Status: 'SUCCESS',
  PhysicalResourceId: physicalResourceId,
  StackId: event.StackId,
  RequestId: event.RequestId,
  LogicalResourceId: event.LogicalResourceId,
  Data: data
});

/**
 * Handles a stack-creation event.
 * @param event - The custom-resource Create event.
 */
const onCreate = async (
  event: CloudFormationCustomResourceCreateEvent
): Promise<CloudFormationCustomResourceResponse> => {
  const result = await ensureDetectorEnabled();
  return (success(event, result.physicalResourceId, { DetectorId: result.detectorId }));
};

/**
 * Handles a stack-update event.
 * @param event - The custom-resource Update event.
 */
const onUpdate = async (
  event: CloudFormationCustomResourceUpdateEvent
): Promise<CloudFormationCustomResourceResponse> => {
  const result = await ensureDetectorEnabled();
  const physicalResourceId = event.PhysicalResourceId.startsWith(PEP_CREATED)
    ? event.PhysicalResourceId
    : result.physicalResourceId;
  return (success(event, physicalResourceId, { DetectorId: result.detectorId }));
};

/**
 * Handles a stack-deletion event.
 * @param event - The custom-resource Delete event.
 */
const onDelete = async (
  event: CloudFormationCustomResourceDeleteEvent
): Promise<CloudFormationCustomResourceResponse> => {
  if (event.PhysicalResourceId.startsWith(PEP_CREATED)) {
    const detectorId = event.PhysicalResourceId.slice(PEP_CREATED.length);
    await guardduty.send(new DeleteDetectorCommand({
      DetectorId: detectorId
    }));
  }
  return (success(event, event.PhysicalResourceId));
};

/**
 * Custom-resource handler that ensures a single enabled
 * GuardDuty detector is present in the deploying account and
 * region.
 */
class Handler implements LambdaInterface {

  /**
   * Lambda entry point.
   * @param event - The CloudFormation custom-resource event.
   */
  @logger.injectLambdaContext()
  @tracer.captureLambdaHandler()
  public async handler(
    event: CloudFormationCustomResourceEvent,
    _context: Context
  ): Promise<CloudFormationCustomResourceResponse> {
    switch (event.RequestType) {
      case 'Create':
        return (onCreate(event));
      case 'Update':
        return (onUpdate(event));
      case 'Delete':
        return (onDelete(event));
    }
  }
}

const instance = new Handler();

/**
 * The bound Lambda handler.
 */
export const handler = instance.handler.bind(instance);
