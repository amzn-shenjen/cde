import { Construct } from 'constructs';
import { CfnOutput, Duration } from 'aws-cdk-lib';
import { PARTITION } from '../../helpers/partition';

import type { IConfiguration } from '../../helpers/validators/configuration';
import type { IEngagementRole } from '../../helpers/validators/engagement';
import type { Conditions } from 'aws-cdk-lib/aws-iam';
import {
  AccountPrincipal,
  ArnPrincipal,
  Effect,
  ManagedPolicy,
  PolicyStatement,
  PrincipalBase,
  PrincipalPolicyFragment,
  Role
} from 'aws-cdk-lib/aws-iam';

/**
 * The properties expected by the cross-account role construct.
 */
export type ICrossAccountRoleProps = {

  /**
   * The configuration associated with the stack.
   */
  configuration: IConfiguration;
};

/**
 * Requires multi-factor authentication at assume-time. Applied to
 * the trust modes relying on long-lived credentials.
 */
const MFA_REQUIRED: Conditions = {
  Bool: { 'aws:MultiFactorAuthPresent': true }
};

/**
 * A principal trusting several IAM ARNs at once. The ARNs are
 * rendered as a single `Principal.AWS` array, keeping the trust
 * policy well below the 2048 character limit that one statement
 * per ARN would exceed.
 * @see https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html
 */
class MultiArnPrincipal extends PrincipalBase {

  /**
   * The ARNs of the principals allowed to assume the role.
   */
  private readonly arns: string[];

  /**
   * @param arns the ARNs of the principals allowed to assume the role.
   */
  constructor(arns: string[]) {
    super();
    this.arns = arns;
  }

  /**
   * @returns the `Principal` section identifying the trusted ARNs.
   */
  public get policyFragment(): PrincipalPolicyFragment {
    return (new PrincipalPolicyFragment({ AWS: this.arns }));
  }

  /**
   * @returns the key under which statements holding this principal
   * are merged together.
   */
  public dedupeString(): string {
    return (`MultiArnPrincipal:${this.arns.join(',')}`);
  }
}

/**
 * Resolves the principal trusted by the cross-account role. The
 * trust modes are mutually exclusive.
 * @param role the engagement role configuration.
 * @returns the principal allowed to assume the cross-account role.
 */
const resolveTrustedPrincipal = (role: IEngagementRole) => {
  // The `role` mode trusts a specific IAM role in the source account.
  if (role.trustMode === 'role') {
    return (new ArnPrincipal(role.sourceRoleArn));
  }

  // The `user` mode trusts specific IAM users in the source account.
  if (role.trustMode === 'user') {
    return (new MultiArnPrincipal(role.sourceUsernames.map(
      (username) => `arn:${PARTITION}:iam::${role.sourceAccountId}:user/${username}`
    )));
  }

  // Otherwise, the `account` mode trusts the source account as a whole.
  return (new AccountPrincipal(role.sourceAccountId));
};

/**
 * The `CrossAccountRoleConstruct` construct creates a cross-account
 * role allowing the AWS team to assume access to the customer account.
 */
export class CrossAccountRoleConstruct extends Construct {

  /**
   * The created cross-account role to be assumed by the AWS team.
   */
  public readonly crossAccountRole: Role;

  /**
   * Creates a cross-account role allowing the AWS team
   * to access customer accounts by assuming the role.
   * @param scope the construct scope.
   * @param id the identifier given the construct.
   * @param props the construct configuration.
   */
  constructor(scope: Construct, id: string, props: ICrossAccountRoleProps) {
    super(scope, id);

    if (!props.configuration.engagement) {
      return;
    }

    // A cross-account role allowing member from the AWS team
    // to switch role into customers account.
    const { role, start, end } = props.configuration.engagement;

    // Adding time related constraints to the role.
    const timeBoxedConditions: Conditions = {
      DateGreaterThan: {
        'aws:CurrentTime': start,
      },
      DateLessThan: {
        'aws:CurrentTime': end
      }
    };

    // Define the role principal.
    const trustedPrincipal = resolveTrustedPrincipal(role)
      .withConditions(role.trustMode === 'role' ? {} : MFA_REQUIRED)
      .withConditions(timeBoxedConditions);

    // Create the IAM cross-account role.
    this.crossAccountRole = new Role(this, 'CrossAccountRole', {
      description: 'A role to be assumed by the AWS team to access and operate on customer accounts.',
      assumedBy: trustedPrincipal,
      managedPolicies: role.managedPolicies.map(
        (policy) => ManagedPolicy.fromManagedPolicyArn(this, `Policy-${policy.split('/').pop()}`, policy)
      ),
      maxSessionDuration: Duration.hours(12)
    });

    // Allow `sts:SetSourceIdentity` on the customer role to allow AWS Staff
    // stamp their identity on the access for CloudTrail attribution.
    // @see https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_iam-condition-keys.html
    this.crossAccountRole.assumeRolePolicy?.addStatements(new PolicyStatement({
      effect: Effect.ALLOW,
      principals: [trustedPrincipal],
      actions: ['sts:SetSourceIdentity']
    }));

    // Exporting the role ARN as part of the stack outputs.
    new CfnOutput(this, 'CrossAccountRoleArn', {
      description: 'The ARN of the cross-account role to provide to the AWS team.',
      value: this.crossAccountRole.roleArn,
    });
  }
}
