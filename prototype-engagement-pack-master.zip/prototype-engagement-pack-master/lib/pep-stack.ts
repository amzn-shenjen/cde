import { Annotations, Stack } from 'aws-cdk-lib';
import { BudgetConstruct } from './constructs/budget';
import { CrossAccountRoleConstruct } from './constructs/cross-account-role';
import { ConfigConstruct } from './constructs/config/config';
import { CloudTrailConstruct } from './constructs/cloudtrail';
import { NotificationConstruct } from './constructs/notification/notification';
import { VpcConstruct } from './constructs/vpc';
import { SecurityPoliciesConstruct } from './constructs/policies/security-policies';
import { Key } from 'aws-cdk-lib/aws-kms';
import { Topic } from 'aws-cdk-lib/aws-sns';
import { GuardDutyConstruct } from './constructs/guardduty';
import { InspectorConstruct } from './constructs/inspector';
import { DevEnvironmentConstruct } from './constructs/dev-environment';
import { PARTITION } from '../helpers/partition';

import type { Construct } from 'constructs';
import type { Environment } from 'aws-cdk-lib';
import type { IConfiguration } from '../helpers/validators/configuration';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { ITopic } from 'aws-cdk-lib/aws-sns';

export class PepStack extends Stack {
  
  /**
   * The KMS CMK used to encrypt resources.
   */
  private _key: IKey;

  /**
   * The SNS topic on which notifications are sent.
   */
  private _topic: ITopic;

  /**
   * The Prototype Engagement Pack CDK Stack deploys all the required
   * resources on the customer account to secure the prototyping environment
   * according to the given configuration.
   *
   * It takes care of creating an SNS topic used to receive the different alerts
   * and creates a Customer Managed Key in KMS to encrypt the storage of created
   * resources (e.g S3 Buckets).
   *
   * @param scope the construct scope.
   * @param id the identifier of the stack.
   * @param props a property object associated with the stack.
   */
  constructor(
    scope: Construct,
    id: string,
    configuration: IConfiguration,
    env: Environment
  ) {
    super(scope, id, { env });    

    // A reference to the VPC optionally created when the
    // configuration requires the use of VPC endpoints.
    let vpc = undefined;

    // A reference to the CloudTrail construct.
    let cloudtrail = undefined;

    // Creating the budget construct.
    if (configuration.budget) {
      if (PARTITION === 'aws') {
        new BudgetConstruct(this, 'Budget', {
          configuration,
          topic: this.topic,
          key: this.key
        });
      } else {
        Annotations.of(this).addWarningV2(
          'PEP:BudgetsNotSupported',
          `AWS Budgets is not available in the ${PARTITION} partition. Skipping budget deployment.`
        );
      }
    }

    // Creating the GuardDuty construct.
    if (configuration.guardDuty) {
      new GuardDutyConstruct(this, 'GuardDuty', {
        configuration,
        topic: this.topic,
        key: this.key
      });
    }

    // Creating the CloudTrail construct.
    if (configuration.cloudtrail) {
      cloudtrail = new CloudTrailConstruct(this, 'CloudTrail', {
        configuration,
        key: this.key
      });
    }

    // Creating the cross-account role.
    if (configuration.engagement?.role) {
      new CrossAccountRoleConstruct(this, 'CrossAccountRole', {
        configuration
      });
    }

    // Creating a optional VPC and VPC Endpoints.
    if (configuration.network && configuration.network.useVpcEndpoints) {
      vpc = new VpcConstruct(this, 'Vpc').vpc;
    }

    // Creating the AWS Config construct.
    if (configuration.config) {
      new ConfigConstruct(this, 'Config', {
        configuration,
        topic: this.topic,
        key: this.key,
        vpc
      });
    }

    // Creating the Inspector construct.
    if (configuration.inspector?.enabled) {
      new InspectorConstruct(this, 'Inspector', {
        configuration,
        topic: this.topic,
        key: this.key
      });
    }

    // Creating the notification construct.
    if (configuration.notification) {
      new NotificationConstruct(this, 'Notification', {
        configuration,
        topic: this.topic,
        key: this.key,
        vpc
      });
    }

    // Creating the security policies construct.
    if (configuration.securityPolicies) {
      new SecurityPoliciesConstruct(this, 'SecurityPolicies', {
        stack: this,
        topic: this.topic,
        key: this.key,
        configuration,
        cloudtrail
      });
    }

    // Creating the development environment construct.
    if (configuration.devEnvironment?.enabled) {
      new DevEnvironmentConstruct(this, 'DevEnvironment', {
        configuration,
        key: this.key
      });
    }
  }

  /**
   * The KMS Customer Managed Key used to encrypt all of the resources
   * created by the Prototype Engagement Pack. Created on first access so
   * configurations that require no encrypted resources synthesize without it.
   * @returns {IKey} the PEP KMS Customer Managed Key instance.
   */
  public get key(): IKey {
    this._key ??= new Key(this, 'PrototypeEngagementKey', {
      description: 'The KMS Customer Managed Key used to encrypt all of the resources created by the Prototype Engagement Pack.',
      enableKeyRotation: true
    });
    return (this._key);
  }

  /**
   * The SNS topic on which the Prototype Engagement Pack publishes events.
   * Created on first access, and encrypted with the CMK.
   * @returns {ITopic} the PEP SNS topic instance.
   */
  public get topic(): ITopic {
    this._topic ??= new Topic(this, 'PrototypeEngagementAlerts', {
      masterKey: this.key
    });
    return (this._topic);
  }
}
