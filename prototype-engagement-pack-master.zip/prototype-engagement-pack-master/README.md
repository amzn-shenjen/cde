<div align="center">
  <img width="200" src="assets/icon.png" />
</div>

# Prototype Engagement Pack

> The prototyping engagement pack is a CDK project used to create secure prototyping sandbox environments.

Current version: **3.4.0**

## 📋 Table of content

- [Prototype Engagement Pack](#prototype-engagement-pack)
  - [📋 Table of content](#-table-of-content)
  - [🚀 Tutorial](#-tutorial)
  - [🎒 Requirements](#-requirements)
  - [🔰 Description](#-description)
  - [🧰 Terraform Variant](#-terraform-variant)
  - [📘 Architecture](#-architecture)
    - [Using VPC Endpoints](#using-vpc-endpoints)
  - [🖥️ Development Environment](#️-development-environment)
  - [👀 See Also](#-see-also)

## 🚀 Tutorial

Before getting started, verify that your configuration matches the [list of requirements](#-requirements) for the Prototype Engagement Pack. If you do not want to use your computer for installing the Prototype Engagement Pack, you can use [AWS CloudShell](https://docs.aws.amazon.com/cloudshell/latest/userguide/welcome.html) which comes preconfigured with all requirements. Once done, simply open this project using your terminal.

You first need to install the dependencies of the project to make it ready to use. To do so, simply run:

```bash
npm ci
```

You then run the built-in wizard which will prompt you with questions on the type of configuration you would like to apply to the sandobox environment ([More information on CDK bootstrapping](https://docs.aws.amazon.com/cdk/latest/guide/cli.html#cli-bootstrap)).

```bash
npm run wizard
```

The wizard will then generate a configuration in the `prototype.context.json` file at the root of this project. 

Before deploying, you need to ensure that the AWS CDK has been boostrapped on the target account and region.

> You need to bootstrap the target account once, you can then dismiss this step. If you're planning on using multiple regions, the boostrap process must be done for each AWS region.

```bash
npm run bootstrap
```

Once the sandbox account has been bootstrapped, you can deploy the Prototype Engagement Pack using the following command.

```bash
npm run deploy
```

> AWS CDK will create and deploy a CloudFormation template on the sandbox account which you can view in the [CloudFormation console](https://console.aws.amazon.com/cloudformation/home) in the selected region.

Whenever the prototype comes to an end, you need to remove the Prototype Engagement Pack from the sandbox account and all the resources it has deployed on the account. To do so, you use the following command which will destroy the associated CloudFormation stack.

```bash
npm run destroy
```

## 🎒 Requirements

- A dedicated AWS Account and a deployment machine that must be able to deploy on this account. ([How to create an AWS account](https://aws.amazon.com/premiumsupport/knowledge-center/create-and-activate-aws-account/?nc1=h_ls) | [How to create an AWS Organization account](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_accounts_create.html))
- [NodeJS 20+](https://nodejs.org/en/) must be installed on the deployment machine. ([Instructions](https://nodejs.org/en/download/))
- The [AWS CDK CLI](https://aws.amazon.com/en/cdk/) must be installed on the deployment machine. ([Instructions](https://docs.aws.amazon.com/cdk/latest/guide/getting_started.html))
- The [AWS Config](https://aws.amazon.com/en/config/) service must be enabled on the target account and recording must be turned on if you would like to use AWS Config rules. ([Instructions](https://docs.aws.amazon.com/config/latest/developerguide/gs-console.html)). *The AWS Config configuration **should** include **global resources** (e.g., AWS IAM resources) to make them discovered by the service and to run rules over them.*
- IAM access to billing must be enabled if you would like to create and manage AWS Budgets. ([Instructions](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/control-access-billing.html#ControllingAccessWebsite-Activate))
- When you deploy the PEP, you are required to provide email addresses for email notifications. Notifications are sent when there are Budget alerts or AWS Config Rule alerts. For this to work correctly, the *sender* email that you choose needs to be verified by AWS SNS. If you select a customer email address to be the *sender*, please inform them that they need to verify their email, this is done by responding to the email that AWS SNS sends you. Sender email addresses can also be verified via the AWS Console in the customer sandbox account. If you do not verify the sender email, you will not recieve email notifications.
- AWS account credentials should be configured in your environment. AWS CloudShell does this automatically for you. If you are deploying from your laptop/PC or another environment make sure the account credentials and regions are [configured correctly](https://docs.aws.amazon.com/cli/v1/userguide/cli-configure-files.html).

## 🔰 Description

The Prototype Engagement Pack is a configurable and modular [AWS CDK](https://docs.aws.amazon.com/cdk/latest/guide/home.html) project that can be used to secure the environment of a sandbox account during prototyping activities. It can conditionally upon selection using the Prototype Engagement Pack Wizard enable the deployment of the following components on a sandbox account.

- The IAM role allowing cross-account access between an AWS internal account and the sandbox account. ([More information](./docs/components.md#cross-account-role))
- A set of AWS Config rules monitoring compliance in the sandbox account. ([More information](./docs/components.md#aws-config-rules))
- A set of AWS Config remediation actions automatically executed when one of the AWS Config rules detects non-compliance (today, remediations include automatic protection of public S3 buckets).
- An AWS Budget dedicated to the prototype defining a cost threshold not to be exceeded during the prototype.
- Notification mechanisms that will alert the customer, the AWS engineer(s) and the engagement manager of potential security threats through E-mails, Slack, or Teams Notifications.
- A CloudTrail trail that logs all the actions occurring on the sandbox account in an encrypted bucket for traceability purposes. ([More information](./docs/components.md#aws-cloudtrail-audit-log))
- A set of additional security perimeter measures used to further improve the security of the sandbox account. ([More information](./docs/security-perimeter-rules.md))

## 🧰 Terraform Variant

This repository is the **AWS CDK** flavor of the Prototype Engagement Pack. A **Terraform** flavor deploying the same components is also available for customers and IT teams who prefer to work with Terraform rather than CDK. Both variants are driven by the same wizard and offer the same set of components, so you can pick the one that matches the Infrastructure-as-Code toolchain preferred for the sandbox account. ([More information](./terraform/README.md))

## 📘 Architecture

Below is the architecture diagram describing the resources that the Prototype Engagement Pack can create depending on the selected options.

<div align="center">
  <img src="assets/diagrams/security-diagram.png" />
  <div align="center"><sub>The Prototype Engagement Pack (click to enlarge)</sub></div>
</div>

### Using VPC Endpoints

Some customers have hard requirements on using exclusively internal traffic to the AWS Cloud for security and compliance reasons. For this reason, the Prototype Engagement Pack has a feature that can be enabled using the Wizard to place Lambda functions within a VPC and creates the required VPC Endpoints to allow these Lambda functions to interact with AWS services.

<div align="center">
  <img src="assets/diagrams/security-diagram-vpc.png" />
  <div align="center"><sub>The Prototype Engagement Pack with VPC Endpoints</sub></div>
</div>

## 🖥️ Development Environment

The Prototype Engagement Pack also includes an optional **Development Environment** that provides a secure, cloud-based VS Code server running inside the customer's sandbox account, with development tools pre-installed and access over SSM port forwarding (no direct internet access required). It is enabled through the wizard.

> For features, architecture, and connection instructions, see the [Development Environment documentation](./docs/dev-environment.md).

## 👀 See Also

- The [Changelog](CHANGELOG.md) of the project.
- The [License](LICENSE) of the project.
- The [Code of Conduct](CODE_OF_CONDUCT.md) of the project.
